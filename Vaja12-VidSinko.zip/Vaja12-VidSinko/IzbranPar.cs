using System;
using System.Drawing;
using System.Windows.Forms;

namespace Vaja12_VidSinko
{
    public class IzbranPar : Form
    {
        private readonly string podatekDogodka;
        private readonly Func<string, bool> dodajNaStavniListek;

        private string stevilkaDogodka;
        private string vrstaSporta;
        private string opisDogodka;
        private string[] oznakeMoznosti;
        private string[] kvote;

        private Label lblNaslov;
        private Label lblStevilkaNaziv;
        private Label lblStevilkaVrednost;
        private Label lblSportNaziv;
        private Label lblSportVrednost;
        private Label lblDogodekNaziv;
        private Label lblDogodekVrednost;
        private GroupBox grpMoznosti;
        private RadioButton rbMoznostA;
        private RadioButton rbMoznostB;
        private RadioButton rbMoznostC;
        private Button btnDodajNaListek;
        private Button btnPreklici;

        public IzbranPar(string podatekDogodka, Func<string, bool> dodajNaStavniListek)
        {
            this.podatekDogodka = podatekDogodka;
            this.dodajNaStavniListek = dodajNaStavniListek;

            InitializeComponent();
            if (RazstaviDogodek())
            {
                PrikaziDogodek();
            }
        }

        private void InitializeComponent()
        {
            lblNaslov = new Label();
            lblStevilkaNaziv = new Label();
            lblStevilkaVrednost = new Label();
            lblSportNaziv = new Label();
            lblSportVrednost = new Label();
            lblDogodekNaziv = new Label();
            lblDogodekVrednost = new Label();
            grpMoznosti = new GroupBox();
            rbMoznostA = new RadioButton();
            rbMoznostB = new RadioButton();
            rbMoznostC = new RadioButton();
            btnDodajNaListek = new Button();
            btnPreklici = new Button();
            grpMoznosti.SuspendLayout();
            SuspendLayout();

            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(247, 248, 251);
            ClientSize = new Size(620, 390);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Icon = SystemIcons.Shield;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "IzbranPar";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Športna loterija - Izbran par";

            lblNaslov.AutoSize = true;
            lblNaslov.Font = new Font("Segoe UI Semibold", 16F, FontStyle.Bold);
            lblNaslov.ForeColor = Color.FromArgb(24, 54, 93);
            lblNaslov.Location = new Point(25, 22);
            lblNaslov.Name = "lblNaslov";
            lblNaslov.Size = new Size(118, 30);
            lblNaslov.TabIndex = 0;
            lblNaslov.Text = "Izbran par";

            lblStevilkaNaziv.AutoSize = true;
            lblStevilkaNaziv.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            lblStevilkaNaziv.Location = new Point(28, 78);
            lblStevilkaNaziv.Name = "lblStevilkaNaziv";
            lblStevilkaNaziv.Size = new Size(64, 19);
            lblStevilkaNaziv.TabIndex = 1;
            lblStevilkaNaziv.Text = "Številka:";

            lblStevilkaVrednost.AutoSize = true;
            lblStevilkaVrednost.Font = new Font("Segoe UI", 10F);
            lblStevilkaVrednost.Location = new Point(110, 78);
            lblStevilkaVrednost.Name = "lblStevilkaVrednost";
            lblStevilkaVrednost.Size = new Size(12, 19);
            lblStevilkaVrednost.TabIndex = 2;
            lblStevilkaVrednost.Text = "-";

            lblSportNaziv.AutoSize = true;
            lblSportNaziv.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            lblSportNaziv.Location = new Point(28, 112);
            lblSportNaziv.Name = "lblSportNaziv";
            lblSportNaziv.Size = new Size(49, 19);
            lblSportNaziv.TabIndex = 3;
            lblSportNaziv.Text = "Šport:";

            lblSportVrednost.AutoSize = true;
            lblSportVrednost.Font = new Font("Segoe UI", 10F);
            lblSportVrednost.Location = new Point(110, 112);
            lblSportVrednost.Name = "lblSportVrednost";
            lblSportVrednost.Size = new Size(12, 19);
            lblSportVrednost.TabIndex = 4;
            lblSportVrednost.Text = "-";

            lblDogodekNaziv.AutoSize = true;
            lblDogodekNaziv.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            lblDogodekNaziv.Location = new Point(28, 146);
            lblDogodekNaziv.Name = "lblDogodekNaziv";
            lblDogodekNaziv.Size = new Size(68, 19);
            lblDogodekNaziv.TabIndex = 5;
            lblDogodekNaziv.Text = "Dogodek:";

            lblDogodekVrednost.Font = new Font("Segoe UI", 10F);
            lblDogodekVrednost.Location = new Point(110, 146);
            lblDogodekVrednost.Name = "lblDogodekVrednost";
            lblDogodekVrednost.Size = new Size(480, 48);
            lblDogodekVrednost.TabIndex = 6;
            lblDogodekVrednost.Text = "-";

            grpMoznosti.Controls.Add(rbMoznostA);
            grpMoznosti.Controls.Add(rbMoznostB);
            grpMoznosti.Controls.Add(rbMoznostC);
            grpMoznosti.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            grpMoznosti.ForeColor = Color.FromArgb(24, 54, 93);
            grpMoznosti.Location = new Point(32, 213);
            grpMoznosti.Name = "grpMoznosti";
            grpMoznosti.Size = new Size(558, 99);
            grpMoznosti.TabIndex = 7;
            grpMoznosti.TabStop = false;
            grpMoznosti.Text = "Izberi možnost za igranje";

            rbMoznostA.AutoSize = true;
            rbMoznostA.Font = new Font("Segoe UI", 10F);
            rbMoznostA.Location = new Point(20, 30);
            rbMoznostA.Name = "rbMoznostA";
            rbMoznostA.Size = new Size(98, 23);
            rbMoznostA.TabIndex = 0;
            rbMoznostA.TabStop = true;
            rbMoznostA.Text = "Možnost A";
            rbMoznostA.UseVisualStyleBackColor = true;
            rbMoznostA.CheckedChanged += RadioGumbi_CheckedChanged;

            rbMoznostB.AutoSize = true;
            rbMoznostB.Font = new Font("Segoe UI", 10F);
            rbMoznostB.Location = new Point(20, 59);
            rbMoznostB.Name = "rbMoznostB";
            rbMoznostB.Size = new Size(99, 23);
            rbMoznostB.TabIndex = 1;
            rbMoznostB.TabStop = true;
            rbMoznostB.Text = "Možnost B";
            rbMoznostB.UseVisualStyleBackColor = true;
            rbMoznostB.CheckedChanged += RadioGumbi_CheckedChanged;

            rbMoznostC.AutoSize = true;
            rbMoznostC.Font = new Font("Segoe UI", 10F);
            rbMoznostC.Location = new Point(281, 30);
            rbMoznostC.Name = "rbMoznostC";
            rbMoznostC.Size = new Size(100, 23);
            rbMoznostC.TabIndex = 2;
            rbMoznostC.TabStop = true;
            rbMoznostC.Text = "Možnost C";
            rbMoznostC.UseVisualStyleBackColor = true;
            rbMoznostC.CheckedChanged += RadioGumbi_CheckedChanged;

            btnDodajNaListek.BackColor = Color.FromArgb(32, 129, 226);
            btnDodajNaListek.FlatAppearance.BorderSize = 0;
            btnDodajNaListek.FlatStyle = FlatStyle.Flat;
            btnDodajNaListek.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnDodajNaListek.ForeColor = Color.White;
            btnDodajNaListek.Location = new Point(306, 330);
            btnDodajNaListek.Name = "btnDodajNaListek";
            btnDodajNaListek.Size = new Size(138, 38);
            btnDodajNaListek.TabIndex = 8;
            btnDodajNaListek.Text = "Dodaj na listek";
            btnDodajNaListek.UseVisualStyleBackColor = false;
            btnDodajNaListek.Click += BtnDodajNaListek_Click;

            btnPreklici.BackColor = Color.FromArgb(86, 94, 109);
            btnPreklici.FlatAppearance.BorderSize = 0;
            btnPreklici.FlatStyle = FlatStyle.Flat;
            btnPreklici.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnPreklici.ForeColor = Color.White;
            btnPreklici.Location = new Point(452, 330);
            btnPreklici.Name = "btnPreklici";
            btnPreklici.Size = new Size(138, 38);
            btnPreklici.TabIndex = 9;
            btnPreklici.Text = "Prekliči";
            btnPreklici.UseVisualStyleBackColor = false;
            btnPreklici.Click += BtnPreklici_Click;

            Controls.Add(lblNaslov);
            Controls.Add(lblStevilkaNaziv);
            Controls.Add(lblStevilkaVrednost);
            Controls.Add(lblSportNaziv);
            Controls.Add(lblSportVrednost);
            Controls.Add(lblDogodekNaziv);
            Controls.Add(lblDogodekVrednost);
            Controls.Add(grpMoznosti);
            Controls.Add(btnDodajNaListek);
            Controls.Add(btnPreklici);

            grpMoznosti.ResumeLayout(false);
            grpMoznosti.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        private bool RazstaviDogodek()
        {
            string[] deliDogodka = podatekDogodka.Split('|');

            if (deliDogodka.Length != 4)
            {
                MessageBox.Show(
                    "Dogodek ni zapisan v pravilnem formatu.",
                    "Napaka",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                Close();
                return false;
            }

            stevilkaDogodka = deliDogodka[0];
            vrstaSporta = deliDogodka[1];
            opisDogodka = deliDogodka[2];
            kvote = deliDogodka[3].Split('/');

            if (kvote.Length < 1 || kvote.Length > 3)
            {
                MessageBox.Show(
                    "Dogodek nima pravilno zapisanih kvot.",
                    "Napaka",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                Close();
                return false;
            }

            if (kvote.Length == 1)
            {
                oznakeMoznosti = new[] { "Z" };
            }
            else if (kvote.Length == 2)
            {
                oznakeMoznosti = new[] { "1", "2" };
            }
            else
            {
                oznakeMoznosti = new[] { "1", "0", "2" };
            }

            return true;
        }

        private void PrikaziDogodek()
        {
            lblStevilkaVrednost.Text = stevilkaDogodka;
            lblSportVrednost.Text = vrstaSporta;
            lblDogodekVrednost.Text = opisDogodka;

            rbMoznostA.Visible = false;
            rbMoznostB.Visible = false;
            rbMoznostC.Visible = false;

            if (kvote.Length >= 1)
            {
                rbMoznostA.Visible = true;
                rbMoznostA.Text = $"{oznakeMoznosti[0]} - kvota {kvote[0]}";
            }

            if (kvote.Length >= 2)
            {
                rbMoznostB.Visible = true;
                rbMoznostB.Text = $"{oznakeMoznosti[1]} - kvota {kvote[1]}";
            }

            if (kvote.Length >= 3)
            {
                rbMoznostC.Visible = true;
                rbMoznostC.Text = $"{oznakeMoznosti[2]} - kvota {kvote[2]}";
            }

            btnDodajNaListek.Enabled = false;
        }

        private void RadioGumbi_CheckedChanged(object sender, EventArgs e)
        {
            btnDodajNaListek.Enabled = rbMoznostA.Checked || rbMoznostB.Checked || rbMoznostC.Checked;
        }

        private void BtnDodajNaListek_Click(object sender, EventArgs e)
        {
            string oznaka = string.Empty;
            string kvota = string.Empty;

            if (rbMoznostA.Checked)
            {
                oznaka = oznakeMoznosti[0];
                kvota = kvote[0];
            }
            else if (rbMoznostB.Checked)
            {
                oznaka = oznakeMoznosti[1];
                kvota = kvote[1];
            }
            else if (rbMoznostC.Checked)
            {
                oznaka = oznakeMoznosti[2];
                kvota = kvote[2];
            }

            if (string.IsNullOrEmpty(oznaka))
            {
                MessageBox.Show(
                    "Najprej izberi eno izmed možnosti.",
                    "Manjkajoča izbira",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            string stavek = $"{stevilkaDogodka}|{vrstaSporta}|{opisDogodka}|{oznaka}|{kvota}";
            if (dodajNaStavniListek == null || dodajNaStavniListek(stavek))
            {
                Close();
            }
        }

        private void BtnPreklici_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
