using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace Vaja12_VidSinko
{
    public class DodajDogodek : Form
    {
        private readonly List<string> dogodki;

        private Label lblNaslov;
        private Label lblStevilkaDogodka;
        private Label lblVrstaSporta;
        private Label lblDogodek;
        private Label lblMoznosti;
        private Label lblKvotaZ;
        private Label lblKvota1;
        private Label lblKvota0;
        private Label lblKvota2;
        private TextBox txtStevilkaDogodka;
        private ComboBox cmbVrstaSporta;
        private TextBox txtDogodek;
        private GroupBox grpMoznosti;
        private RadioButton rbMoznost1;
        private RadioButton rbMoznost2;
        private RadioButton rbMoznost3;
        private TextBox txtKvotaZ;
        private TextBox txtKvota1;
        private TextBox txtKvota0;
        private TextBox txtKvota2;
        private Button btnDodaj;
        private Button btnPreklici;

        public DodajDogodek(List<string> dogodki)
        {
            this.dogodki = dogodki;
            InitializeComponent();
            NastaviZacetnoStanje();
        }

        private void InitializeComponent()
        {
            lblNaslov = new Label();
            lblStevilkaDogodka = new Label();
            lblVrstaSporta = new Label();
            lblDogodek = new Label();
            lblMoznosti = new Label();
            lblKvotaZ = new Label();
            lblKvota1 = new Label();
            lblKvota0 = new Label();
            lblKvota2 = new Label();
            txtStevilkaDogodka = new TextBox();
            cmbVrstaSporta = new ComboBox();
            txtDogodek = new TextBox();
            grpMoznosti = new GroupBox();
            rbMoznost1 = new RadioButton();
            rbMoznost2 = new RadioButton();
            rbMoznost3 = new RadioButton();
            txtKvotaZ = new TextBox();
            txtKvota1 = new TextBox();
            txtKvota0 = new TextBox();
            txtKvota2 = new TextBox();
            btnDodaj = new Button();
            btnPreklici = new Button();
            grpMoznosti.SuspendLayout();
            SuspendLayout();

            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(248, 249, 252);
            ClientSize = new Size(560, 470);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Icon = SystemIcons.Shield;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "DodajDogodek";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Športna loterija - Dodaj dogodek";

            lblNaslov.AutoSize = true;
            lblNaslov.Font = new Font("Segoe UI Semibold", 16F, FontStyle.Bold);
            lblNaslov.ForeColor = Color.FromArgb(24, 54, 93);
            lblNaslov.Location = new Point(27, 23);
            lblNaslov.Name = "lblNaslov";
            lblNaslov.Size = new Size(165, 30);
            lblNaslov.TabIndex = 0;
            lblNaslov.Text = "Dodaj dogodek";

            lblStevilkaDogodka.AutoSize = true;
            lblStevilkaDogodka.Font = new Font("Segoe UI", 10F);
            lblStevilkaDogodka.Location = new Point(30, 80);
            lblStevilkaDogodka.Name = "lblStevilkaDogodka";
            lblStevilkaDogodka.Size = new Size(108, 19);
            lblStevilkaDogodka.TabIndex = 1;
            lblStevilkaDogodka.Text = "Številka dogodka";

            lblVrstaSporta.AutoSize = true;
            lblVrstaSporta.Font = new Font("Segoe UI", 10F);
            lblVrstaSporta.Location = new Point(30, 136);
            lblVrstaSporta.Name = "lblVrstaSporta";
            lblVrstaSporta.Size = new Size(84, 19);
            lblVrstaSporta.TabIndex = 2;
            lblVrstaSporta.Text = "Vrsta športa";

            lblDogodek.AutoSize = true;
            lblDogodek.Font = new Font("Segoe UI", 10F);
            lblDogodek.Location = new Point(30, 192);
            lblDogodek.Name = "lblDogodek";
            lblDogodek.Size = new Size(65, 19);
            lblDogodek.TabIndex = 3;
            lblDogodek.Text = "Dogodek";

            lblMoznosti.AutoSize = true;
            lblMoznosti.Font = new Font("Segoe UI", 10F);
            lblMoznosti.Location = new Point(30, 248);
            lblMoznosti.Name = "lblMoznosti";
            lblMoznosti.Size = new Size(112, 19);
            lblMoznosti.TabIndex = 4;
            lblMoznosti.Text = "Možne postavitve";

            lblKvotaZ.AutoSize = true;
            lblKvotaZ.Font = new Font("Segoe UI", 10F);
            lblKvotaZ.Location = new Point(30, 347);
            lblKvotaZ.Name = "lblKvotaZ";
            lblKvotaZ.Size = new Size(56, 19);
            lblKvotaZ.TabIndex = 5;
            lblKvotaZ.Text = "Kvota Z";

            lblKvota1.AutoSize = true;
            lblKvota1.Font = new Font("Segoe UI", 10F);
            lblKvota1.Location = new Point(162, 347);
            lblKvota1.Name = "lblKvota1";
            lblKvota1.Size = new Size(54, 19);
            lblKvota1.TabIndex = 6;
            lblKvota1.Text = "Kvota 1";

            lblKvota0.AutoSize = true;
            lblKvota0.Font = new Font("Segoe UI", 10F);
            lblKvota0.Location = new Point(294, 347);
            lblKvota0.Name = "lblKvota0";
            lblKvota0.Size = new Size(55, 19);
            lblKvota0.TabIndex = 7;
            lblKvota0.Text = "Kvota 0";

            lblKvota2.AutoSize = true;
            lblKvota2.Font = new Font("Segoe UI", 10F);
            lblKvota2.Location = new Point(426, 347);
            lblKvota2.Name = "lblKvota2";
            lblKvota2.Size = new Size(54, 19);
            lblKvota2.TabIndex = 8;
            lblKvota2.Text = "Kvota 2";

            txtStevilkaDogodka.Font = new Font("Segoe UI", 10F);
            txtStevilkaDogodka.Location = new Point(30, 102);
            txtStevilkaDogodka.Name = "txtStevilkaDogodka";
            txtStevilkaDogodka.Size = new Size(500, 25);
            txtStevilkaDogodka.TabIndex = 9;

            cmbVrstaSporta.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbVrstaSporta.Font = new Font("Segoe UI", 10F);
            cmbVrstaSporta.FormattingEnabled = true;
            cmbVrstaSporta.Items.AddRange(new object[] { "Nogomet", "Tenis", "Rokomet", "Košarka", "Kolesarstvo", "Odbojka" });
            cmbVrstaSporta.Location = new Point(30, 158);
            cmbVrstaSporta.Name = "cmbVrstaSporta";
            cmbVrstaSporta.Size = new Size(500, 25);
            cmbVrstaSporta.TabIndex = 10;

            txtDogodek.Font = new Font("Segoe UI", 10F);
            txtDogodek.Location = new Point(30, 214);
            txtDogodek.Name = "txtDogodek";
            txtDogodek.Size = new Size(500, 25);
            txtDogodek.TabIndex = 11;

            grpMoznosti.Controls.Add(rbMoznost1);
            grpMoznosti.Controls.Add(rbMoznost2);
            grpMoznosti.Controls.Add(rbMoznost3);
            grpMoznosti.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            grpMoznosti.ForeColor = Color.FromArgb(24, 54, 93);
            grpMoznosti.Location = new Point(30, 271);
            grpMoznosti.Name = "grpMoznosti";
            grpMoznosti.Size = new Size(500, 59);
            grpMoznosti.TabIndex = 12;
            grpMoznosti.TabStop = false;
            grpMoznosti.Text = "Izberi število možnih izidov";

            rbMoznost1.AutoSize = true;
            rbMoznost1.Location = new Point(20, 26);
            rbMoznost1.Name = "rbMoznost1";
            rbMoznost1.Size = new Size(93, 21);
            rbMoznost1.TabIndex = 0;
            rbMoznost1.Text = "Možnost 1";
            rbMoznost1.UseVisualStyleBackColor = true;
            rbMoznost1.CheckedChanged += Moznosti_CheckedChanged;

            rbMoznost2.AutoSize = true;
            rbMoznost2.Location = new Point(187, 26);
            rbMoznost2.Name = "rbMoznost2";
            rbMoznost2.Size = new Size(93, 21);
            rbMoznost2.TabIndex = 1;
            rbMoznost2.Text = "Možnost 2";
            rbMoznost2.UseVisualStyleBackColor = true;
            rbMoznost2.CheckedChanged += Moznosti_CheckedChanged;

            rbMoznost3.AutoSize = true;
            rbMoznost3.Location = new Point(354, 26);
            rbMoznost3.Name = "rbMoznost3";
            rbMoznost3.Size = new Size(93, 21);
            rbMoznost3.TabIndex = 2;
            rbMoznost3.Text = "Možnost 3";
            rbMoznost3.UseVisualStyleBackColor = true;
            rbMoznost3.CheckedChanged += Moznosti_CheckedChanged;

            txtKvotaZ.Font = new Font("Segoe UI", 10F);
            txtKvotaZ.Location = new Point(30, 369);
            txtKvotaZ.Name = "txtKvotaZ";
            txtKvotaZ.Size = new Size(104, 25);
            txtKvotaZ.TabIndex = 13;

            txtKvota1.Font = new Font("Segoe UI", 10F);
            txtKvota1.Location = new Point(162, 369);
            txtKvota1.Name = "txtKvota1";
            txtKvota1.Size = new Size(104, 25);
            txtKvota1.TabIndex = 14;

            txtKvota0.Font = new Font("Segoe UI", 10F);
            txtKvota0.Location = new Point(294, 369);
            txtKvota0.Name = "txtKvota0";
            txtKvota0.Size = new Size(104, 25);
            txtKvota0.TabIndex = 15;

            txtKvota2.Font = new Font("Segoe UI", 10F);
            txtKvota2.Location = new Point(426, 369);
            txtKvota2.Name = "txtKvota2";
            txtKvota2.Size = new Size(104, 25);
            txtKvota2.TabIndex = 16;

            btnDodaj.BackColor = Color.FromArgb(48, 165, 111);
            btnDodaj.FlatAppearance.BorderSize = 0;
            btnDodaj.FlatStyle = FlatStyle.Flat;
            btnDodaj.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnDodaj.ForeColor = Color.White;
            btnDodaj.Location = new Point(250, 414);
            btnDodaj.Name = "btnDodaj";
            btnDodaj.Size = new Size(132, 38);
            btnDodaj.TabIndex = 17;
            btnDodaj.Text = "Dodaj dogodek";
            btnDodaj.UseVisualStyleBackColor = false;
            btnDodaj.Click += BtnDodaj_Click;

            btnPreklici.BackColor = Color.FromArgb(86, 94, 109);
            btnPreklici.FlatAppearance.BorderSize = 0;
            btnPreklici.FlatStyle = FlatStyle.Flat;
            btnPreklici.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnPreklici.ForeColor = Color.White;
            btnPreklici.Location = new Point(398, 414);
            btnPreklici.Name = "btnPreklici";
            btnPreklici.Size = new Size(132, 38);
            btnPreklici.TabIndex = 18;
            btnPreklici.Text = "Prekliči";
            btnPreklici.UseVisualStyleBackColor = false;
            btnPreklici.Click += BtnPreklici_Click;

            Controls.Add(lblNaslov);
            Controls.Add(lblStevilkaDogodka);
            Controls.Add(lblVrstaSporta);
            Controls.Add(lblDogodek);
            Controls.Add(lblMoznosti);
            Controls.Add(lblKvotaZ);
            Controls.Add(lblKvota1);
            Controls.Add(lblKvota0);
            Controls.Add(lblKvota2);
            Controls.Add(txtStevilkaDogodka);
            Controls.Add(cmbVrstaSporta);
            Controls.Add(txtDogodek);
            Controls.Add(grpMoznosti);
            Controls.Add(txtKvotaZ);
            Controls.Add(txtKvota1);
            Controls.Add(txtKvota0);
            Controls.Add(txtKvota2);
            Controls.Add(btnDodaj);
            Controls.Add(btnPreklici);

            grpMoznosti.ResumeLayout(false);
            grpMoznosti.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        private void NastaviZacetnoStanje()
        {
            cmbVrstaSporta.SelectedIndex = 0;
            rbMoznost3.Checked = true;
        }

        private void Moznosti_CheckedChanged(object sender, EventArgs e)
        {
            PosodobiPoljaKvot();
        }

        private void PosodobiPoljaKvot()
        {
            bool enaMoznost = rbMoznost1.Checked;
            bool dveMoznosti = rbMoznost2.Checked;
            bool triMoznosti = rbMoznost3.Checked;

            txtKvotaZ.Enabled = enaMoznost;
            lblKvotaZ.Enabled = enaMoznost;

            txtKvota1.Enabled = dveMoznosti || triMoznosti;
            lblKvota1.Enabled = dveMoznosti || triMoznosti;

            txtKvota0.Enabled = triMoznosti;
            lblKvota0.Enabled = triMoznosti;

            txtKvota2.Enabled = dveMoznosti || triMoznosti;
            lblKvota2.Enabled = dveMoznosti || triMoznosti;

            if (!enaMoznost)
            {
                txtKvotaZ.Clear();
            }

            if (!dveMoznosti && !triMoznosti)
            {
                txtKvota1.Clear();
                txtKvota2.Clear();
            }

            if (!triMoznosti)
            {
                txtKvota0.Clear();
            }
        }

        private void BtnDodaj_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtStevilkaDogodka.Text) ||
                cmbVrstaSporta.SelectedIndex < 0 ||
                string.IsNullOrWhiteSpace(txtDogodek.Text))
            {
                PrikaziNapako("Izpolniti moraš številko dogodka, vrsto športa in opis dogodka.");
                return;
            }

            if (AliStevilkaDogodkaZeObstaja(txtStevilkaDogodka.Text.Trim()))
            {
                PrikaziNapako(
                    "Dogodek s takšno številko dogodka že obstaja v naboru tekem.",
                    "Napaka pri dodajanju");
                return;
            }

            string zapisKvot;

            if (rbMoznost1.Checked)
            {
                if (!PoskusiPrebratiKvoto(txtKvotaZ.Text, out decimal kvotaZ))
                {
                    PrikaziNapako("Za možnost 1 mora biti izpolnjena veljavna kvota Z.");
                    return;
                }

                zapisKvot = kvotaZ.ToString("0.00", CultureInfo.InvariantCulture);
            }
            else if (rbMoznost2.Checked)
            {
                if (!PoskusiPrebratiKvoto(txtKvota1.Text, out decimal kvota1) ||
                    !PoskusiPrebratiKvoto(txtKvota2.Text, out decimal kvota2))
                {
                    PrikaziNapako("Za možnost 2 morata biti izpolnjeni veljavni kvoti 1 in 2.");
                    return;
                }

                zapisKvot = string.Format(CultureInfo.InvariantCulture, "{0:0.00}/{1:0.00}", kvota1, kvota2);
            }
            else
            {
                if (!PoskusiPrebratiKvoto(txtKvota1.Text, out decimal kvota1) ||
                    !PoskusiPrebratiKvoto(txtKvota0.Text, out decimal kvota0) ||
                    !PoskusiPrebratiKvoto(txtKvota2.Text, out decimal kvota2))
                {
                    PrikaziNapako("Za možnost 3 morajo biti izpolnjene veljavne kvote 1, 0 in 2.");
                    return;
                }

                zapisKvot = string.Format(CultureInfo.InvariantCulture, "{0:0.00}/{1:0.00}/{2:0.00}", kvota1, kvota0, kvota2);
            }

            string novDogodek = string.Format(
                CultureInfo.InvariantCulture,
                "{0}|{1}|{2}|{3}",
                txtStevilkaDogodka.Text.Trim(),
                cmbVrstaSporta.SelectedItem.ToString(),
                txtDogodek.Text.Trim(),
                zapisKvot);

            dogodki.Add(novDogodek);
            DialogResult = DialogResult.OK;
            Close();
        }

        private static bool PoskusiPrebratiKvoto(string besedilo, out decimal kvota)
        {
            kvota = 0m;
            string popravljenoBesedilo = (besedilo ?? string.Empty).Trim().Replace(',', '.');

            return decimal.TryParse(
                       popravljenoBesedilo,
                       NumberStyles.AllowDecimalPoint,
                       CultureInfo.InvariantCulture,
                       out kvota)
                   && kvota > 0m;
        }

        private bool AliStevilkaDogodkaZeObstaja(string stevilkaDogodka)
        {
            foreach (string dogodek in dogodki)
            {
                string[] deliDogodka = dogodek.Split('|');
                if (deliDogodka.Length > 0 && deliDogodka[0] == stevilkaDogodka)
                {
                    return true;
                }
            }

            return false;
        }

        private static void PrikaziNapako(string besedilo, string naslov = "Napaka pri vnosu")
        {
            MessageBox.Show(
                besedilo,
                naslov,
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }

        private void BtnPreklici_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
