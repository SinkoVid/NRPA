using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace Vaja12_VidSinko
{
    public class StavniListek : Form
    {
        private const int MaksimalnoSteviloDogodkov = 16;
        private const decimal PragZaDavek = 300.00m;
        private const decimal StopnjaDavka = 0.15m;

        private readonly List<string> dogodki = new List<string>();
        private readonly CultureInfo slovenskaKultura = CultureInfo.GetCultureInfo("sl-SI");

        private Label lblNaslov;
        private Label lblPodnaslov;
        private ListBox lbStavniListek;
        private Button btnPokaziSeznamTekem;
        private Button btnIzbrisiOznacenega;
        private Button btnIzbrisiVse;
        private GroupBox grpPovzetek;
        private Label lblSkupnaKvota;
        private Label lblVlozek;
        private Label lblDavek;
        private Label lblIzplacilo;
        private TextBox txtSkupnaKvota;
        private TextBox txtVlozek;
        private TextBox txtDavek;
        private TextBox txtIzplacilo;
        private Button btnVplacaj;
        private Label lblNamig;

        public StavniListek()
        {
            InitializeComponent();
            NaloziZacetneDogodke();
            PosodobiStanjeGumbov();
            OsveziPovzetek();
        }

        private void InitializeComponent()
        {
            lblNaslov = new Label();
            lblPodnaslov = new Label();
            lbStavniListek = new ListBox();
            btnPokaziSeznamTekem = new Button();
            btnIzbrisiOznacenega = new Button();
            btnIzbrisiVse = new Button();
            grpPovzetek = new GroupBox();
            lblSkupnaKvota = new Label();
            lblVlozek = new Label();
            lblDavek = new Label();
            lblIzplacilo = new Label();
            txtSkupnaKvota = new TextBox();
            txtVlozek = new TextBox();
            txtDavek = new TextBox();
            txtIzplacilo = new TextBox();
            btnVplacaj = new Button();
            lblNamig = new Label();
            grpPovzetek.SuspendLayout();
            SuspendLayout();

            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(244, 247, 252);
            ClientSize = new Size(860, 520);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Icon = SystemIcons.Shield;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "StavniListek";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Športna loterija - Stavni listek";

            lblNaslov.AutoSize = true;
            lblNaslov.Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point, 238);
            lblNaslov.ForeColor = Color.FromArgb(24, 54, 93);
            lblNaslov.Location = new Point(28, 22);
            lblNaslov.Name = "lblNaslov";
            lblNaslov.Size = new Size(196, 32);
            lblNaslov.TabIndex = 0;
            lblNaslov.Text = "Športna loterija";

            lblPodnaslov.AutoSize = true;
            lblPodnaslov.Font = new Font("Segoe UI", 10F);
            lblPodnaslov.ForeColor = Color.FromArgb(84, 99, 122);
            lblPodnaslov.Location = new Point(31, 58);
            lblPodnaslov.Name = "lblPodnaslov";
            lblPodnaslov.Size = new Size(258, 19);
            lblPodnaslov.TabIndex = 1;
            lblPodnaslov.Text = "Sestavi svoj listek iz predpripravljenih parov";

            lbStavniListek.BackColor = Color.White;
            lbStavniListek.BorderStyle = BorderStyle.FixedSingle;
            lbStavniListek.Font = new Font("Segoe UI", 10F);
            lbStavniListek.FormattingEnabled = true;
            lbStavniListek.HorizontalScrollbar = true;
            lbStavniListek.ItemHeight = 17;
            lbStavniListek.Location = new Point(34, 101);
            lbStavniListek.Name = "lbStavniListek";
            lbStavniListek.Size = new Size(560, 291);
            lbStavniListek.TabIndex = 2;
            lbStavniListek.SelectedIndexChanged += LbStavniListek_SelectedIndexChanged;

            btnPokaziSeznamTekem.BackColor = Color.FromArgb(32, 129, 226);
            btnPokaziSeznamTekem.FlatAppearance.BorderSize = 0;
            btnPokaziSeznamTekem.FlatStyle = FlatStyle.Flat;
            btnPokaziSeznamTekem.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnPokaziSeznamTekem.ForeColor = Color.White;
            btnPokaziSeznamTekem.Location = new Point(34, 414);
            btnPokaziSeznamTekem.Name = "btnPokaziSeznamTekem";
            btnPokaziSeznamTekem.Size = new Size(186, 40);
            btnPokaziSeznamTekem.TabIndex = 3;
            btnPokaziSeznamTekem.Text = "Pokaži seznam tekem";
            btnPokaziSeznamTekem.UseVisualStyleBackColor = false;
            btnPokaziSeznamTekem.Click += BtnPokaziSeznamTekem_Click;

            btnIzbrisiOznacenega.BackColor = Color.FromArgb(226, 82, 82);
            btnIzbrisiOznacenega.FlatAppearance.BorderSize = 0;
            btnIzbrisiOznacenega.FlatStyle = FlatStyle.Flat;
            btnIzbrisiOznacenega.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnIzbrisiOznacenega.ForeColor = Color.White;
            btnIzbrisiOznacenega.Location = new Point(239, 414);
            btnIzbrisiOznacenega.Name = "btnIzbrisiOznacenega";
            btnIzbrisiOznacenega.Size = new Size(166, 40);
            btnIzbrisiOznacenega.TabIndex = 4;
            btnIzbrisiOznacenega.Text = "Izbriši označenega";
            btnIzbrisiOznacenega.UseVisualStyleBackColor = false;
            btnIzbrisiOznacenega.Click += BtnIzbrisiOznacenega_Click;

            btnIzbrisiVse.BackColor = Color.FromArgb(86, 94, 109);
            btnIzbrisiVse.FlatAppearance.BorderSize = 0;
            btnIzbrisiVse.FlatStyle = FlatStyle.Flat;
            btnIzbrisiVse.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnIzbrisiVse.ForeColor = Color.White;
            btnIzbrisiVse.Location = new Point(423, 414);
            btnIzbrisiVse.Name = "btnIzbrisiVse";
            btnIzbrisiVse.Size = new Size(171, 40);
            btnIzbrisiVse.TabIndex = 5;
            btnIzbrisiVse.Text = "Izbriši vse";
            btnIzbrisiVse.UseVisualStyleBackColor = false;
            btnIzbrisiVse.Click += BtnIzbrisiVse_Click;

            grpPovzetek.BackColor = Color.White;
            grpPovzetek.Controls.Add(lblSkupnaKvota);
            grpPovzetek.Controls.Add(lblVlozek);
            grpPovzetek.Controls.Add(lblDavek);
            grpPovzetek.Controls.Add(lblIzplacilo);
            grpPovzetek.Controls.Add(txtSkupnaKvota);
            grpPovzetek.Controls.Add(txtVlozek);
            grpPovzetek.Controls.Add(txtDavek);
            grpPovzetek.Controls.Add(txtIzplacilo);
            grpPovzetek.Controls.Add(btnVplacaj);
            grpPovzetek.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            grpPovzetek.ForeColor = Color.FromArgb(24, 54, 93);
            grpPovzetek.Location = new Point(622, 101);
            grpPovzetek.Name = "grpPovzetek";
            grpPovzetek.Size = new Size(210, 305);
            grpPovzetek.TabIndex = 6;
            grpPovzetek.TabStop = false;
            grpPovzetek.Text = "Povzetek listka";

            lblSkupnaKvota.AutoSize = true;
            lblSkupnaKvota.Font = new Font("Segoe UI", 9.5F);
            lblSkupnaKvota.Location = new Point(18, 35);
            lblSkupnaKvota.Name = "lblSkupnaKvota";
            lblSkupnaKvota.Size = new Size(88, 17);
            lblSkupnaKvota.TabIndex = 0;
            lblSkupnaKvota.Text = "Skupna kvota";

            lblVlozek.AutoSize = true;
            lblVlozek.Font = new Font("Segoe UI", 9.5F);
            lblVlozek.Location = new Point(18, 92);
            lblVlozek.Name = "lblVlozek";
            lblVlozek.Size = new Size(44, 17);
            lblVlozek.TabIndex = 1;
            lblVlozek.Text = "Vložek";

            lblDavek.AutoSize = true;
            lblDavek.Font = new Font("Segoe UI", 9.5F);
            lblDavek.Location = new Point(18, 149);
            lblDavek.Name = "lblDavek";
            lblDavek.Size = new Size(43, 17);
            lblDavek.TabIndex = 2;
            lblDavek.Text = "Davek";

            lblIzplacilo.AutoSize = true;
            lblIzplacilo.Font = new Font("Segoe UI", 9.5F);
            lblIzplacilo.Location = new Point(18, 206);
            lblIzplacilo.Name = "lblIzplacilo";
            lblIzplacilo.Size = new Size(54, 17);
            lblIzplacilo.TabIndex = 3;
            lblIzplacilo.Text = "Izplačilo";

            txtSkupnaKvota.Location = new Point(21, 55);
            txtSkupnaKvota.Name = "txtSkupnaKvota";
            txtSkupnaKvota.ReadOnly = true;
            txtSkupnaKvota.Size = new Size(165, 25);
            txtSkupnaKvota.TabIndex = 3;
            txtSkupnaKvota.TextAlign = HorizontalAlignment.Right;

            txtVlozek.Location = new Point(21, 112);
            txtVlozek.Name = "txtVlozek";
            txtVlozek.Size = new Size(165, 25);
            txtVlozek.TabIndex = 4;
            txtVlozek.TextAlign = HorizontalAlignment.Right;
            txtVlozek.TextChanged += TxtVlozek_TextChanged;

            txtDavek.Location = new Point(21, 169);
            txtDavek.Name = "txtDavek";
            txtDavek.ReadOnly = true;
            txtDavek.Size = new Size(165, 25);
            txtDavek.TabIndex = 5;
            txtDavek.TextAlign = HorizontalAlignment.Right;

            txtIzplacilo.Location = new Point(21, 226);
            txtIzplacilo.Name = "txtIzplacilo";
            txtIzplacilo.ReadOnly = true;
            txtIzplacilo.Size = new Size(165, 25);
            txtIzplacilo.TabIndex = 6;
            txtIzplacilo.TextAlign = HorizontalAlignment.Right;

            btnVplacaj.BackColor = Color.FromArgb(48, 165, 111);
            btnVplacaj.FlatAppearance.BorderSize = 0;
            btnVplacaj.FlatStyle = FlatStyle.Flat;
            btnVplacaj.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnVplacaj.ForeColor = Color.White;
            btnVplacaj.Location = new Point(68, 261);
            btnVplacaj.Name = "btnVplacaj";
            btnVplacaj.Size = new Size(118, 31);
            btnVplacaj.TabIndex = 7;
            btnVplacaj.Text = "Vplačaj";
            btnVplacaj.UseVisualStyleBackColor = false;
            btnVplacaj.Click += BtnVplacaj_Click;

            lblNamig.Font = new Font("Segoe UI", 9F);
            lblNamig.ForeColor = Color.FromArgb(84, 99, 122);
            lblNamig.Location = new Point(622, 419);
            lblNamig.Name = "lblNamig";
            lblNamig.Size = new Size(210, 63);
            lblNamig.TabIndex = 7;
            lblNamig.Text = "Namig:\r\nPri vložku lahko uporabiš vejico ali piko.\r\nIzplačilo se vedno preračuna na 2 decimalki.";

            Controls.Add(lblNaslov);
            Controls.Add(lblPodnaslov);
            Controls.Add(lbStavniListek);
            Controls.Add(btnPokaziSeznamTekem);
            Controls.Add(btnIzbrisiOznacenega);
            Controls.Add(btnIzbrisiVse);
            Controls.Add(grpPovzetek);
            Controls.Add(lblNamig);

            grpPovzetek.ResumeLayout(false);
            grpPovzetek.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        private void NaloziZacetneDogodke()
        {
            dogodki.Clear();
            dogodki.Add("252|Nogomet|NŠ Mura - NK Maribor|2.30/2.50/1.90");
            dogodki.Add("314|Tenis|Rafael Nadal - Roger Federer|1.85/2.10");
            dogodki.Add("411|Kolesarstvo|Tour De France - Primož Roglič|3.40");
            dogodki.Add("512|Košarka|Dallas Mavericks - Boston Celtics|2.10/2.80/1.75");
            dogodki.Add("618|Rokomet|Celje Pivovarna Laško - Gorenje Velenje|1.95/2.55/2.20");
        }

        private void BtnPokaziSeznamTekem_Click(object sender, EventArgs e)
        {
            using (NaborTekem naborTekem = new NaborTekem(dogodki, PoskusiDodatiNaStavniListek))
            {
                naborTekem.ShowDialog(this);
            }
        }

        private bool PoskusiDodatiNaStavniListek(string vnos)
        {
            if (lbStavniListek.Items.Count >= MaksimalnoSteviloDogodkov)
            {
                MessageBox.Show(
                    $"Na stavnem listku je lahko največ {MaksimalnoSteviloDogodkov} dogodkov.",
                    "Omejitev stavnega listka",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }

            string[] noviDeli = vnos.Split('|');
            if (noviDeli.Length < 1)
            {
                return false;
            }

            string stevilkaDogodka = noviDeli[0];
            foreach (object obstojece in lbStavniListek.Items)
            {
                string[] obstojeceDeli = obstojece.ToString().Split('|');
                if (obstojeceDeli.Length > 0 && obstojeceDeli[0] == stevilkaDogodka)
                {
                    MessageBox.Show(
                        "Dogodek s takšno številko dogodka že obstaja na stavnem listku.",
                        "Napaka pri dodajanju",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    return false;
                }
            }

            lbStavniListek.Items.Add(vnos);
            PosodobiStanjeGumbov();
            OsveziPovzetek();
            return true;
        }

        private void BtnIzbrisiOznacenega_Click(object sender, EventArgs e)
        {
            if (lbStavniListek.SelectedIndex < 0)
            {
                return;
            }

            string stevilkaDogodka = lbStavniListek.SelectedItem.ToString().Split('|')[0];
            DialogResult odgovor = MessageBox.Show(
                $"Se strinjate z izbrisom označenega dogodka, ki je označen s številko dogodka ({stevilkaDogodka})?",
                "Izbris dogodka",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (odgovor != DialogResult.Yes)
            {
                return;
            }

            lbStavniListek.Items.RemoveAt(lbStavniListek.SelectedIndex);
            PosodobiStanjeGumbov();
            OsveziPovzetek();
        }

        private void BtnIzbrisiVse_Click(object sender, EventArgs e)
        {
            if (lbStavniListek.Items.Count == 0)
            {
                return;
            }

            DialogResult odgovor = MessageBox.Show(
                "Stavni listek bo počiščen. Se strinjate z izbrisom vseh dogodkov z njega?",
                "Izbris dogodkov",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (odgovor != DialogResult.Yes)
            {
                return;
            }

            lbStavniListek.Items.Clear();
            PosodobiStanjeGumbov();
            OsveziPovzetek();
        }

        private void LbStavniListek_SelectedIndexChanged(object sender, EventArgs e)
        {
            PosodobiStanjeGumbov();
        }

        private void PosodobiStanjeGumbov()
        {
            bool vsebujeDogodke = lbStavniListek.Items.Count > 0;

            btnIzbrisiVse.Enabled = vsebujeDogodke;
            btnIzbrisiOznacenega.Enabled = lbStavniListek.SelectedIndex >= 0;
            btnVplacaj.Enabled = vsebujeDogodke && PoskusiPrebratiDecimalnoStevilo(txtVlozek.Text, out _);
        }

        private void OsveziPovzetek()
        {
            bool vsebujeDogodke = lbStavniListek.Items.Count > 0;
            decimal skupnaKvota = vsebujeDogodke ? 1m : 0m;

            foreach (object vnos in lbStavniListek.Items)
            {
                string[] deli = vnos.ToString().Split('|');
                if (deli.Length != 5)
                {
                    continue;
                }

                string kvotaBesedilo = deli[4].Replace(".", ",");
                if (decimal.TryParse(kvotaBesedilo, NumberStyles.Number, slovenskaKultura, out decimal kvota))
                {
                    skupnaKvota *= kvota;
                }
            }

            skupnaKvota = Math.Round(skupnaKvota, 2, MidpointRounding.AwayFromZero);
            txtSkupnaKvota.Text = vsebujeDogodke
                ? skupnaKvota.ToString("0.00", slovenskaKultura)
                : string.Empty;

            txtDavek.Clear();
            txtIzplacilo.Clear();

            if (vsebujeDogodke && PoskusiPrebratiDecimalnoStevilo(txtVlozek.Text, out decimal vlozek))
            {
                decimal brutoDobitek = Math.Round(skupnaKvota * vlozek, 2, MidpointRounding.AwayFromZero);
                decimal davek = brutoDobitek >= PragZaDavek
                    ? Math.Round(brutoDobitek * StopnjaDavka, 2, MidpointRounding.AwayFromZero)
                    : 0m;
                decimal izplacilo = Math.Round(brutoDobitek - davek, 2, MidpointRounding.AwayFromZero);

                txtDavek.Text = davek > 0m
                    ? $"{davek.ToString("0.00", slovenskaKultura)} €"
                    : string.Empty;
                txtIzplacilo.Text = $"{izplacilo.ToString("0.00", slovenskaKultura)} €";
            }

            PosodobiStanjeGumbov();
        }

        private void TxtVlozek_TextChanged(object sender, EventArgs e)
        {
            OsveziPovzetek();
        }

        private void BtnVplacaj_Click(object sender, EventArgs e)
        {
            if (lbStavniListek.Items.Count == 0 || !PoskusiPrebratiDecimalnoStevilo(txtVlozek.Text, out decimal vlozek))
            {
                MessageBox.Show(
                    "Najprej dodaj vsaj en dogodek in vnesi veljaven vložek.",
                    "Vplačilo ni mogoče",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            decimal skupnaKvota = decimal.Parse(txtSkupnaKvota.Text, NumberStyles.Number, slovenskaKultura);
            decimal brutoDobitek = Math.Round(skupnaKvota * vlozek, 2, MidpointRounding.AwayFromZero);
            decimal davek = brutoDobitek >= PragZaDavek
                ? Math.Round(brutoDobitek * StopnjaDavka, 2, MidpointRounding.AwayFromZero)
                : 0m;
            decimal izplacilo = Math.Round(brutoDobitek - davek, 2, MidpointRounding.AwayFromZero);

            MessageBox.Show(
                $"Število parov, ki jih boš odigral: {lbStavniListek.Items.Count}\n" +
                $"Skupna kvota znaša: {skupnaKvota.ToString("0.00", slovenskaKultura)}\n" +
                $"Vplačilo: {vlozek.ToString("0.00", slovenskaKultura)} €\n" +
                $"Davek: {davek.ToString("0.00", slovenskaKultura)} €\n" +
                $"Izplačilo: {izplacilo.ToString("0.00", slovenskaKultura)} €",
                "Vplačilo",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            PonastaviStavniListek();
        }

        private bool PoskusiPrebratiDecimalnoStevilo(string besedilo, out decimal vrednost)
        {
            vrednost = 0m;
            string popravljenoBesedilo = (besedilo ?? string.Empty).Trim().Replace(".", ",");

            return decimal.TryParse(
                       popravljenoBesedilo,
                       NumberStyles.Number,
                       slovenskaKultura,
                       out vrednost)
                   && vrednost > 0m;
        }

        private void PonastaviStavniListek()
        {
            lbStavniListek.Items.Clear();
            lbStavniListek.ClearSelected();
            txtVlozek.Clear();
            txtDavek.Clear();
            txtIzplacilo.Clear();
            OsveziPovzetek();
        }
    }
}
