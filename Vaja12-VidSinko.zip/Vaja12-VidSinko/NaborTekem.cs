using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Vaja12_VidSinko
{
    public class NaborTekem : Form
    {
        private readonly List<string> dogodki;
        private readonly Func<string, bool> dodajNaStavniListek;

        private Label lblNaslov;
        private Label lblOpis;
        private ListBox lbDogodki;
        private Button btnIgrajDogodek;
        private Button btnDodajDogodekNaNabor;
        private Button btnZapri;

        public NaborTekem(List<string> dogodki, Func<string, bool> dodajNaStavniListek)
        {
            this.dogodki = dogodki;
            this.dodajNaStavniListek = dodajNaStavniListek;

            InitializeComponent();
            PrikaziDogodke();
            PosodobiStanjeGumbov();
        }

        private void InitializeComponent()
        {
            lblNaslov = new Label();
            lblOpis = new Label();
            lbDogodki = new ListBox();
            btnIgrajDogodek = new Button();
            btnDodajDogodekNaNabor = new Button();
            btnZapri = new Button();
            SuspendLayout();

            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(247, 248, 251);
            ClientSize = new Size(780, 470);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Icon = SystemIcons.Shield;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "NaborTekem";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Športna loterija - Nabor tekem";

            lblNaslov.AutoSize = true;
            lblNaslov.Font = new Font("Segoe UI Semibold", 16F, FontStyle.Bold);
            lblNaslov.ForeColor = Color.FromArgb(24, 54, 93);
            lblNaslov.Location = new Point(24, 20);
            lblNaslov.Name = "lblNaslov";
            lblNaslov.Size = new Size(145, 30);
            lblNaslov.TabIndex = 0;
            lblNaslov.Text = "Nabor tekem";

            lblOpis.AutoSize = true;
            lblOpis.Font = new Font("Segoe UI", 10F);
            lblOpis.ForeColor = Color.FromArgb(84, 99, 122);
            lblOpis.Location = new Point(26, 56);
            lblOpis.Name = "lblOpis";
            lblOpis.Size = new Size(321, 19);
            lblOpis.TabIndex = 1;
            lblOpis.Text = "Izberi dogodek za igranje ali dodaj novega v ponudbo";

            lbDogodki.BackColor = Color.White;
            lbDogodki.BorderStyle = BorderStyle.FixedSingle;
            lbDogodki.Font = new Font("Segoe UI", 10F);
            lbDogodki.FormattingEnabled = true;
            lbDogodki.HorizontalScrollbar = true;
            lbDogodki.ItemHeight = 17;
            lbDogodki.Location = new Point(29, 93);
            lbDogodki.Name = "lbDogodki";
            lbDogodki.Size = new Size(721, 257);
            lbDogodki.TabIndex = 2;
            lbDogodki.SelectedIndexChanged += LbDogodki_SelectedIndexChanged;

            btnIgrajDogodek.BackColor = Color.FromArgb(32, 129, 226);
            btnIgrajDogodek.FlatAppearance.BorderSize = 0;
            btnIgrajDogodek.FlatStyle = FlatStyle.Flat;
            btnIgrajDogodek.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnIgrajDogodek.ForeColor = Color.White;
            btnIgrajDogodek.Location = new Point(29, 382);
            btnIgrajDogodek.Name = "btnIgrajDogodek";
            btnIgrajDogodek.Size = new Size(176, 42);
            btnIgrajDogodek.TabIndex = 3;
            btnIgrajDogodek.Text = "Igraj ta dogodek";
            btnIgrajDogodek.UseVisualStyleBackColor = false;
            btnIgrajDogodek.Click += BtnIgrajDogodek_Click;

            btnDodajDogodekNaNabor.BackColor = Color.FromArgb(48, 165, 111);
            btnDodajDogodekNaNabor.FlatAppearance.BorderSize = 0;
            btnDodajDogodekNaNabor.FlatStyle = FlatStyle.Flat;
            btnDodajDogodekNaNabor.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnDodajDogodekNaNabor.ForeColor = Color.White;
            btnDodajDogodekNaNabor.Location = new Point(225, 382);
            btnDodajDogodekNaNabor.Name = "btnDodajDogodekNaNabor";
            btnDodajDogodekNaNabor.Size = new Size(201, 42);
            btnDodajDogodekNaNabor.TabIndex = 4;
            btnDodajDogodekNaNabor.Text = "Dodaj dogodek na nabor";
            btnDodajDogodekNaNabor.UseVisualStyleBackColor = false;
            btnDodajDogodekNaNabor.Click += BtnDodajDogodekNaNabor_Click;

            btnZapri.BackColor = Color.FromArgb(86, 94, 109);
            btnZapri.FlatAppearance.BorderSize = 0;
            btnZapri.FlatStyle = FlatStyle.Flat;
            btnZapri.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnZapri.ForeColor = Color.White;
            btnZapri.Location = new Point(617, 382);
            btnZapri.Name = "btnZapri";
            btnZapri.Size = new Size(133, 42);
            btnZapri.TabIndex = 5;
            btnZapri.Text = "Zapri";
            btnZapri.UseVisualStyleBackColor = false;
            btnZapri.Click += BtnZapri_Click;

            Controls.Add(lblNaslov);
            Controls.Add(lblOpis);
            Controls.Add(lbDogodki);
            Controls.Add(btnIgrajDogodek);
            Controls.Add(btnDodajDogodekNaNabor);
            Controls.Add(btnZapri);
            ResumeLayout(false);
            PerformLayout();
        }

        private void PrikaziDogodke()
        {
            lbDogodki.BeginUpdate();
            lbDogodki.Items.Clear();

            foreach (string dogodek in dogodki)
            {
                lbDogodki.Items.Add(dogodek);
            }

            lbDogodki.EndUpdate();
            PosodobiStanjeGumbov();
        }

        private void LbDogodki_SelectedIndexChanged(object sender, EventArgs e)
        {
            PosodobiStanjeGumbov();
        }

        private void PosodobiStanjeGumbov()
        {
            btnIgrajDogodek.Enabled = lbDogodki.SelectedIndex >= 0;
        }

        private void BtnDodajDogodekNaNabor_Click(object sender, EventArgs e)
        {
            using (DodajDogodek dodajDogodek = new DodajDogodek(dogodki))
            {
                if (dodajDogodek.ShowDialog(this) == DialogResult.OK)
                {
                    PrikaziDogodke();
                }
            }
        }

        private void BtnIgrajDogodek_Click(object sender, EventArgs e)
        {
            if (lbDogodki.SelectedItem == null)
            {
                return;
            }

            using (IzbranPar izbranPar = new IzbranPar(lbDogodki.SelectedItem.ToString(), dodajNaStavniListek))
            {
                izbranPar.ShowDialog(this);
            }
        }

        private void BtnZapri_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
