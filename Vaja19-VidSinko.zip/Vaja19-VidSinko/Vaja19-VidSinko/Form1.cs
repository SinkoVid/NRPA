using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Vaja19_VidSinko
{
    public partial class Form1 : Form
    {
        const int steviloGob = 5;

        private readonly Random nakljucno = new Random();
        private List<Point> seznamTock = new List<Point>();
        private List<Label> seznamGob;
        private Label pobiralecGob;
        private int vrednostPobranihGob = 0;
        private double maxCas = 10;
        private double trenutniCas = 0;
        private bool igraSeJeZacela = false;
        private bool igraJeKoncana = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            novaIgra();
        }

        private void novaIgra()
        {
            casovnik.Stop();

            foreach (Label goba in seznamGob ?? new List<Label>())
            {
                Controls.Remove(goba);
                goba.Dispose();
            }

            if (pobiralecGob != null)
            {
                Controls.Remove(pobiralecGob);
                pobiralecGob.Dispose();
            }

            seznamTock = new List<Point>();
            seznamGob = new List<Label>();
            vrednostPobranihGob = 0;
            trenutniCas = 0;
            igraSeJeZacela = false;
            igraJeKoncana = false;

            pripraviTocke();
            ustvariGobe();
            ustvariPobiralcaGob();
            osveziTocke();

            statusBar_lblOdstevanje.Text = "Čakam na začetek..";
            statusBar_lblCrta.Text = "|";
        }

        private void pripraviTocke()
        {
            while (seznamTock.Count < steviloGob)
            {
                Point novaTocka = nakljucnaTocka();

                if (!seznamTock.Contains(novaTocka))
                {
                    seznamTock.Add(novaTocka);
                }
            }
        }

        private Point nakljucnaTocka()
        {
            int x = nakljucno.Next(2, 27) * 10;
            int y = nakljucno.Next(2, 25) * 10;

            return new Point(x, y);
        }

        private void ustvariGobe()
        {
            for (int i = 0; i < steviloGob; i++)
            {
                Label mojaLabela = ustvariLabeloIzPredloge(predlogaGoba);
                mojaLabela.Location = seznamTock[i];
                mojaLabela.Tag = (i + 1).ToString();

                seznamGob.Add(mojaLabela);
                Controls.Add(mojaLabela);
                mojaLabela.BringToFront();
            }
        }

        private void ustvariPobiralcaGob()
        {
            Point lokacijaPobiralca;

            do
            {
                lokacijaPobiralca = nakljucnaTocka();
            }
            while (seznamTock.Contains(lokacijaPobiralca));

            pobiralecGob = ustvariLabeloIzPredloge(predlogaPobiralec);
            pobiralecGob.Location = lokacijaPobiralca;

            Controls.Add(pobiralecGob);
            pobiralecGob.BringToFront();
        }

        private Label ustvariLabeloIzPredloge(Label predloga)
        {
            return new Label
            {
                AutoSize = predloga.AutoSize,
                BackColor = predloga.BackColor,
                BorderStyle = predloga.BorderStyle,
                Font = predloga.Font,
                ForeColor = predloga.ForeColor,
                Margin = predloga.Margin,
                Padding = predloga.Padding,
                Size = predloga.Size,
                Text = predloga.Text,
                Visible = true
            };
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (igraJeKoncana || pobiralecGob == null)
            {
                return;
            }

            if (e.KeyCode != Keys.Up && e.KeyCode != Keys.Down &&
                e.KeyCode != Keys.Left && e.KeyCode != Keys.Right)
            {
                return;
            }

            if (!igraSeJeZacela)
            {
                igraSeJeZacela = true;
                casovnik.Start();
            }

            Point novaLokacija = pobiralecGob.Location;

            switch (e.KeyCode)
            {
                case Keys.Up:
                    novaLokacija.Y -= 10;
                    break;
                case Keys.Down:
                    novaLokacija.Y += 10;
                    break;
                case Keys.Left:
                    novaLokacija.X -= 10;
                    break;
                case Keys.Right:
                    novaLokacija.X += 10;
                    break;
            }

            pobiralecGob.Location = popraviRobove(novaLokacija);
            preveriAliJePobranaGoba();
        }

        private Point popraviRobove(Point lokacija)
        {
            const int najmanjsaX = 20;
            const int najvecjaX = 260;
            const int najmanjsaY = 20;
            const int najvecjaY = 240;

            if (lokacija.X < najmanjsaX)
            {
                lokacija.X = najvecjaX;
            }
            else if (lokacija.X > najvecjaX)
            {
                lokacija.X = najmanjsaX;
            }

            if (lokacija.Y < najmanjsaY)
            {
                lokacija.Y = najvecjaY;
            }
            else if (lokacija.Y > najvecjaY)
            {
                lokacija.Y = najmanjsaY;
            }

            return lokacija;
        }

        private void preveriAliJePobranaGoba()
        {
            Label pobranaGoba = seznamGob.FirstOrDefault(goba => goba.Location == pobiralecGob.Location);

            if (pobranaGoba == null)
            {
                return;
            }

            vrednostPobranihGob += Convert.ToInt32(pobranaGoba.Tag);
            seznamGob.Remove(pobranaGoba);
            Controls.Remove(pobranaGoba);
            pobranaGoba.Dispose();
            osveziTocke();

            if (seznamGob.Count == 0)
            {
                koncajIgro($"Bravo, pobrali ste vse gobe! Dosegli ste {vrednostPobranihGob} točk. Igro ste končali v {trenutniCas:0.0} s.");
            }
        }

        private void osveziTocke()
        {
            statusBar_lblTocke.Text = $"Točke pobranih gob: {vrednostPobranihGob}";
        }

        private void casovnik_Tick(object sender, EventArgs e)
        {
            if (trenutniCas < maxCas)
            {
                trenutniCas += 0.1;
                double preostaliCas = Math.Max(0, maxCas - trenutniCas);
                statusBar_lblOdstevanje.Text = $"Na voljo še: {preostaliCas:0.0} s";
            }

            if (trenutniCas >= maxCas)
            {
                koncajIgro($"Igre je konec. Potekel je vaš čas. Dosegli ste {vrednostPobranihGob} točk.");
            }
        }

        private void koncajIgro(string sporocilo)
        {
            if (igraJeKoncana)
            {
                return;
            }

            igraJeKoncana = true;
            casovnik.Stop();

            MessageBox.Show(
                sporocilo,
                "Konec igre",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            DialogResult odgovor = MessageBox.Show(
                "Bi želeli igrati novo igro?",
                "Nova igra",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (odgovor == DialogResult.Yes)
            {
                novaIgra();
            }
            else
            {
                Close();
            }
        }
    }
}
