namespace Vaja19_VidSinko
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.statusBar = new System.Windows.Forms.StatusStrip();
            this.statusBar_lblOdstevanje = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusBar_lblCrta = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusBar_lblTocke = new System.Windows.Forms.ToolStripStatusLabel();
            this.casovnik = new System.Windows.Forms.Timer(this.components);
            this.predlogaGoba = new System.Windows.Forms.Label();
            this.predlogaPobiralec = new System.Windows.Forms.Label();
            this.gozdPanel = new System.Windows.Forms.Panel();
            this.statusBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusBar
            // 
            this.statusBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(246)))));
            this.statusBar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.statusBar.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.statusBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusBar_lblOdstevanje,
            this.statusBar_lblCrta,
            this.statusBar_lblTocke});
            this.statusBar.Location = new System.Drawing.Point(0, 300);
            this.statusBar.Name = "statusBar";
            this.statusBar.Size = new System.Drawing.Size(300, 22);
            this.statusBar.SizingGrip = false;
            this.statusBar.TabIndex = 0;
            // 
            // statusBar_lblOdstevanje
            // 
            this.statusBar_lblOdstevanje.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(83)))), ((int)(((byte)(57)))));
            this.statusBar_lblOdstevanje.Name = "statusBar_lblOdstevanje";
            this.statusBar_lblOdstevanje.Padding = new System.Windows.Forms.Padding(5, 0, 2, 0);
            this.statusBar_lblOdstevanje.Size = new System.Drawing.Size(119, 17);
            this.statusBar_lblOdstevanje.Text = "Čakam na začetek..";
            // 
            // statusBar_lblCrta
            // 
            this.statusBar_lblCrta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(157)))), ((int)(((byte)(132)))));
            this.statusBar_lblCrta.Name = "statusBar_lblCrta";
            this.statusBar_lblCrta.Size = new System.Drawing.Size(10, 17);
            this.statusBar_lblCrta.Text = "|";
            // 
            // statusBar_lblTocke
            // 
            this.statusBar_lblTocke.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.statusBar_lblTocke.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(62)))), ((int)(((byte)(33)))));
            this.statusBar_lblTocke.Name = "statusBar_lblTocke";
            this.statusBar_lblTocke.Size = new System.Drawing.Size(145, 17);
            this.statusBar_lblTocke.Text = "Točke pobranih gob: 0";
            // 
            // casovnik
            // 
            this.casovnik.Interval = 100;
            this.casovnik.Tick += new System.EventHandler(this.casovnik_Tick);
            // 
            // predlogaGoba
            // 
            this.predlogaGoba.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(126)))), ((int)(((byte)(42)))));
            this.predlogaGoba.Location = new System.Drawing.Point(-20, -20);
            this.predlogaGoba.Name = "predlogaGoba";
            this.predlogaGoba.Size = new System.Drawing.Size(10, 10);
            this.predlogaGoba.TabIndex = 1;
            this.predlogaGoba.Visible = false;
            // 
            // predlogaPobiralec
            // 
            this.predlogaPobiralec.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            this.predlogaPobiralec.Location = new System.Drawing.Point(-20, -20);
            this.predlogaPobiralec.Name = "predlogaPobiralec";
            this.predlogaPobiralec.Size = new System.Drawing.Size(10, 10);
            this.predlogaPobiralec.TabIndex = 2;
            this.predlogaPobiralec.Visible = false;
            // 
            // gozdPanel
            // 
            this.gozdPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(238)))), ((int)(((byte)(222)))));
            this.gozdPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gozdPanel.Location = new System.Drawing.Point(10, 10);
            this.gozdPanel.Name = "gozdPanel";
            this.gozdPanel.Size = new System.Drawing.Size(280, 280);
            this.gozdPanel.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(230)))), ((int)(((byte)(211)))));
            this.ClientSize = new System.Drawing.Size(300, 322);
            this.Controls.Add(this.predlogaPobiralec);
            this.Controls.Add(this.predlogaGoba);
            this.Controls.Add(this.gozdPanel);
            this.Controls.Add(this.statusBar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hitrostno nabiranje";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.statusBar.ResumeLayout(false);
            this.statusBar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusBar;
        private System.Windows.Forms.ToolStripStatusLabel statusBar_lblOdstevanje;
        private System.Windows.Forms.ToolStripStatusLabel statusBar_lblCrta;
        private System.Windows.Forms.ToolStripStatusLabel statusBar_lblTocke;
        private System.Windows.Forms.Timer casovnik;
        private System.Windows.Forms.Label predlogaGoba;
        private System.Windows.Forms.Label predlogaPobiralec;
        private System.Windows.Forms.Panel gozdPanel;
    }
}
