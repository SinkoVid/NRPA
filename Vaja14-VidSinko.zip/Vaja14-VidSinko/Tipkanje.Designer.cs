﻿namespace Vaja14_VidSinko
{
    partial class Tipkanje
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tipkanje));
            this.lblBeseda = new System.Windows.Forms.Label();
            this.lblTipkam = new System.Windows.Forms.Label();
            this.lblNova = new System.Windows.Forms.Label();
            this.btnNadaljuj = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.slblSTvse = new System.Windows.Forms.ToolStripStatusLabel();
            this.slblSepparator1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.slblSTprav = new System.Windows.Forms.ToolStripStatusLabel();
            this.slblSepparator2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.slblSTnap = new System.Windows.Forms.ToolStripStatusLabel();
            this.slblSepparator3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.slblUspesnost = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.datotekaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ponastaviStatistikoTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.izhodTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.pomocTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.oProgramuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.avtorTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.checkboxAuto = new System.Windows.Forms.CheckBox();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.statusStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblBeseda
            // 
            this.lblBeseda.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.lblBeseda.Font = new System.Drawing.Font("Consolas", 20F);
            this.lblBeseda.Location = new System.Drawing.Point(12, 37);
            this.lblBeseda.Name = "lblBeseda";
            this.lblBeseda.Size = new System.Drawing.Size(460, 53);
            this.lblBeseda.TabIndex = 0;
            this.lblBeseda.Text = "beseda";
            this.lblBeseda.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTipkam
            // 
            this.lblTipkam.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.lblTipkam.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblTipkam.Font = new System.Drawing.Font("Consolas", 20F);
            this.lblTipkam.Location = new System.Drawing.Point(12, 101);
            this.lblTipkam.Name = "lblTipkam";
            this.lblTipkam.Size = new System.Drawing.Size(460, 53);
            this.lblTipkam.TabIndex = 1;
            this.lblTipkam.Text = "tipkam";
            this.lblTipkam.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNova
            // 
            this.lblNova.AutoSize = true;
            this.lblNova.Font = new System.Drawing.Font("Consolas", 14F);
            this.lblNova.Location = new System.Drawing.Point(12, 205);
            this.lblNova.Name = "lblNova";
            this.lblNova.Size = new System.Drawing.Size(210, 22);
            this.lblNova.TabIndex = 2;
            this.lblNova.Text = "Nova beseda čez: X s";
            // 
            // btnNadaljuj
            // 
            this.btnNadaljuj.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnNadaljuj.Location = new System.Drawing.Point(346, 166);
            this.btnNadaljuj.Name = "btnNadaljuj";
            this.btnNadaljuj.Size = new System.Drawing.Size(126, 34);
            this.btnNadaljuj.TabIndex = 3;
            this.btnNadaljuj.Text = "Nadaljuj";
            this.btnNadaljuj.UseVisualStyleBackColor = true;
            this.btnNadaljuj.Click += new System.EventHandler(this.btnNadaljuj_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Font = new System.Drawing.Font("Consolas", 8F);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.slblSTvse,
            this.slblSepparator1,
            this.slblSTprav,
            this.slblSepparator2,
            this.slblSTnap,
            this.slblSepparator3,
            this.slblUspesnost});
            this.statusStrip1.Location = new System.Drawing.Point(0, 259);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(484, 22);
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // slblSTvse
            // 
            this.slblSTvse.Name = "slblSTvse";
            this.slblSTvse.Size = new System.Drawing.Size(79, 17);
            this.slblSTvse.Text = "Št. besed: 0";
            // 
            // slblSepparator1
            // 
            this.slblSepparator1.Name = "slblSepparator1";
            this.slblSepparator1.Size = new System.Drawing.Size(13, 17);
            this.slblSepparator1.Text = "|";
            // 
            // slblSTprav
            // 
            this.slblSTprav.Name = "slblSTprav";
            this.slblSTprav.Size = new System.Drawing.Size(103, 17);
            this.slblSTprav.Text = "Št. pravilnih: 0";
            // 
            // slblSepparator2
            // 
            this.slblSepparator2.Name = "slblSepparator2";
            this.slblSepparator2.Size = new System.Drawing.Size(13, 17);
            this.slblSepparator2.Text = "|";
            // 
            // slblSTnap
            // 
            this.slblSTnap.Name = "slblSTnap";
            this.slblSTnap.Size = new System.Drawing.Size(97, 17);
            this.slblSTnap.Text = "Št. napačnih: 0";
            // 
            // slblSepparator3
            // 
            this.slblSepparator3.Name = "slblSepparator3";
            this.slblSepparator3.Size = new System.Drawing.Size(13, 17);
            this.slblSepparator3.Text = "|";
            // 
            // slblUspesnost
            // 
            this.slblUspesnost.Name = "slblUspesnost";
            this.slblUspesnost.Size = new System.Drawing.Size(85, 17);
            this.slblUspesnost.Text = "Uspešnost: 0%";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.datotekaToolStripMenuItem,
            this.pomocTSMI});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(484, 24);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // datotekaToolStripMenuItem
            // 
            this.datotekaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ponastaviStatistikoTSMI,
            this.izhodTSMI});
            this.datotekaToolStripMenuItem.Name = "datotekaToolStripMenuItem";
            this.datotekaToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.datotekaToolStripMenuItem.Text = "Datoteka";
            // 
            // ponastaviStatistikoTSMI
            // 
            this.ponastaviStatistikoTSMI.Image = global::Vaja14_VidSinko.Properties.Resources.reset;
            this.ponastaviStatistikoTSMI.Name = "ponastaviStatistikoTSMI";
            this.ponastaviStatistikoTSMI.Size = new System.Drawing.Size(175, 22);
            this.ponastaviStatistikoTSMI.Text = "Ponastavi statistiko";
            this.ponastaviStatistikoTSMI.Click += new System.EventHandler(this.ponastaviStatistikoTSMI_Click);
            // 
            // izhodTSMI
            // 
            this.izhodTSMI.Image = global::Vaja14_VidSinko.Properties.Resources.exit;
            this.izhodTSMI.Name = "izhodTSMI";
            this.izhodTSMI.Size = new System.Drawing.Size(175, 22);
            this.izhodTSMI.Text = "Izhod";
            this.izhodTSMI.Click += new System.EventHandler(this.izhodTSMI_Click);
            // 
            // pomocTSMI
            // 
            this.pomocTSMI.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oProgramuToolStripMenuItem,
            this.avtorTSMI});
            this.pomocTSMI.Name = "pomocTSMI";
            this.pomocTSMI.Size = new System.Drawing.Size(57, 20);
            this.pomocTSMI.Text = "Pomoč";
            // 
            // oProgramuToolStripMenuItem
            // 
            this.oProgramuToolStripMenuItem.Image = global::Vaja14_VidSinko.Properties.Resources.info;
            this.oProgramuToolStripMenuItem.Name = "oProgramuToolStripMenuItem";
            this.oProgramuToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.oProgramuToolStripMenuItem.Text = "O programu";
            this.oProgramuToolStripMenuItem.Click += new System.EventHandler(this.oProgramuToolStripMenuItem_Click);
            // 
            // avtorTSMI
            // 
            this.avtorTSMI.Image = global::Vaja14_VidSinko.Properties.Resources.user;
            this.avtorTSMI.Name = "avtorTSMI";
            this.avtorTSMI.Size = new System.Drawing.Size(139, 22);
            this.avtorTSMI.Text = "Avtor";
            this.avtorTSMI.Click += new System.EventHandler(this.avtorTSMI_Click);
            // 
            // checkboxAuto
            // 
            this.checkboxAuto.AutoSize = true;
            this.checkboxAuto.Checked = true;
            this.checkboxAuto.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkboxAuto.Location = new System.Drawing.Point(350, 12);
            this.checkboxAuto.Name = "checkboxAuto";
            this.checkboxAuto.Size = new System.Drawing.Size(122, 17);
            this.checkboxAuto.TabIndex = 6;
            this.checkboxAuto.Text = "Nadaljuj avtomatsko";
            this.checkboxAuto.UseVisualStyleBackColor = true;
            this.checkboxAuto.CheckedChanged += new System.EventHandler(this.checkboxAuto_CheckedChanged);
            // 
            // progressBar
            // 
            this.progressBar.BackColor = System.Drawing.SystemColors.Control;
            this.progressBar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.progressBar.ForeColor = System.Drawing.Color.Red;
            this.progressBar.Location = new System.Drawing.Point(0, 245);
            this.progressBar.Maximum = 1000;
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(484, 14);
            this.progressBar.Step = 100;
            this.progressBar.TabIndex = 7;
            this.progressBar.Value = 1000;
            // 
            // Tipkanje
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 281);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.checkboxAuto);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.btnNadaljuj);
            this.Controls.Add(this.lblNova);
            this.Controls.Add(this.lblTipkam);
            this.Controls.Add(this.lblBeseda);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Tipkanje";
            this.Text = "Tipkanje";
            this.Load += new System.EventHandler(this.Tipkanje_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Tipkanje_KeyPress);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBeseda;
        private System.Windows.Forms.Label lblTipkam;
        private System.Windows.Forms.Label lblNova;
        private System.Windows.Forms.Button btnNadaljuj;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel slblSTvse;
        private System.Windows.Forms.ToolStripStatusLabel slblSepparator1;
        private System.Windows.Forms.ToolStripStatusLabel slblSTprav;
        private System.Windows.Forms.ToolStripStatusLabel slblSepparator2;
        private System.Windows.Forms.ToolStripStatusLabel slblSTnap;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem datotekaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ponastaviStatistikoTSMI;
        private System.Windows.Forms.ToolStripMenuItem izhodTSMI;
        private System.Windows.Forms.CheckBox checkboxAuto;
        private System.Windows.Forms.ToolStripMenuItem pomocTSMI;
        private System.Windows.Forms.ToolStripMenuItem oProgramuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem avtorTSMI;
        private System.Windows.Forms.ToolStripStatusLabel slblSepparator3;
        private System.Windows.Forms.ToolStripStatusLabel slblUspesnost;
        private System.Windows.Forms.ProgressBar progressBar;
    }
}

