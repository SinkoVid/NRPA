﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vaja14_VidSinko
{
    public partial class Tipkanje : Form
    {
        #region Spremenljivke + konstruktor

        private enum StanjeIgre  // za lazje upravljanje stanja / timer
        {
            PredZacetkom,
            Tipkanje,
            PoKoncu
        }
        private StanjeIgre trenutnoStanje = StanjeIgre.PredZacetkom;

        Timer timer = new Timer();

        private int steviloPoskusov = 0;
        private int steviloPravilnih = 0;
        private int steviloNapacnih = 0;
        private int steviloVseh = 0;

        private string trenutnaBeseda = ""; // trenutna beseda, ki jo mora uporabnik napisati
        private int indexCrke = 0; // index trenutne črke iz besede
        private int preverjanje = 1; // vmesno preverjanje - 0=napačno, 1=default, 2=pravilno (cela beseda)

        private float preostaliCas;

        Random random = new Random();

        public List<string> listBesede = new List<string>()
        { 
            "programiranje", "csharp", "WindoWs", "tipKanje", "VAja", 
            "c#", "67", "Nekajnekaj", "BeSeda", "monkeytype", "day", 
            "nIght", "keYboard", "mouSe", "laptop", "monitor", "miza", 
            "stoLec", "okNo", "VraTa"
        };
        
        public Tipkanje()
        {
            InitializeComponent();
            this.KeyPreview = true; // fix za problem buttonPress -> nemres tipkati (button je v focusi)
            timer.Interval = 100; // nastavi interval timerja (100 milisekund) - za update labela "Tipkam..."
            timer.Tick += Timer_Tick; // dodaj event handler za timer
        }
        #endregion

        #region Load
        private void Tipkanje_Load(object sender, EventArgs e)
        {
            lblNova.Visible = false;
            lblTipkam.Visible = false;
            lblTipkam.Text = "";
 
            RandomBeseda();
            Preverjanje(); // nastavi st. vseh poskusov takoj ko se naloži form (zacne z 1)
            btnNadaljuj.Enabled = false;
            checkboxAuto.Checked = true; 
            btnNadaljuj.Visible = false;
        }
        #endregion

        private void checkboxAuto_CheckedChanged(object sender, EventArgs e) // za debug - avtomatsko nadaljevanje (skriti button Nadaljuj)
        {
            if (checkboxAuto.Checked)
            {
                btnNadaljuj.Visible = false;
            }
            else
            {
                btnNadaljuj.Visible = true;
            }
        }



        #region Potek naloge - Funkcije (Random, Preverjanje, Nadaljuj, Keypress)

        private void RandomBeseda() // random beseda iz lista
        {
            int indexBesede = this.random.Next(listBesede.Count);
            lblBeseda.Text = listBesede[indexBesede];
            this.trenutnaBeseda = listBesede[indexBesede];
        }

        private void Nadaljuj()
        {
            // resetiraje raznih stvari za naslednjo besedo
            this.indexCrke = 0;
            this.preverjanje = 1;
            RandomBeseda();
            Preverjanje(); // nastavi st. vseh poskusov takoj ko kliknemo nadaljuj
            lblBeseda.ForeColor = Color.Black;
            lblTipkam.Text = "";
            btnNadaljuj.Enabled = false;
            lblTipkam.Focus();
            lblTipkam.Visible = false;
            lblNova.Visible = false;
            checkboxAuto.Enabled = true;

            trenutnoStanje = StanjeIgre.PredZacetkom; // resetiraj stanje igre
        }

        private void btnNadaljuj_Click(object sender, EventArgs e) 
        {        
            Nadaljuj();
        }

        private void Preverjanje() // preverjanje pravilnosti
        {
            btnNadaljuj.Enabled = true;

            if (this.preverjanje == 0) // napačno
            {
                lblBeseda.ForeColor = Color.Red;
                steviloNapacnih++;
                slblSTnap.Text = "Št. napačnih: " + steviloNapacnih;
                this.steviloVseh = steviloPravilnih + steviloNapacnih;
                slblUspesnost.Text = "Uspešnost: " + Math.Round(steviloPravilnih / (float)steviloVseh * 100, 2) + "%";

                timer.Stop();
                //nadaljevanje - nova beseda
                checkboxAuto.Enabled = false;
                if (checkboxAuto.Checked)
                {
                    ZacniTimerPoKoncu();
                }
                
            }

            else if (this.preverjanje == 1) // default
            {
                steviloPoskusov++;
                slblSTvse.Text = "Št. besed: " + steviloPoskusov;         
            }

            else if (this.preverjanje == 2) // pravilno
            {
                lblBeseda.ForeColor = Color.Green;
                steviloPravilnih++;
                slblSTprav.Text = "Št. pravilnih: " + steviloPravilnih;
                this.steviloVseh = steviloPravilnih + steviloNapacnih;
                slblUspesnost.Text = "Uspešnost: " + Math.Round(steviloPravilnih / (float)steviloVseh * 100, 2) + "%";

                timer.Stop();
                //nadaljevanje - nova beseda
                checkboxAuto.Enabled = false;
                if (checkboxAuto.Checked)
                {
                    ZacniTimerPoKoncu();
                }               
            }
        }

        private void Timer_Tick(object sender, EventArgs e) // timer tick event - ko je čas 0
        {
            preostaliCas -= timer.Interval;
            progressBar.Value = (int)preostaliCas;

            if (preostaliCas < 600) // če je čas manjši od 30% -> rdeča barva
            {
                progressBar.ForeColor = Color.Red;
            }

            lblNova.Text = "Preostali čas: " + (this.preostaliCas / 1000.0) + " sekund";

            if (preostaliCas <= 0)
            {
                timer.Stop();
               
                if (trenutnoStanje == StanjeIgre.Tipkanje)
                {                   
                    if (preverjanje != 2) // če user ne vpiše prave besede v času -> napačno
                    {
                        preverjanje = 0;
                        Preverjanje();
                    }
                    if (checkboxAuto.Checked)
                    {
                        ZacniTimerPoKoncu();
                    }
                }
                else if (trenutnoStanje == StanjeIgre.PoKoncu)
                {
                    if (checkboxAuto.Checked)
                    {
                        Nadaljuj();
                    }
                    trenutnoStanje = StanjeIgre.PredZacetkom; // resetiraj stanje igre
                }

            }
        }

        private void ZacniTimerPoKoncu()
        {
            this.preostaliCas = 2000;
            progressBar.Maximum = (int)this.preostaliCas;
            progressBar.Value = (int)this.preostaliCas;
            trenutnoStanje = StanjeIgre.PoKoncu;
            timer.Start();
        }

        private void Tipkanje_KeyPress(object sender, KeyPressEventArgs e) // Keypress
        {
            lblNova.Visible = true;
            lblTipkam.Visible = true;

            if (this.indexCrke == 0 && !timer.Enabled && trenutnoStanje == StanjeIgre.PredZacetkom)  // ko user začne tipkati
            {
                trenutnoStanje = StanjeIgre.Tipkanje;
                this.preostaliCas = this.trenutnaBeseda.Length * 300; // 300ms na črko
                progressBar.Maximum = (int)this.preostaliCas;
                progressBar.Value = (int)this.preostaliCas;
                lblNova.Text = "Nova beseda čez: " + (this.preostaliCas / 1000.0) + " sekund";          
                timer.Start();
            }
            

            if (char.IsControl(e.KeyChar)) // kontrolni znaki (enter, backspace...) -> problem (crash)
            {
                if (preverjanje != 1)
                    return;

                this.preverjanje = 0;
                Preverjanje();
                return;
            }

            if (indexCrke >= trenutnaBeseda.Length || preverjanje == 0) // ne pusti tipkati ko se zmotimo/pravilno
                return;

            lblTipkam.Text += e.KeyChar;

            if (e.KeyChar != this.trenutnaBeseda[this.indexCrke])
            {
                this.preverjanje = 0; // napačno
                Preverjanje();
            }
            else
            {
                this.indexCrke++; // premakni se na naslednjo črko

                if (lblBeseda.Text == lblTipkam.Text)
                {
                    this.preverjanje = 2; // pravilno (cela beseda)
                    Preverjanje();
                }
            }

        }
        #endregion


        #region MenuStrip
        private void ponastaviStatistikoTSMI_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Ali ste prepričani, da želite ponastaviti statistiko?", "Ponastavi statistiko", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                steviloPoskusov = 0;
                steviloPravilnih = 0;
                steviloNapacnih = 0;
                steviloVseh = 0;
                slblSTvse.Text = "Št. besed: 0";
                slblSTprav.Text = "Št. pravilnih: 0";
                slblSTnap.Text = "Št. napačnih: 0";
                slblUspesnost.Text = "Uspešnost: 0%";

                btnNadaljuj.Enabled = true;
                Nadaljuj(); // resetiraj nalogo
            }
        }

        private void izhodTSMI_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Ali ste prepričani, da želite zapustiti aplikacijo?", "Izhod", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void oProgramuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Tipkanje - igra za izboljšanje tipkarskih sposobnosti.\n\n" +
                "Navodila:\n\n" +
                "- Ko se prikaže beseda, jo poskušajte čim hitreje in pravilno vtipkati.\n" +
                "- Imate 5 sekund časa za vsako besedo.\n" +
                "- Če vtipkate napačno črko ali ne dokončate besede v času, se šteje kot napačen poskus.\n" +
                "- Statistika se vodi glede na število poskusov, pravilnih in napačnih vnosov.\n\n" +
                "Uživajte v igri!", "O programu", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void avtorTSMI_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Avtor: Vid Sinko (4R3)\n\n" + "Datum Izida: 20.2.2026\n\n", "O avtorju", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        #endregion

    }
}
