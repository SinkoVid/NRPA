﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vaja15_VidSinko
{
    public partial class Form1 : Form
    {
        private enum Stanje
        {
            PredZacetkom,
            Igra,
            Konec
        }
        private Stanje stanjeIgre = Stanje.PredZacetkom;
        private int randomNumber = 0;
        private int pravilnih = 0;

        private DateTime casZacetka;
        private TimeSpan casIgre;

        Random random = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            OnemogociVseKvadratke();
        }

        private void Kvadratek_Hover(object sender, EventArgs e)
        {
                PictureBox kvadratek = (PictureBox)sender;                              
                kvadratek.Cursor = Cursors.Hand;            
        }


        private void KlikniNaKvadratek(object sender, EventArgs e)
        {
            if (sender is PictureBox)
            {
                PictureBox kvadratek = (PictureBox)sender;

                if (this.stanjeIgre == Stanje.PredZacetkom) { }

                else if (this.stanjeIgre == Stanje.Igra)
                {
                    if (Convert.ToInt32(kvadratek.Tag) == this.randomNumber)
                    {
                        this.pravilnih++;
                    }
                    else
                    {
                        MessageBox.Show("Napačen kvadratek! Igre je konec po: " + KonecIgreCas() 
                            + "s.\nPravilno ste kliknili na " + this.pravilnih + " kvadratkov.",
                            "Konec igre", MessageBoxButtons.OK, MessageBoxIcon.Error);

                        Reset();
                        return;
                    }
                    if (this.pravilnih == 15)
                    {
                        MessageBox.Show("Čestitke! Zmagali ste! Nalogo ste opravili v:\n" + KonecIgreCas() + "s.", "Konec igre", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Reset();
                        return;
                    }
                    OmogociInNastaviNakljucni();
                }
            }
            else if (sender is Button)
            {
                if (this.stanjeIgre == Stanje.PredZacetkom)
                {
                    this.stanjeIgre = Stanje.Igra;
                    btnZacni.Enabled = false;
                    MessageBox.Show("Igra se je začela!", "Obvestilo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.casZacetka = DateTime.Now;
                    this.OmogociInNastaviNakljucni();
                }
            }
            
        }


        private string KonecIgreCas()
        {
            this.stanjeIgre = Stanje.Konec;
            this.casIgre = DateTime.Now - this.casZacetka;

            return Math.Round(this.casIgre.TotalSeconds, 2).ToString();
        }

        #region Reset
        private void Reset()
        {
            OnemogociVseKvadratke();
            btnZacni.Enabled = true;
            this.pravilnih = 0;
            this.stanjeIgre = Stanje.PredZacetkom;
        }

        private void OnemogociVseKvadratke()
        {
            foreach (Control pbox in this.Controls)
            {
                if (pbox is PictureBox)
                {
                    pbox.Enabled = false;
                    pbox.BackColor = Color.MediumBlue;
                }
            }
        }
        #endregion

        private void OmogociInNastaviNakljucni()
        {
            int randomNumber = 0;
            
            do {
                randomNumber = random.Next(1, 13); // 1–12
            } while (randomNumber == this.randomNumber);

            this.randomNumber = randomNumber;

            foreach (Control pbox in this.Controls)
            {
                if (pbox is PictureBox)
                {
                    pbox.Enabled = true;
                    //pbox.Enabled = pbox.Tag.ToString() == randomNumber.ToString();
                    if (Convert.ToInt32(pbox.Tag) == this.randomNumber)
                    {
                        pbox.BackColor = Color.Red;
                    }
                    else
                    {
                        pbox.BackColor = Color.MediumBlue;
                    }
                }
            }
        }
    }
}
