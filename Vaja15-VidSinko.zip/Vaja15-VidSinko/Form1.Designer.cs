﻿namespace Vaja15_VidSinko
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pBox1 = new System.Windows.Forms.PictureBox();
            this.pBox2 = new System.Windows.Forms.PictureBox();
            this.pBox3 = new System.Windows.Forms.PictureBox();
            this.pBox6 = new System.Windows.Forms.PictureBox();
            this.pBox5 = new System.Windows.Forms.PictureBox();
            this.pBox4 = new System.Windows.Forms.PictureBox();
            this.pBox12 = new System.Windows.Forms.PictureBox();
            this.pBox11 = new System.Windows.Forms.PictureBox();
            this.pBox10 = new System.Windows.Forms.PictureBox();
            this.pBox9 = new System.Windows.Forms.PictureBox();
            this.pBox8 = new System.Windows.Forms.PictureBox();
            this.pBox7 = new System.Windows.Forms.PictureBox();
            this.btnZacni = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // pBox1
            // 
            this.pBox1.BackColor = System.Drawing.Color.MediumBlue;
            this.pBox1.Location = new System.Drawing.Point(12, 12);
            this.pBox1.Name = "pBox1";
            this.pBox1.Size = new System.Drawing.Size(65, 65);
            this.pBox1.TabIndex = 0;
            this.pBox1.TabStop = false;
            this.pBox1.Tag = "1";
            this.pBox1.Click += new System.EventHandler(this.KlikniNaKvadratek);
            this.pBox1.MouseHover += new System.EventHandler(this.Kvadratek_Hover);
            // 
            // pBox2
            // 
            this.pBox2.BackColor = System.Drawing.Color.MediumBlue;
            this.pBox2.Location = new System.Drawing.Point(83, 12);
            this.pBox2.Name = "pBox2";
            this.pBox2.Size = new System.Drawing.Size(65, 65);
            this.pBox2.TabIndex = 1;
            this.pBox2.TabStop = false;
            this.pBox2.Tag = "2";
            this.pBox2.Click += new System.EventHandler(this.KlikniNaKvadratek);
            this.pBox2.MouseHover += new System.EventHandler(this.Kvadratek_Hover);
            // 
            // pBox3
            // 
            this.pBox3.BackColor = System.Drawing.Color.MediumBlue;
            this.pBox3.Location = new System.Drawing.Point(154, 12);
            this.pBox3.Name = "pBox3";
            this.pBox3.Size = new System.Drawing.Size(65, 65);
            this.pBox3.TabIndex = 2;
            this.pBox3.TabStop = false;
            this.pBox3.Tag = "3";
            this.pBox3.Click += new System.EventHandler(this.KlikniNaKvadratek);
            this.pBox3.MouseHover += new System.EventHandler(this.Kvadratek_Hover);
            // 
            // pBox6
            // 
            this.pBox6.BackColor = System.Drawing.Color.MediumBlue;
            this.pBox6.Location = new System.Drawing.Point(154, 83);
            this.pBox6.Name = "pBox6";
            this.pBox6.Size = new System.Drawing.Size(65, 65);
            this.pBox6.TabIndex = 5;
            this.pBox6.TabStop = false;
            this.pBox6.Tag = "6";
            this.pBox6.Click += new System.EventHandler(this.KlikniNaKvadratek);
            this.pBox6.MouseHover += new System.EventHandler(this.Kvadratek_Hover);
            // 
            // pBox5
            // 
            this.pBox5.BackColor = System.Drawing.Color.MediumBlue;
            this.pBox5.Location = new System.Drawing.Point(83, 83);
            this.pBox5.Name = "pBox5";
            this.pBox5.Size = new System.Drawing.Size(65, 65);
            this.pBox5.TabIndex = 4;
            this.pBox5.TabStop = false;
            this.pBox5.Tag = "5";
            this.pBox5.Click += new System.EventHandler(this.KlikniNaKvadratek);
            this.pBox5.MouseHover += new System.EventHandler(this.Kvadratek_Hover);
            // 
            // pBox4
            // 
            this.pBox4.BackColor = System.Drawing.Color.MediumBlue;
            this.pBox4.Location = new System.Drawing.Point(12, 83);
            this.pBox4.Name = "pBox4";
            this.pBox4.Size = new System.Drawing.Size(65, 65);
            this.pBox4.TabIndex = 3;
            this.pBox4.TabStop = false;
            this.pBox4.Tag = "4";
            this.pBox4.Click += new System.EventHandler(this.KlikniNaKvadratek);
            this.pBox4.MouseHover += new System.EventHandler(this.Kvadratek_Hover);
            // 
            // pBox12
            // 
            this.pBox12.BackColor = System.Drawing.Color.MediumBlue;
            this.pBox12.Location = new System.Drawing.Point(154, 225);
            this.pBox12.Name = "pBox12";
            this.pBox12.Size = new System.Drawing.Size(65, 65);
            this.pBox12.TabIndex = 11;
            this.pBox12.TabStop = false;
            this.pBox12.Tag = "12";
            this.pBox12.Click += new System.EventHandler(this.KlikniNaKvadratek);
            this.pBox12.MouseHover += new System.EventHandler(this.Kvadratek_Hover);
            // 
            // pBox11
            // 
            this.pBox11.BackColor = System.Drawing.Color.MediumBlue;
            this.pBox11.Location = new System.Drawing.Point(83, 225);
            this.pBox11.Name = "pBox11";
            this.pBox11.Size = new System.Drawing.Size(65, 65);
            this.pBox11.TabIndex = 10;
            this.pBox11.TabStop = false;
            this.pBox11.Tag = "11";
            this.pBox11.Click += new System.EventHandler(this.KlikniNaKvadratek);
            this.pBox11.MouseHover += new System.EventHandler(this.Kvadratek_Hover);
            // 
            // pBox10
            // 
            this.pBox10.BackColor = System.Drawing.Color.MediumBlue;
            this.pBox10.Location = new System.Drawing.Point(12, 225);
            this.pBox10.Name = "pBox10";
            this.pBox10.Size = new System.Drawing.Size(65, 65);
            this.pBox10.TabIndex = 9;
            this.pBox10.TabStop = false;
            this.pBox10.Tag = "10";
            this.pBox10.Click += new System.EventHandler(this.KlikniNaKvadratek);
            this.pBox10.MouseHover += new System.EventHandler(this.Kvadratek_Hover);
            // 
            // pBox9
            // 
            this.pBox9.BackColor = System.Drawing.Color.MediumBlue;
            this.pBox9.Location = new System.Drawing.Point(154, 154);
            this.pBox9.Name = "pBox9";
            this.pBox9.Size = new System.Drawing.Size(65, 65);
            this.pBox9.TabIndex = 8;
            this.pBox9.TabStop = false;
            this.pBox9.Tag = "9";
            this.pBox9.Click += new System.EventHandler(this.KlikniNaKvadratek);
            this.pBox9.MouseHover += new System.EventHandler(this.Kvadratek_Hover);
            // 
            // pBox8
            // 
            this.pBox8.BackColor = System.Drawing.Color.MediumBlue;
            this.pBox8.Location = new System.Drawing.Point(83, 154);
            this.pBox8.Name = "pBox8";
            this.pBox8.Size = new System.Drawing.Size(65, 65);
            this.pBox8.TabIndex = 7;
            this.pBox8.TabStop = false;
            this.pBox8.Tag = "8";
            this.pBox8.Click += new System.EventHandler(this.KlikniNaKvadratek);
            this.pBox8.MouseHover += new System.EventHandler(this.Kvadratek_Hover);
            // 
            // pBox7
            // 
            this.pBox7.BackColor = System.Drawing.Color.MediumBlue;
            this.pBox7.Location = new System.Drawing.Point(12, 154);
            this.pBox7.Name = "pBox7";
            this.pBox7.Size = new System.Drawing.Size(65, 65);
            this.pBox7.TabIndex = 6;
            this.pBox7.TabStop = false;
            this.pBox7.Tag = "7";
            this.pBox7.Click += new System.EventHandler(this.KlikniNaKvadratek);
            this.pBox7.MouseHover += new System.EventHandler(this.Kvadratek_Hover);
            // 
            // btnZacni
            // 
            this.btnZacni.Location = new System.Drawing.Point(12, 411);
            this.btnZacni.Name = "btnZacni";
            this.btnZacni.Size = new System.Drawing.Size(210, 27);
            this.btnZacni.TabIndex = 12;
            this.btnZacni.Text = "Začni igro";
            this.btnZacni.UseVisualStyleBackColor = true;
            this.btnZacni.Click += new System.EventHandler(this.KlikniNaKvadratek);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(234, 450);
            this.Controls.Add(this.btnZacni);
            this.Controls.Add(this.pBox12);
            this.Controls.Add(this.pBox11);
            this.Controls.Add(this.pBox10);
            this.Controls.Add(this.pBox9);
            this.Controls.Add(this.pBox8);
            this.Controls.Add(this.pBox7);
            this.Controls.Add(this.pBox6);
            this.Controls.Add(this.pBox5);
            this.Controls.Add(this.pBox4);
            this.Controls.Add(this.pBox3);
            this.Controls.Add(this.pBox2);
            this.Controls.Add(this.pBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Petnajstko";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox7)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pBox1;
        private System.Windows.Forms.PictureBox pBox2;
        private System.Windows.Forms.PictureBox pBox3;
        private System.Windows.Forms.PictureBox pBox6;
        private System.Windows.Forms.PictureBox pBox5;
        private System.Windows.Forms.PictureBox pBox4;
        private System.Windows.Forms.PictureBox pBox12;
        private System.Windows.Forms.PictureBox pBox11;
        private System.Windows.Forms.PictureBox pBox10;
        private System.Windows.Forms.PictureBox pBox9;
        private System.Windows.Forms.PictureBox pBox8;
        private System.Windows.Forms.PictureBox pBox7;
        private System.Windows.Forms.Button btnZacni;
    }
}

