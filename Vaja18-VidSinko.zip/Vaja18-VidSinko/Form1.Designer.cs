namespace Vaja18_VidSinko
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.mainLayout = new System.Windows.Forms.TableLayoutPanel();
            this.leftLayout = new System.Windows.Forms.TableLayoutPanel();
            this.headerPanel = new System.Windows.Forms.Panel();
            this.lblSubtitle = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.questionCard = new System.Windows.Forms.Panel();
            this.bottomActionsPanel = new System.Windows.Forms.Panel();
            this.btnRestart = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.lblFeedback = new System.Windows.Forms.Label();
            this.optionsPanel = new System.Windows.Forms.TableLayoutPanel();
            this.btnAnswer3 = new System.Windows.Forms.Button();
            this.btnAnswer2 = new System.Windows.Forms.Button();
            this.btnAnswer1 = new System.Windows.Forms.Button();
            this.btnAnswer4 = new System.Windows.Forms.Button();
            this.progressTrack = new System.Windows.Forms.Panel();
            this.progressFill = new System.Windows.Forms.Panel();
            this.lblQuestion = new System.Windows.Forms.Label();
            this.lblQuestionCounter = new System.Windows.Forms.Label();
            this.sidebarPanel = new System.Windows.Forms.Panel();
            this.helpPanel = new System.Windows.Forms.TableLayoutPanel();
            this.btnHelpAudience = new System.Windows.Forms.Button();
            this.btnHelpHint = new System.Windows.Forms.Button();
            this.btnHelpSkip = new System.Windows.Forms.Button();
            this.btnHelp5050 = new System.Windows.Forms.Button();
            this.lblHelpTitle = new System.Windows.Forms.Label();
            this.tipPanel = new System.Windows.Forms.Panel();
            this.lblTipBody = new System.Windows.Forms.Label();
            this.lblTipTitle = new System.Windows.Forms.Label();
            this.statsPanel = new System.Windows.Forms.Panel();
            this.lblRoundValue = new System.Windows.Forms.Label();
            this.lblRoundCaption = new System.Windows.Forms.Label();
            this.lblStreakValue = new System.Windows.Forms.Label();
            this.lblStreakCaption = new System.Windows.Forms.Label();
            this.lblScoreValue = new System.Windows.Forms.Label();
            this.lblScoreCaption = new System.Windows.Forms.Label();
            this.mainLayout.SuspendLayout();
            this.leftLayout.SuspendLayout();
            this.headerPanel.SuspendLayout();
            this.questionCard.SuspendLayout();
            this.bottomActionsPanel.SuspendLayout();
            this.optionsPanel.SuspendLayout();
            this.progressTrack.SuspendLayout();
            this.sidebarPanel.SuspendLayout();
            this.helpPanel.SuspendLayout();
            this.tipPanel.SuspendLayout();
            this.statsPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // mainLayout
            // 
            this.mainLayout.ColumnCount = 2;
            this.mainLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 68F));
            this.mainLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32F));
            this.mainLayout.Controls.Add(this.leftLayout, 0, 0);
            this.mainLayout.Controls.Add(this.sidebarPanel, 1, 0);
            this.mainLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainLayout.Location = new System.Drawing.Point(0, 0);
            this.mainLayout.Margin = new System.Windows.Forms.Padding(0);
            this.mainLayout.Name = "mainLayout";
            this.mainLayout.Padding = new System.Windows.Forms.Padding(14, 15, 14, 15);
            this.mainLayout.RowCount = 1;
            this.mainLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mainLayout.Size = new System.Drawing.Size(1460, 618);
            this.mainLayout.TabIndex = 0;
            // 
            // leftLayout
            // 
            this.leftLayout.ColumnCount = 1;
            this.leftLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.leftLayout.Controls.Add(this.headerPanel, 0, 0);
            this.leftLayout.Controls.Add(this.questionCard, 0, 1);
            this.leftLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.leftLayout.Location = new System.Drawing.Point(14, 15);
            this.leftLayout.Margin = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.leftLayout.Name = "leftLayout";
            this.leftLayout.RowCount = 2;
            this.leftLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.leftLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.leftLayout.Size = new System.Drawing.Size(963, 588);
            this.leftLayout.TabIndex = 0;
            // 
            // headerPanel
            // 
            this.headerPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(27)))), ((int)(((byte)(54)))));
            this.headerPanel.Controls.Add(this.lblSubtitle);
            this.headerPanel.Controls.Add(this.lblTitle);
            this.headerPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.headerPanel.Location = new System.Drawing.Point(0, 0);
            this.headerPanel.Margin = new System.Windows.Forms.Padding(0, 0, 0, 13);
            this.headerPanel.Name = "headerPanel";
            this.headerPanel.Padding = new System.Windows.Forms.Padding(18, 15, 18, 13);
            this.headerPanel.Size = new System.Drawing.Size(963, 86);
            this.headerPanel.TabIndex = 0;
            // 
            // lblSubtitle
            // 
            this.lblSubtitle.AutoSize = true;
            this.lblSubtitle.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblSubtitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(195)))), ((int)(((byte)(255)))));
            this.lblSubtitle.Location = new System.Drawing.Point(22, 51);
            this.lblSubtitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSubtitle.Name = "lblSubtitle";
            this.lblSubtitle.Size = new System.Drawing.Size(450, 20);
            this.lblSubtitle.TabIndex = 1;
            this.lblSubtitle.Text = "Odgovori na 8 nakljucnih vprasanj in izkoristi vse stiri vrste pomoci.";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 24F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(18, 11);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(316, 45);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Kvizarna Vega Night";
            // 
            // questionCard
            // 
            this.questionCard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(20)))), ((int)(((byte)(43)))));
            this.questionCard.Controls.Add(this.bottomActionsPanel);
            this.questionCard.Controls.Add(this.optionsPanel);
            this.questionCard.Controls.Add(this.progressTrack);
            this.questionCard.Controls.Add(this.lblQuestion);
            this.questionCard.Controls.Add(this.lblQuestionCounter);
            this.questionCard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.questionCard.Location = new System.Drawing.Point(0, 99);
            this.questionCard.Margin = new System.Windows.Forms.Padding(0);
            this.questionCard.Name = "questionCard";
            this.questionCard.Padding = new System.Windows.Forms.Padding(22, 23, 22, 20);
            this.questionCard.Size = new System.Drawing.Size(963, 489);
            this.questionCard.TabIndex = 1;
            // 
            // bottomActionsPanel
            // 
            this.bottomActionsPanel.Controls.Add(this.btnRestart);
            this.bottomActionsPanel.Controls.Add(this.btnNext);
            this.bottomActionsPanel.Controls.Add(this.lblFeedback);
            this.bottomActionsPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bottomActionsPanel.Location = new System.Drawing.Point(22, 397);
            this.bottomActionsPanel.Margin = new System.Windows.Forms.Padding(2);
            this.bottomActionsPanel.Name = "bottomActionsPanel";
            this.bottomActionsPanel.Size = new System.Drawing.Size(919, 72);
            this.bottomActionsPanel.TabIndex = 4;
            // 
            // btnRestart
            // 
            this.btnRestart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRestart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(76)))));
            this.btnRestart.FlatAppearance.BorderSize = 0;
            this.btnRestart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRestart.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold);
            this.btnRestart.ForeColor = System.Drawing.Color.White;
            this.btnRestart.Location = new System.Drawing.Point(656, 24);
            this.btnRestart.Margin = new System.Windows.Forms.Padding(2);
            this.btnRestart.Name = "btnRestart";
            this.btnRestart.Size = new System.Drawing.Size(112, 37);
            this.btnRestart.TabIndex = 1;
            this.btnRestart.Text = "Nova igra";
            this.btnRestart.UseVisualStyleBackColor = false;
            this.btnRestart.Click += new System.EventHandler(this.btnRestart_Click);
            // 
            // btnNext
            // 
            this.btnNext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNext.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(199)))), ((int)(((byte)(166)))));
            this.btnNext.FlatAppearance.BorderSize = 0;
            this.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNext.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold);
            this.btnNext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(22)))), ((int)(((byte)(39)))));
            this.btnNext.Location = new System.Drawing.Point(781, 24);
            this.btnNext.Margin = new System.Windows.Forms.Padding(2);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(135, 37);
            this.btnNext.TabIndex = 2;
            this.btnNext.Text = "Naprej";
            this.btnNext.UseVisualStyleBackColor = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // lblFeedback
            // 
            this.lblFeedback.AutoSize = true;
            this.lblFeedback.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblFeedback.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(209)))), ((int)(((byte)(255)))));
            this.lblFeedback.Location = new System.Drawing.Point(0, 30);
            this.lblFeedback.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblFeedback.MaximumSize = new System.Drawing.Size(270, 0);
            this.lblFeedback.Name = "lblFeedback";
            this.lblFeedback.Size = new System.Drawing.Size(183, 20);
            this.lblFeedback.TabIndex = 0;
            this.lblFeedback.Text = "Izberi odgovor za zacetek.";
            // 
            // optionsPanel
            // 
            this.optionsPanel.ColumnCount = 2;
            this.optionsPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.optionsPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.optionsPanel.Controls.Add(this.btnAnswer3, 0, 1);
            this.optionsPanel.Controls.Add(this.btnAnswer2, 1, 0);
            this.optionsPanel.Controls.Add(this.btnAnswer1, 0, 0);
            this.optionsPanel.Controls.Add(this.btnAnswer4, 1, 1);
            this.optionsPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.optionsPanel.Location = new System.Drawing.Point(22, 160);
            this.optionsPanel.Margin = new System.Windows.Forms.Padding(0);
            this.optionsPanel.Name = "optionsPanel";
            this.optionsPanel.RowCount = 2;
            this.optionsPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.optionsPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.optionsPanel.Size = new System.Drawing.Size(919, 177);
            this.optionsPanel.TabIndex = 3;
            // 
            // btnAnswer3
            // 
            this.btnAnswer3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(31)))), ((int)(((byte)(66)))));
            this.btnAnswer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAnswer3.FlatAppearance.BorderSize = 0;
            this.btnAnswer3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAnswer3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.btnAnswer3.ForeColor = System.Drawing.Color.White;
            this.btnAnswer3.Location = new System.Drawing.Point(2, 90);
            this.btnAnswer3.Margin = new System.Windows.Forms.Padding(2);
            this.btnAnswer3.Name = "btnAnswer3";
            this.btnAnswer3.Padding = new System.Windows.Forms.Padding(12, 8, 12, 8);
            this.btnAnswer3.Size = new System.Drawing.Size(455, 85);
            this.btnAnswer3.TabIndex = 2;
            this.btnAnswer3.Tag = "2";
            this.btnAnswer3.Text = "Odgovor C";
            this.btnAnswer3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAnswer3.UseVisualStyleBackColor = false;
            this.btnAnswer3.Click += new System.EventHandler(this.AnswerButton_Click);
            // 
            // btnAnswer2
            // 
            this.btnAnswer2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(31)))), ((int)(((byte)(66)))));
            this.btnAnswer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAnswer2.FlatAppearance.BorderSize = 0;
            this.btnAnswer2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAnswer2.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.btnAnswer2.ForeColor = System.Drawing.Color.White;
            this.btnAnswer2.Location = new System.Drawing.Point(461, 2);
            this.btnAnswer2.Margin = new System.Windows.Forms.Padding(2);
            this.btnAnswer2.Name = "btnAnswer2";
            this.btnAnswer2.Padding = new System.Windows.Forms.Padding(12, 8, 12, 8);
            this.btnAnswer2.Size = new System.Drawing.Size(456, 84);
            this.btnAnswer2.TabIndex = 1;
            this.btnAnswer2.Tag = "1";
            this.btnAnswer2.Text = "Odgovor B";
            this.btnAnswer2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAnswer2.UseVisualStyleBackColor = false;
            this.btnAnswer2.Click += new System.EventHandler(this.AnswerButton_Click);
            // 
            // btnAnswer1
            // 
            this.btnAnswer1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(31)))), ((int)(((byte)(66)))));
            this.btnAnswer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAnswer1.FlatAppearance.BorderSize = 0;
            this.btnAnswer1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAnswer1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.btnAnswer1.ForeColor = System.Drawing.Color.White;
            this.btnAnswer1.Location = new System.Drawing.Point(2, 2);
            this.btnAnswer1.Margin = new System.Windows.Forms.Padding(2);
            this.btnAnswer1.Name = "btnAnswer1";
            this.btnAnswer1.Padding = new System.Windows.Forms.Padding(12, 8, 12, 8);
            this.btnAnswer1.Size = new System.Drawing.Size(455, 84);
            this.btnAnswer1.TabIndex = 0;
            this.btnAnswer1.Tag = "0";
            this.btnAnswer1.Text = "Odgovor A";
            this.btnAnswer1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAnswer1.UseVisualStyleBackColor = false;
            this.btnAnswer1.Click += new System.EventHandler(this.AnswerButton_Click);
            // 
            // btnAnswer4
            // 
            this.btnAnswer4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(31)))), ((int)(((byte)(66)))));
            this.btnAnswer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAnswer4.FlatAppearance.BorderSize = 0;
            this.btnAnswer4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAnswer4.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.btnAnswer4.ForeColor = System.Drawing.Color.White;
            this.btnAnswer4.Location = new System.Drawing.Point(461, 90);
            this.btnAnswer4.Margin = new System.Windows.Forms.Padding(2);
            this.btnAnswer4.Name = "btnAnswer4";
            this.btnAnswer4.Padding = new System.Windows.Forms.Padding(12, 8, 12, 8);
            this.btnAnswer4.Size = new System.Drawing.Size(456, 85);
            this.btnAnswer4.TabIndex = 3;
            this.btnAnswer4.Tag = "3";
            this.btnAnswer4.Text = "Odgovor D";
            this.btnAnswer4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAnswer4.UseVisualStyleBackColor = false;
            this.btnAnswer4.Click += new System.EventHandler(this.AnswerButton_Click);
            // 
            // progressTrack
            // 
            this.progressTrack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(80)))));
            this.progressTrack.Controls.Add(this.progressFill);
            this.progressTrack.Dock = System.Windows.Forms.DockStyle.Top;
            this.progressTrack.Location = new System.Drawing.Point(22, 141);
            this.progressTrack.Margin = new System.Windows.Forms.Padding(0, 0, 0, 15);
            this.progressTrack.Name = "progressTrack";
            this.progressTrack.Size = new System.Drawing.Size(919, 19);
            this.progressTrack.TabIndex = 2;
            // 
            // progressFill
            // 
            this.progressFill.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(199)))), ((int)(((byte)(166)))));
            this.progressFill.Dock = System.Windows.Forms.DockStyle.Left;
            this.progressFill.Location = new System.Drawing.Point(0, 0);
            this.progressFill.Margin = new System.Windows.Forms.Padding(2);
            this.progressFill.Name = "progressFill";
            this.progressFill.Size = new System.Drawing.Size(69, 19);
            this.progressFill.TabIndex = 0;
            // 
            // lblQuestion
            // 
            this.lblQuestion.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblQuestion.Font = new System.Drawing.Font("Segoe UI Semibold", 20F, System.Drawing.FontStyle.Bold);
            this.lblQuestion.ForeColor = System.Drawing.Color.White;
            this.lblQuestion.Location = new System.Drawing.Point(22, 43);
            this.lblQuestion.Margin = new System.Windows.Forms.Padding(0, 0, 0, 15);
            this.lblQuestion.Name = "lblQuestion";
            this.lblQuestion.Padding = new System.Windows.Forms.Padding(0, 15, 0, 15);
            this.lblQuestion.Size = new System.Drawing.Size(919, 98);
            this.lblQuestion.TabIndex = 1;
            this.lblQuestion.Text = "Vprasanje bo prikazano tukaj.";
            // 
            // lblQuestionCounter
            // 
            this.lblQuestionCounter.AutoSize = true;
            this.lblQuestionCounter.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblQuestionCounter.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold);
            this.lblQuestionCounter.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(230)))), ((int)(((byte)(214)))));
            this.lblQuestionCounter.Location = new System.Drawing.Point(22, 23);
            this.lblQuestionCounter.Margin = new System.Windows.Forms.Padding(0);
            this.lblQuestionCounter.Name = "lblQuestionCounter";
            this.lblQuestionCounter.Size = new System.Drawing.Size(125, 20);
            this.lblQuestionCounter.TabIndex = 0;
            this.lblQuestionCounter.Text = "Vprasanje 1 od 8";
            // 
            // sidebarPanel
            // 
            this.sidebarPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(23)))), ((int)(((byte)(49)))));
            this.sidebarPanel.Controls.Add(this.helpPanel);
            this.sidebarPanel.Controls.Add(this.lblHelpTitle);
            this.sidebarPanel.Controls.Add(this.tipPanel);
            this.sidebarPanel.Controls.Add(this.statsPanel);
            this.sidebarPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sidebarPanel.Location = new System.Drawing.Point(987, 15);
            this.sidebarPanel.Margin = new System.Windows.Forms.Padding(0);
            this.sidebarPanel.Name = "sidebarPanel";
            this.sidebarPanel.Padding = new System.Windows.Forms.Padding(15, 16, 15, 16);
            this.sidebarPanel.Size = new System.Drawing.Size(459, 588);
            this.sidebarPanel.TabIndex = 1;
            // 
            // helpPanel
            // 
            this.helpPanel.ColumnCount = 2;
            this.helpPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.helpPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.helpPanel.Controls.Add(this.btnHelpAudience, 1, 1);
            this.helpPanel.Controls.Add(this.btnHelpHint, 0, 1);
            this.helpPanel.Controls.Add(this.btnHelpSkip, 1, 0);
            this.helpPanel.Controls.Add(this.btnHelp5050, 0, 0);
            this.helpPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.helpPanel.Location = new System.Drawing.Point(15, 392);
            this.helpPanel.Margin = new System.Windows.Forms.Padding(0);
            this.helpPanel.Name = "helpPanel";
            this.helpPanel.RowCount = 2;
            this.helpPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.helpPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.helpPanel.Size = new System.Drawing.Size(429, 136);
            this.helpPanel.TabIndex = 3;
            // 
            // btnHelpAudience
            // 
            this.btnHelpAudience.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(76)))));
            this.btnHelpAudience.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnHelpAudience.FlatAppearance.BorderSize = 0;
            this.btnHelpAudience.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHelpAudience.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.btnHelpAudience.ForeColor = System.Drawing.Color.White;
            this.btnHelpAudience.Location = new System.Drawing.Point(216, 70);
            this.btnHelpAudience.Margin = new System.Windows.Forms.Padding(2);
            this.btnHelpAudience.Name = "btnHelpAudience";
            this.btnHelpAudience.Size = new System.Drawing.Size(211, 64);
            this.btnHelpAudience.TabIndex = 3;
            this.btnHelpAudience.Text = "Publika";
            this.btnHelpAudience.UseVisualStyleBackColor = false;
            this.btnHelpAudience.Click += new System.EventHandler(this.btnHelpAudience_Click);
            // 
            // btnHelpHint
            // 
            this.btnHelpHint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(76)))));
            this.btnHelpHint.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnHelpHint.FlatAppearance.BorderSize = 0;
            this.btnHelpHint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHelpHint.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.btnHelpHint.ForeColor = System.Drawing.Color.White;
            this.btnHelpHint.Location = new System.Drawing.Point(2, 70);
            this.btnHelpHint.Margin = new System.Windows.Forms.Padding(2);
            this.btnHelpHint.Name = "btnHelpHint";
            this.btnHelpHint.Size = new System.Drawing.Size(210, 64);
            this.btnHelpHint.TabIndex = 2;
            this.btnHelpHint.Text = "Namig";
            this.btnHelpHint.UseVisualStyleBackColor = false;
            this.btnHelpHint.Click += new System.EventHandler(this.btnHelpHint_Click);
            // 
            // btnHelpSkip
            // 
            this.btnHelpSkip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(76)))));
            this.btnHelpSkip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnHelpSkip.FlatAppearance.BorderSize = 0;
            this.btnHelpSkip.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHelpSkip.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.btnHelpSkip.ForeColor = System.Drawing.Color.White;
            this.btnHelpSkip.Location = new System.Drawing.Point(216, 2);
            this.btnHelpSkip.Margin = new System.Windows.Forms.Padding(2);
            this.btnHelpSkip.Name = "btnHelpSkip";
            this.btnHelpSkip.Size = new System.Drawing.Size(211, 64);
            this.btnHelpSkip.TabIndex = 1;
            this.btnHelpSkip.Text = "Preskok";
            this.btnHelpSkip.UseVisualStyleBackColor = false;
            this.btnHelpSkip.Click += new System.EventHandler(this.btnHelpSkip_Click);
            // 
            // btnHelp5050
            // 
            this.btnHelp5050.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(76)))));
            this.btnHelp5050.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnHelp5050.FlatAppearance.BorderSize = 0;
            this.btnHelp5050.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHelp5050.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.btnHelp5050.ForeColor = System.Drawing.Color.White;
            this.btnHelp5050.Location = new System.Drawing.Point(2, 2);
            this.btnHelp5050.Margin = new System.Windows.Forms.Padding(2);
            this.btnHelp5050.Name = "btnHelp5050";
            this.btnHelp5050.Size = new System.Drawing.Size(210, 64);
            this.btnHelp5050.TabIndex = 0;
            this.btnHelp5050.Text = "50 : 50";
            this.btnHelp5050.UseVisualStyleBackColor = false;
            this.btnHelp5050.Click += new System.EventHandler(this.btnHelp5050_Click);
            // 
            // lblHelpTitle
            // 
            this.lblHelpTitle.AutoSize = true;
            this.lblHelpTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblHelpTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold);
            this.lblHelpTitle.ForeColor = System.Drawing.Color.White;
            this.lblHelpTitle.Location = new System.Drawing.Point(15, 342);
            this.lblHelpTitle.Margin = new System.Windows.Forms.Padding(0);
            this.lblHelpTitle.Name = "lblHelpTitle";
            this.lblHelpTitle.Padding = new System.Windows.Forms.Padding(0, 15, 0, 10);
            this.lblHelpTitle.Size = new System.Drawing.Size(75, 50);
            this.lblHelpTitle.TabIndex = 2;
            this.lblHelpTitle.Text = "Pomoci";
            // 
            // tipPanel
            // 
            this.tipPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(31)))), ((int)(((byte)(61)))));
            this.tipPanel.Controls.Add(this.lblTipBody);
            this.tipPanel.Controls.Add(this.lblTipTitle);
            this.tipPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.tipPanel.Location = new System.Drawing.Point(15, 155);
            this.tipPanel.Margin = new System.Windows.Forms.Padding(0);
            this.tipPanel.Name = "tipPanel";
            this.tipPanel.Padding = new System.Windows.Forms.Padding(14, 15, 14, 11);
            this.tipPanel.Size = new System.Drawing.Size(429, 187);
            this.tipPanel.TabIndex = 1;
            // 
            // lblTipBody
            // 
            this.lblTipBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTipBody.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.lblTipBody.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(220)))), ((int)(((byte)(255)))));
            this.lblTipBody.Location = new System.Drawing.Point(14, 38);
            this.lblTipBody.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTipBody.Name = "lblTipBody";
            this.lblTipBody.Size = new System.Drawing.Size(401, 138);
            this.lblTipBody.TabIndex = 1;
            this.lblTipBody.Text = "Vsaka pomoc je na voljo enkrat. Klikni jo, ko res potrebujes prednost.";
            // 
            // lblTipTitle
            // 
            this.lblTipTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTipTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.lblTipTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(230)))), ((int)(((byte)(214)))));
            this.lblTipTitle.Location = new System.Drawing.Point(14, 15);
            this.lblTipTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTipTitle.Name = "lblTipTitle";
            this.lblTipTitle.Size = new System.Drawing.Size(401, 23);
            this.lblTipTitle.TabIndex = 0;
            this.lblTipTitle.Text = "Studio sporoca";
            // 
            // statsPanel
            // 
            this.statsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(31)))), ((int)(((byte)(61)))));
            this.statsPanel.Controls.Add(this.lblRoundValue);
            this.statsPanel.Controls.Add(this.lblRoundCaption);
            this.statsPanel.Controls.Add(this.lblStreakValue);
            this.statsPanel.Controls.Add(this.lblStreakCaption);
            this.statsPanel.Controls.Add(this.lblScoreValue);
            this.statsPanel.Controls.Add(this.lblScoreCaption);
            this.statsPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.statsPanel.Location = new System.Drawing.Point(15, 16);
            this.statsPanel.Margin = new System.Windows.Forms.Padding(0);
            this.statsPanel.Name = "statsPanel";
            this.statsPanel.Padding = new System.Windows.Forms.Padding(14, 15, 14, 15);
            this.statsPanel.Size = new System.Drawing.Size(429, 139);
            this.statsPanel.TabIndex = 0;
            // 
            // lblRoundValue
            // 
            this.lblRoundValue.AutoSize = true;
            this.lblRoundValue.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold);
            this.lblRoundValue.ForeColor = System.Drawing.Color.White;
            this.lblRoundValue.Location = new System.Drawing.Point(16, 100);
            this.lblRoundValue.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoundValue.Name = "lblRoundValue";
            this.lblRoundValue.Size = new System.Drawing.Size(49, 25);
            this.lblRoundValue.TabIndex = 5;
            this.lblRoundValue.Text = "1 / 8";
            // 
            // lblRoundCaption
            // 
            this.lblRoundCaption.AutoSize = true;
            this.lblRoundCaption.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblRoundCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(191)))), ((int)(((byte)(245)))));
            this.lblRoundCaption.Location = new System.Drawing.Point(17, 80);
            this.lblRoundCaption.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoundCaption.Name = "lblRoundCaption";
            this.lblRoundCaption.Size = new System.Drawing.Size(38, 19);
            this.lblRoundCaption.TabIndex = 4;
            this.lblRoundCaption.Text = "Krog";
            // 
            // lblStreakValue
            // 
            this.lblStreakValue.AutoSize = true;
            this.lblStreakValue.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold);
            this.lblStreakValue.ForeColor = System.Drawing.Color.White;
            this.lblStreakValue.Location = new System.Drawing.Point(154, 47);
            this.lblStreakValue.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStreakValue.Name = "lblStreakValue";
            this.lblStreakValue.Size = new System.Drawing.Size(23, 25);
            this.lblStreakValue.TabIndex = 3;
            this.lblStreakValue.Text = "0";
            // 
            // lblStreakCaption
            // 
            this.lblStreakCaption.AutoSize = true;
            this.lblStreakCaption.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStreakCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(191)))), ((int)(((byte)(245)))));
            this.lblStreakCaption.Location = new System.Drawing.Point(154, 28);
            this.lblStreakCaption.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStreakCaption.Name = "lblStreakCaption";
            this.lblStreakCaption.Size = new System.Drawing.Size(41, 19);
            this.lblStreakCaption.TabIndex = 2;
            this.lblStreakCaption.Text = "Serija";
            // 
            // lblScoreValue
            // 
            this.lblScoreValue.AutoSize = true;
            this.lblScoreValue.Font = new System.Drawing.Font("Segoe UI Semibold", 28F, System.Drawing.FontStyle.Bold);
            this.lblScoreValue.ForeColor = System.Drawing.Color.White;
            this.lblScoreValue.Location = new System.Drawing.Point(15, 28);
            this.lblScoreValue.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblScoreValue.Name = "lblScoreValue";
            this.lblScoreValue.Size = new System.Drawing.Size(43, 51);
            this.lblScoreValue.TabIndex = 1;
            this.lblScoreValue.Text = "0";
            // 
            // lblScoreCaption
            // 
            this.lblScoreCaption.AutoSize = true;
            this.lblScoreCaption.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblScoreCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(191)))), ((int)(((byte)(245)))));
            this.lblScoreCaption.Location = new System.Drawing.Point(18, 9);
            this.lblScoreCaption.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblScoreCaption.Name = "lblScoreCaption";
            this.lblScoreCaption.Size = new System.Drawing.Size(43, 19);
            this.lblScoreCaption.TabIndex = 0;
            this.lblScoreCaption.Text = "Tocke";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(13)))), ((int)(((byte)(28)))));
            this.ClientSize = new System.Drawing.Size(1460, 618);
            this.Controls.Add(this.mainLayout);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MinimumSize = new System.Drawing.Size(829, 592);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vaja18 - Vid Sinko - Kviz";
            this.mainLayout.ResumeLayout(false);
            this.leftLayout.ResumeLayout(false);
            this.headerPanel.ResumeLayout(false);
            this.headerPanel.PerformLayout();
            this.questionCard.ResumeLayout(false);
            this.questionCard.PerformLayout();
            this.bottomActionsPanel.ResumeLayout(false);
            this.bottomActionsPanel.PerformLayout();
            this.optionsPanel.ResumeLayout(false);
            this.progressTrack.ResumeLayout(false);
            this.sidebarPanel.ResumeLayout(false);
            this.sidebarPanel.PerformLayout();
            this.helpPanel.ResumeLayout(false);
            this.tipPanel.ResumeLayout(false);
            this.statsPanel.ResumeLayout(false);
            this.statsPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel mainLayout;
        private System.Windows.Forms.TableLayoutPanel leftLayout;
        private System.Windows.Forms.Panel headerPanel;
        private System.Windows.Forms.Label lblSubtitle;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel questionCard;
        private System.Windows.Forms.Panel bottomActionsPanel;
        private System.Windows.Forms.Button btnRestart;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Label lblFeedback;
        private System.Windows.Forms.TableLayoutPanel optionsPanel;
        private System.Windows.Forms.Button btnAnswer3;
        private System.Windows.Forms.Button btnAnswer2;
        private System.Windows.Forms.Button btnAnswer1;
        private System.Windows.Forms.Button btnAnswer4;
        private System.Windows.Forms.Panel progressTrack;
        private System.Windows.Forms.Panel progressFill;
        private System.Windows.Forms.Label lblQuestion;
        private System.Windows.Forms.Label lblQuestionCounter;
        private System.Windows.Forms.Panel sidebarPanel;
        private System.Windows.Forms.TableLayoutPanel helpPanel;
        private System.Windows.Forms.Button btnHelpAudience;
        private System.Windows.Forms.Button btnHelpHint;
        private System.Windows.Forms.Button btnHelpSkip;
        private System.Windows.Forms.Button btnHelp5050;
        private System.Windows.Forms.Label lblHelpTitle;
        private System.Windows.Forms.Panel tipPanel;
        private System.Windows.Forms.Label lblTipBody;
        private System.Windows.Forms.Label lblTipTitle;
        private System.Windows.Forms.Panel statsPanel;
        private System.Windows.Forms.Label lblRoundValue;
        private System.Windows.Forms.Label lblRoundCaption;
        private System.Windows.Forms.Label lblStreakValue;
        private System.Windows.Forms.Label lblStreakCaption;
        private System.Windows.Forms.Label lblScoreValue;
        private System.Windows.Forms.Label lblScoreCaption;
    }
}
