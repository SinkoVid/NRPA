using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace Vaja18_VidSinko
{
    public partial class Form1 : Form
    {
        private readonly Random random = new Random();
        private readonly List<Button> answerButtons;
        private readonly List<QuizQuestion> questionBank;
        private readonly int[] prizeLevels = { 100, 200, 300, 500, 1000, 2000, 4000, 8000 };
        private readonly HashSet<int> guaranteedLevelIndexes = new HashSet<int> { 2, 5 };
        private readonly CultureInfo moneyCulture = new CultureInfo("sl-SI");
        private List<QuizQuestion> activeQuestions;
        private int currentQuestionIndex;
        private int score;
        private int streak;
        private int bestStreak;
        private int currentWinnings;
        private int guaranteedWinnings;
        private int finalWinnings;
        private bool questionAnswered;
        private bool help5050Used;
        private bool helpHintUsed;
        private bool helpAudienceUsed;
        private bool helpSkipUsed;
        private bool uiReady;
        private bool gameFinished;
        private bool roundEndsGame;
        private GameEndReason endReason;
        private Panel prizeCard;
        private TableLayoutPanel prizeLayout;
        private Label lblPrizeTitle;
        private Label lblPrizeHint;
        private Label[] prizeLabels;

        private readonly Color optionIdle = Color.FromArgb(21, 31, 66);
        private readonly Color optionHover = Color.FromArgb(37, 51, 96);
        private readonly Color optionDisabled = Color.FromArgb(37, 42, 61);
        private readonly Color optionCorrect = Color.FromArgb(0, 199, 166);
        private readonly Color optionWrong = Color.FromArgb(230, 82, 87);

        public Form1()
        {
            InitializeComponent();

            answerButtons = new List<Button>
            {
                btnAnswer1,
                btnAnswer2,
                btnAnswer3,
                btnAnswer4
            };

            questionBank = BuildQuestionBank();
            activeQuestions = new List<QuizQuestion>();

            ConfigureWindow();
            ConfigureVisualStyle();
            uiReady = true;
            StartNewGame();
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            RefreshResponsiveLayout();
        }

        private void ConfigureWindow()
        {
            AutoScaleMode = AutoScaleMode.Dpi;
            MinimumSize = new Size(1120, 720);
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);
            UpdateStyles();
            questionCard.AutoScroll = true;
            sidebarPanel.AutoScroll = true;
        }

        private void ConfigureVisualStyle()
        {
            lblTitle.Text = "Kdo zeli do 8.000 EUR?";
            lblSubtitle.Text = "Osem vprasanj, dva varna praga in samo en popoln zakljucek.";
            lblHelpTitle.Text = "Pomoci tekmovalca";
            Text = "Vaja18 - Vid Sinko - Kdo zeli do 8.000 EUR?";
            btnNext.BackColor = Color.FromArgb(241, 197, 79);
            btnNext.ForeColor = Color.FromArgb(24, 18, 36);
            btnRestart.BackColor = Color.FromArgb(45, 58, 105);
            btnRestart.ForeColor = Color.White;
            lblQuestionCounter.ForeColor = Color.FromArgb(241, 197, 79);
            lblFeedback.ForeColor = Color.FromArgb(213, 226, 255);
            lblTipTitle.Text = "Studio v zivo";
            lblTipBody.Text = "Voditelj bo tukaj izpisoval dodatne informacije, pomoc in razplet potez.";
            lblScoreCaption.Text = "Na racunu";
            lblStreakCaption.Text = "Varno";
            lblRoundCaption.Text = "Za to vpr.";
            lblScoreValue.Font = new Font("Segoe UI Semibold", 24F, FontStyle.Bold);
            lblStreakValue.Font = new Font("Segoe UI Semibold", 12.5F, FontStyle.Bold);
            lblRoundValue.Font = new Font("Segoe UI Semibold", 12.5F, FontStyle.Bold);

            foreach (Button button in answerButtons)
            {
                button.FlatAppearance.MouseOverBackColor = optionHover;
                button.FlatAppearance.MouseDownBackColor = optionHover;
                button.FlatAppearance.BorderSize = 1;
                button.FlatAppearance.BorderColor = Color.FromArgb(64, 80, 132);
                button.Cursor = Cursors.Hand;
                button.TextAlign = ContentAlignment.MiddleLeft;
            }

            btnNext.Cursor = Cursors.Hand;
            btnRestart.Cursor = Cursors.Hand;
            btnHelp5050.Cursor = Cursors.Hand;
            btnHelpSkip.Cursor = Cursors.Hand;
            btnHelpHint.Cursor = Cursors.Hand;
            btnHelpAudience.Cursor = Cursors.Hand;
            btnNext.FlatAppearance.BorderSize = 0;
            btnRestart.FlatAppearance.BorderSize = 0;

            lblFeedback.MaximumSize = new Size(520, 0);
            BuildPrizeCard();
            SetStudioMessage("Studio v zivo", "Voditelj je pripravljen. Izberi odgovor in napreduj proti glavni nagradi.");

            ApplyRoundedRegion(headerPanel, 24);
            ApplyRoundedRegion(questionCard, 28);
            ApplyRoundedRegion(sidebarPanel, 28);
            ApplyRoundedRegion(statsPanel, 20);
            ApplyRoundedRegion(tipPanel, 20);
            ApplyRoundedRegion(prizeCard, 20);
            ApplyRoundedRegion(progressTrack, 10);
            ApplyRoundedRegion(btnNext, 18);
            ApplyRoundedRegion(btnRestart, 18);

            foreach (Button button in answerButtons)
            {
                ApplyRoundedRegion(button, 22);
            }

            foreach (Button button in new[] { btnHelp5050, btnHelpSkip, btnHelpHint, btnHelpAudience })
            {
                button.FlatAppearance.BorderSize = 1;
                button.FlatAppearance.BorderColor = Color.FromArgb(67, 82, 138);
                ApplyRoundedRegion(button, 18);
            }
        }

        private void StartNewGame()
        {
            score = 0;
            streak = 0;
            bestStreak = 0;
            currentWinnings = 0;
            guaranteedWinnings = 0;
            finalWinnings = 0;
            currentQuestionIndex = 0;
            questionAnswered = false;
            help5050Used = false;
            helpHintUsed = false;
            helpAudienceUsed = false;
            helpSkipUsed = false;
            gameFinished = false;
            roundEndsGame = false;
            endReason = GameEndReason.None;

            activeQuestions = questionBank
                .OrderBy(q => random.Next())
                .Take(prizeLevels.Length)
                .Select(CloneAndShuffleQuestion)
                .ToList();

            lblFeedback.Text = "Dobrodosli v glavni igri. Prvo vprasanje je vredno " + FormatMoney(prizeLevels[0]) + ".";
            btnRestart.Visible = true;
            btnRestart.Text = "Zakljuci oddajo";
            btnNext.Enabled = false;
            btnNext.Text = "Naprej";

            UpdateHelpButtons();
            UpdateMoneyStatus();
            UpdateMoneyLadder();
            SetStudioMessage(
                "Studio je odprt",
                "Varna praga sta pri " + FormatMoney(prizeLevels[2]) + " in " + FormatMoney(prizeLevels[5]) + ". Vsaka pomoc je na voljo samo enkrat.");
            ShowCurrentQuestion();
            RefreshResponsiveLayout();
        }

        private QuizQuestion CloneAndShuffleQuestion(QuizQuestion source)
        {
            List<QuizOption> shuffledAnswers = source.Answers
                .Select(answer => new QuizOption(answer.Text, answer.IsCorrect))
                .OrderBy(answer => random.Next())
                .ToList();

            return new QuizQuestion(source.Question, shuffledAnswers, source.Hint, source.Explanation, source.AudienceLead)
            {
                Theme = source.Theme
            };
        }

        private void ShowCurrentQuestion()
        {
            if (currentQuestionIndex >= activeQuestions.Count)
            {
                endReason = GameEndReason.TopPrize;
                finalWinnings = currentWinnings;
                ShowFinalScreen();
                return;
            }

            QuizQuestion question = activeQuestions[currentQuestionIndex];
            questionAnswered = false;
            roundEndsGame = false;
            endReason = GameEndReason.None;
            string[] answerLetters = { "A", "B", "C", "D" };

            lblQuestionCounter.Text = string.Format("Vprasanje {0} od {1}  |  {2}", currentQuestionIndex + 1, activeQuestions.Count, question.Theme);
            lblQuestion.Text = question.Question;
            lblFeedback.Text = string.Format(
                "Igras za {0}. Napacen odgovor te vrne na {1}.",
                FormatMoney(prizeLevels[currentQuestionIndex]),
                FormatMoney(guaranteedWinnings));
            btnNext.Enabled = false;
            btnRestart.Text = currentWinnings > 0 ? "Vzemi " + FormatMoney(currentWinnings) : "Zakljuci oddajo";

            UpdateProgressFill();
            UpdateMoneyStatus();

            for (int i = 0; i < answerButtons.Count; i++)
            {
                Button button = answerButtons[i];
                button.Text = answerLetters[i] + "   " + question.Answers[i].Text;
                button.Enabled = true;
                button.Visible = true;
                button.BackColor = optionIdle;
                button.ForeColor = Color.White;
            }

            UpdateHelpButtons();
            UpdateMoneyLadder();
            SetStudioMessage(
                "Vprasanje za " + FormatMoney(prizeLevels[currentQuestionIndex]),
                question.Hint);
            RefreshResponsiveLayout();
            Invalidate();
        }

        private void ShowFinalScreen()
        {
            gameFinished = true;
            lblQuestionCounter.Text = "Rezultat oddaje";
            lblQuestion.Text = BuildSummaryTitle();
            lblFeedback.Text = BuildSummaryBody();
            btnRestart.Text = "Nova igra";
            btnNext.Enabled = false;
            btnNext.Text = "Konec";

            foreach (Button button in answerButtons)
            {
                button.Enabled = false;
                button.BackColor = optionDisabled;
                button.ForeColor = Color.FromArgb(150, 160, 190);
            }

            UpdateProgressFill(true);
            UpdateHelpButtons(true);
            UpdateMoneyStatus(true);
            UpdateMoneyLadder();
            SetStudioMessage(
                "Oddaja je koncana",
                "Pravilni odgovori: " + score + " od " + activeQuestions.Count + ". Koncni dobitek je " + FormatMoney(finalWinnings) + ".");
            RefreshResponsiveLayout();
        }

        private string BuildSummaryTitle()
        {
            if (endReason == GameEndReason.TopPrize)
            {
                return "Pravilno. Domov odnasas glavno nagrado " + FormatMoney(finalWinnings) + ".";
            }

            if (endReason == GameEndReason.WalkedAway)
            {
                return "Pametna odlocitev. Oddajo si ustavil ob pravem casu.";
            }

            return "Napacen odgovor je zakljucil pot proti vrhu.";
        }

        private string BuildSummaryBody()
        {
            return string.Format(
                "Pravilno odgovorjena vprasanja: {0}/{1}\r\nOsvojen znesek: {2}\r\nVarni prag: {3}\r\n\r\nKlikni 'Nova igra' za nov nastop v studiu.",
                score,
                activeQuestions.Count,
                FormatMoney(finalWinnings),
                FormatMoney(guaranteedWinnings));
        }

        private void UpdateHelpButtons(bool disableAll = false)
        {
            ConfigureHelpButton(btnHelp5050, "50 : 50", help5050Used || disableAll);
            ConfigureHelpButton(btnHelpSkip, "Klic", helpSkipUsed || disableAll);
            ConfigureHelpButton(btnHelpHint, "Voditelj", helpHintUsed || disableAll);
            ConfigureHelpButton(btnHelpAudience, "Publika", helpAudienceUsed || disableAll);
        }

        private void ConfigureHelpButton(Button button, string text, bool used)
        {
            button.Text = used ? text + "\r\nporabljeno" : text;
            button.Enabled = !used && currentQuestionIndex < activeQuestions.Count && !questionAnswered;
            button.BackColor = used ? optionDisabled : Color.FromArgb(31, 41, 76);
            button.ForeColor = used ? Color.FromArgb(145, 156, 190) : Color.White;
        }

        private void UpdateProgressFill(bool forceComplete = false)
        {
            if (progressTrack == null || progressFill == null || activeQuestions == null || activeQuestions.Count == 0)
            {
                return;
            }

            if (forceComplete || currentQuestionIndex >= activeQuestions.Count)
            {
                progressFill.Width = progressTrack.Width;
                return;
            }

            progressFill.Width = Math.Max(24, progressTrack.Width * (currentQuestionIndex + 1) / activeQuestions.Count);
        }

        private void UpdateMoneyStatus(bool finalScreen = false)
        {
            lblScoreCaption.Text = finalScreen ? "Dobitek" : "Na racunu";
            lblScoreValue.Text = FormatMoney(finalScreen ? finalWinnings : currentWinnings);
            lblStreakCaption.Text = "Varno";
            lblStreakValue.Text = FormatMoney(guaranteedWinnings);
            lblRoundCaption.Text = finalScreen ? "Pravilno" : "Za to vpr.";
            lblRoundValue.Text = finalScreen
                ? string.Format("{0} / {1}", score, activeQuestions.Count)
                : FormatMoney(prizeLevels[currentQuestionIndex]);
        }

        private void UpdateMoneyLadder()
        {
            if (prizeLabels == null)
            {
                return;
            }

            for (int i = 0; i < prizeLevels.Length; i++)
            {
                bool isCurrent = !gameFinished && i == currentQuestionIndex;
                bool isWon = questionAnswered && !roundEndsGame && prizeLevels[i] == currentWinnings;
                bool isFinal = gameFinished && prizeLevels[i] == finalWinnings && finalWinnings > 0;
                bool isGuaranteed = guaranteedLevelIndexes.Contains(i);

                Label label = prizeLabels[i];
                label.Text = string.Format(
                    "{0}. {1}{2}",
                    i + 1,
                    FormatMoney(prizeLevels[i]),
                    isGuaranteed ? "   SAFE" : string.Empty);

                if (isCurrent)
                {
                    label.BackColor = Color.FromArgb(241, 197, 79);
                    label.ForeColor = Color.FromArgb(26, 23, 38);
                }
                else if (isFinal || isWon)
                {
                    label.BackColor = Color.FromArgb(58, 192, 164);
                    label.ForeColor = Color.FromArgb(11, 25, 39);
                }
                else if (isGuaranteed)
                {
                    label.BackColor = Color.FromArgb(31, 49, 96);
                    label.ForeColor = Color.FromArgb(245, 226, 148);
                }
                else
                {
                    label.BackColor = Color.FromArgb(21, 31, 66);
                    label.ForeColor = Color.FromArgb(222, 230, 255);
                }
            }

            lblPrizeHint.Text = "Safe stopnji: " + FormatMoney(prizeLevels[2]) + " in " + FormatMoney(prizeLevels[5]) + ".";
        }

        private string FormatMoney(int amount)
        {
            return amount.ToString("N0", moneyCulture) + " EUR";
        }

        private void SetStudioMessage(string title, string body)
        {
            lblTipTitle.Text = title;
            lblTipBody.Text = body;
        }

        private void BuildPrizeCard()
        {
            if (prizeCard != null)
            {
                return;
            }

            prizeCard = new Panel
            {
                BackColor = Color.FromArgb(18, 27, 58),
                Dock = DockStyle.Top,
                Margin = new Padding(0),
                Padding = new Padding(14, 14, 14, 12),
                Height = 258
            };

            lblPrizeTitle = new Label
            {
                Dock = DockStyle.Top,
                Height = 28,
                Font = new Font("Segoe UI Semibold", 12.5F, FontStyle.Bold),
                ForeColor = Color.White,
                Text = "Denarna lestvica"
            };

            lblPrizeHint = new Label
            {
                Dock = DockStyle.Top,
                Height = 24,
                Font = new Font("Segoe UI", 9.5F),
                ForeColor = Color.FromArgb(186, 198, 244),
                Text = "Safe stopnji sta oznaceni posebej."
            };

            prizeLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                ColumnCount = 1,
                RowCount = prizeLevels.Length,
                Margin = new Padding(0),
                Padding = new Padding(0),
                Height = prizeLevels.Length * 36
            };
            prizeLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));

            prizeLabels = new Label[prizeLevels.Length];
            for (int row = 0; row < prizeLevels.Length; row++)
            {
                prizeLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));

                int levelIndex = prizeLevels.Length - 1 - row;
                Label label = new Label
                {
                    Dock = DockStyle.Fill,
                    Margin = new Padding(0, 0, 0, 5),
                    Padding = new Padding(12, 0, 12, 0),
                    Font = new Font("Segoe UI Semibold", 10.5F, FontStyle.Bold),
                    TextAlign = ContentAlignment.MiddleLeft,
                    BackColor = Color.FromArgb(21, 31, 66),
                    ForeColor = Color.FromArgb(222, 230, 255),
                    AutoEllipsis = true,
                    Text = FormatMoney(prizeLevels[levelIndex])
                };

                prizeLabels[levelIndex] = label;
                prizeLayout.Controls.Add(label, 0, row);
            }

            prizeCard.Controls.Add(lblPrizeHint);
            prizeCard.Controls.Add(prizeLayout);
            prizeCard.Controls.Add(lblPrizeTitle);
            sidebarPanel.Controls.Add(prizeCard);
            sidebarPanel.Controls.SetChildIndex(prizeCard, 3);
        }

        private void AnswerButton_Click(object sender, EventArgs e)
        {
            if (questionAnswered)
            {
                return;
            }

            Button selectedButton = sender as Button;
            if (selectedButton == null)
            {
                return;
            }

            int answerIndex = Convert.ToInt32(selectedButton.Tag);
            QuizQuestion question = activeQuestions[currentQuestionIndex];
            bool isCorrect = question.Answers[answerIndex].IsCorrect;
            questionAnswered = true;

            foreach (Button button in answerButtons)
            {
                button.Enabled = false;
            }

            foreach (Button button in answerButtons.Where(button => !button.Visible))
            {
                button.Visible = true;
                button.Enabled = false;
                button.BackColor = optionDisabled;
                button.ForeColor = Color.FromArgb(150, 160, 190);
            }

            Button correctButton = answerButtons[question.Answers.FindIndex(answer => answer.IsCorrect)];
            correctButton.BackColor = optionCorrect;
            correctButton.ForeColor = Color.FromArgb(8, 22, 39);

            if (!isCorrect)
            {
                selectedButton.BackColor = optionWrong;
                selectedButton.ForeColor = Color.White;
                streak = 0;
                currentWinnings = guaranteedWinnings;
                finalWinnings = guaranteedWinnings;
                roundEndsGame = true;
                endReason = GameEndReason.WrongAnswer;
                lblFeedback.Text = "Napacen odgovor. " + question.Explanation + " Oddajo zapustis z " + FormatMoney(finalWinnings) + ".";
                SetStudioMessage("Napacen odgovor", "Varni prag ti zagotovi " + FormatMoney(finalWinnings) + ".");
            }
            else
            {
                score++;
                streak++;
                bestStreak = Math.Max(bestStreak, streak);
                currentWinnings = prizeLevels[currentQuestionIndex];
                if (guaranteedLevelIndexes.Contains(currentQuestionIndex))
                {
                    guaranteedWinnings = currentWinnings;
                }

                if (currentQuestionIndex == prizeLevels.Length - 1)
                {
                    finalWinnings = currentWinnings;
                    roundEndsGame = true;
                    endReason = GameEndReason.TopPrize;
                    lblFeedback.Text = "Pravilno. " + question.Explanation + " Pravkar si osvojil glavno nagrado " + FormatMoney(finalWinnings) + ".";
                    SetStudioMessage("Glavna nagrada", "Ostal si miren do konca in osvojil vseh " + FormatMoney(finalWinnings) + ".");
                }
                else
                {
                    lblFeedback.Text = string.Format(
                        "Pravilno. {0} Na racunu je zdaj {1}, naslednje vprasanje pa je vredno {2}.",
                        question.Explanation,
                        FormatMoney(currentWinnings),
                        FormatMoney(prizeLevels[currentQuestionIndex + 1]));
                    SetStudioMessage(
                        guaranteedLevelIndexes.Contains(currentQuestionIndex) ? "Varni prag osvojen" : "Odgovor potrjen",
                        guaranteedLevelIndexes.Contains(currentQuestionIndex)
                            ? "Odslej ti pripada najmanj " + FormatMoney(guaranteedWinnings) + "."
                            : "Naslednji korak vodi proti " + FormatMoney(prizeLevels[currentQuestionIndex + 1]) + ".");
                }
            }

            UpdateMoneyStatus();
            UpdateMoneyLadder();
            btnRestart.Text = roundEndsGame
                ? "Prikazi izid"
                : "Vzemi " + FormatMoney(currentWinnings);
            btnNext.Enabled = true;
            btnNext.Text = roundEndsGame
                ? "Zakljuci oddajo"
                : "Naprej na " + FormatMoney(prizeLevels[currentQuestionIndex + 1]);
            UpdateHelpButtons();
            RefreshResponsiveLayout();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (!questionAnswered)
            {
                return;
            }

            if (roundEndsGame)
            {
                ShowFinalScreen();
                return;
            }

            currentQuestionIndex++;
            ShowCurrentQuestion();
        }

        private void btnRestart_Click(object sender, EventArgs e)
        {
            if (!gameFinished)
            {
                if (roundEndsGame)
                {
                    ShowFinalScreen();
                    return;
                }

                finalWinnings = currentWinnings;
                endReason = GameEndReason.WalkedAway;
                ShowFinalScreen();
                return;
            }

            StartNewGame();
        }

        private void btnHelp5050_Click(object sender, EventArgs e)
        {
            if (help5050Used || questionAnswered)
            {
                return;
            }

            help5050Used = true;
            QuizQuestion question = activeQuestions[currentQuestionIndex];
            List<int> wrongIndexes = question.Answers
                .Select((answer, index) => new { answer, index })
                .Where(x => !x.answer.IsCorrect)
                .OrderBy(x => random.Next())
                .Take(2)
                .Select(x => x.index)
                .ToList();

            foreach (int index in wrongIndexes)
            {
                answerButtons[index].Visible = false;
            }

            lblFeedback.Text = "50 : 50 je aktiviran. Na odru sta ostali samo dve moznosti.";
            SetStudioMessage("50 : 50", "Dve nepravilni moznosti sta izloceni. Zdaj odloca mirna glava.");
            UpdateHelpButtons();
            RefreshResponsiveLayout();
        }

        private void btnHelpSkip_Click(object sender, EventArgs e)
        {
            if (helpSkipUsed || questionAnswered)
            {
                return;
            }

            helpSkipUsed = true;
            QuizQuestion question = activeQuestions[currentQuestionIndex];
            int correctIndex = question.Answers.FindIndex(answer => answer.IsCorrect);
            int suggestedIndex = random.NextDouble() < 0.82
                ? correctIndex
                : question.Answers
                    .Select((answer, index) => index)
                    .Where(index => index != correctIndex)
                    .OrderBy(index => random.Next())
                    .First();

            string[] labels = { "A", "B", "C", "D" };
            lblFeedback.Text = "Klic prijatelju: precej samozavestno predlaga odgovor " + labels[suggestedIndex] + ".";
            SetStudioMessage("Klic prijatelju", "Prijatelj bi stavil na odgovor " + labels[suggestedIndex] + ".");
            UpdateHelpButtons();
            RefreshResponsiveLayout();
        }

        private void btnHelpHint_Click(object sender, EventArgs e)
        {
            if (helpHintUsed || questionAnswered)
            {
                return;
            }

            helpHintUsed = true;
            QuizQuestion question = activeQuestions[currentQuestionIndex];
            lblFeedback.Text = "Voditeljev namig: " + question.Hint;
            SetStudioMessage("Voditeljev namig", question.Hint);
            UpdateHelpButtons();
            RefreshResponsiveLayout();
        }

        private void btnHelpAudience_Click(object sender, EventArgs e)
        {
            if (helpAudienceUsed || questionAnswered)
            {
                return;
            }

            helpAudienceUsed = true;
            QuizQuestion question = activeQuestions[currentQuestionIndex];
            int correctIndex = question.Answers.FindIndex(answer => answer.IsCorrect);

            List<int> votes = new List<int> { 12, 18, 21, 16 };
            votes[correctIndex] = question.AudienceLead;

            List<int> otherIndexes = Enumerable.Range(0, 4).Where(index => index != correctIndex).ToList();
            int remainder = 100 - question.AudienceLead;

            for (int i = 0; i < otherIndexes.Count; i++)
            {
                int min = i == otherIndexes.Count - 1 ? remainder : Math.Max(8, remainder / (otherIndexes.Count - i + 1));
                int max = i == otherIndexes.Count - 1 ? remainder : Math.Max(min, remainder - ((otherIndexes.Count - i - 1) * 8));
                int value = i == otherIndexes.Count - 1 ? remainder : random.Next(min, max + 1);
                votes[otherIndexes[i]] = value;
                remainder -= value;
            }

            string[] labels = { "A", "B", "C", "D" };
            int bestVoteIndex = votes.IndexOf(votes.Max());
            lblFeedback.Text = string.Format(
                "Publika je najbolj na strani odgovora {0} ({1}%). Ostali glasovi: A {2}%, B {3}%, C {4}%, D {5}%.",
                labels[bestVoteIndex],
                votes[bestVoteIndex],
                votes[0],
                votes[1],
                votes[2],
                votes[3]);

            SetStudioMessage("Glasovanje publike", "Najvec zaupanja je dobil odgovor " + labels[bestVoteIndex] + ".");
            UpdateHelpButtons();
            RefreshResponsiveLayout();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            using (LinearGradientBrush brush = new LinearGradientBrush(ClientRectangle,
                Color.FromArgb(9, 13, 28),
                Color.FromArgb(24, 17, 54),
                35F))
            {
                e.Graphics.FillRectangle(brush, ClientRectangle);
            }

            using (SolidBrush glowBrush = new SolidBrush(Color.FromArgb(25, 0, 199, 166)))
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                e.Graphics.FillEllipse(glowBrush, new Rectangle(55, 35, 260, 260));
                e.Graphics.FillEllipse(glowBrush, new Rectangle(860, 510, 220, 220));
            }

            base.OnPaint(e);
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);

            if (!uiReady)
            {
                return;
            }

            RefreshResponsiveLayout();
        }

        private void ApplyRoundedRegion(Control control, int radius)
        {
            if (control == null || control.IsDisposed || control.Width <= 0 || control.Height <= 0)
            {
                return;
            }

            GraphicsPath path = new GraphicsPath();
            int diameter = radius * 2;
            Rectangle bounds = new Rectangle(0, 0, control.Width, control.Height);

            path.AddArc(bounds.X, bounds.Y, diameter, diameter, 180, 90);
            path.AddArc(bounds.Right - diameter, bounds.Y, diameter, diameter, 270, 90);
            path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
            path.AddArc(bounds.X, bounds.Bottom - diameter, diameter, diameter, 90, 90);
            path.CloseFigure();

            if (control.Region != null)
            {
                control.Region.Dispose();
            }

            control.Region = new Region(path);
            path.Dispose();
        }

        private void RefreshRoundedRegions()
        {
            ApplyRoundedRegion(headerPanel, 24);
            ApplyRoundedRegion(questionCard, 28);
            ApplyRoundedRegion(sidebarPanel, 28);
            ApplyRoundedRegion(statsPanel, 20);
            ApplyRoundedRegion(tipPanel, 20);
            ApplyRoundedRegion(prizeCard, 20);
            ApplyRoundedRegion(progressTrack, 10);
            ApplyRoundedRegion(btnNext, 18);
            ApplyRoundedRegion(btnRestart, 18);

            if (answerButtons != null)
            {
                foreach (Button button in answerButtons)
                {
                    ApplyRoundedRegion(button, 22);
                }
            }

            foreach (Button button in new[] { btnHelp5050, btnHelpSkip, btnHelpHint, btnHelpAudience })
            {
                ApplyRoundedRegion(button, 18);
            }
        }

        private void RefreshResponsiveLayout()
        {
            if (!uiReady || IsDisposed)
            {
                return;
            }

            SuspendLayout();
            try
            {
                UpdateProgressFill(gameFinished);

                int headerWidth = Math.Max(200, headerPanel.ClientSize.Width - headerPanel.Padding.Horizontal);
                lblTitle.MaximumSize = new Size(headerWidth, 0);
                lblSubtitle.MaximumSize = new Size(headerWidth, 0);
                headerPanel.Height = Math.Max(
                    ScalePixels(88),
                    lblSubtitle.Bottom + headerPanel.Padding.Bottom + ScalePixels(8));
                leftLayout.RowStyles[0].SizeType = SizeType.Absolute;
                leftLayout.RowStyles[0].Height = headerPanel.Height + headerPanel.Margin.Bottom;

                int questionWidth = Math.Max(200, questionCard.ClientSize.Width - questionCard.Padding.Horizontal);
                lblQuestion.MaximumSize = new Size(questionWidth, 0);
                lblQuestion.Height = Math.Max(
                    ScalePixels(96),
                    MeasureTextHeight(lblQuestion.Text, lblQuestion.Font, questionWidth, lblQuestion.Padding));

                int optionWidth = Math.Max(150, (optionsPanel.ClientSize.Width - ScalePixels(6)) / 2);
                int rowHeight1 = Math.Max(
                    GetPreferredButtonHeight(btnAnswer1, optionWidth, ScalePixels(84)),
                    GetPreferredButtonHeight(btnAnswer2, optionWidth, ScalePixels(84)));
                int rowHeight2 = Math.Max(
                    GetPreferredButtonHeight(btnAnswer3, optionWidth, ScalePixels(84)),
                    GetPreferredButtonHeight(btnAnswer4, optionWidth, ScalePixels(84)));
                optionsPanel.RowStyles[0].SizeType = SizeType.Absolute;
                optionsPanel.RowStyles[1].SizeType = SizeType.Absolute;
                optionsPanel.RowStyles[0].Height = rowHeight1;
                optionsPanel.RowStyles[1].Height = rowHeight2;
                optionsPanel.Height = rowHeight1 + rowHeight2 + ScalePixels(4);

                int restartWidth = GetPreferredButtonWidth(btnRestart, ScalePixels(150));
                int nextWidth = GetPreferredButtonWidth(btnNext, ScalePixels(170));
                btnRestart.Width = restartWidth;
                btnNext.Width = nextWidth;
                btnNext.Left = Math.Max(0, bottomActionsPanel.ClientSize.Width - btnNext.Width);
                btnRestart.Left = Math.Max(0, btnNext.Left - ScalePixels(12) - btnRestart.Width);

                int feedbackWidth = Math.Max(
                    ScalePixels(240),
                    btnRestart.Left - ScalePixels(18));
                lblFeedback.MaximumSize = new Size(feedbackWidth, 0);
                int feedbackHeight = MeasureTextHeight(lblFeedback.Text, lblFeedback.Font, feedbackWidth, Padding.Empty);
                int buttonHeight = Math.Max(btnNext.Height, btnRestart.Height);
                bottomActionsPanel.Height = Math.Max(
                    ScalePixels(74),
                    Math.Max(feedbackHeight + ScalePixels(18), buttonHeight + ScalePixels(24)));
                lblFeedback.Top = Math.Max(ScalePixels(10), (bottomActionsPanel.Height - feedbackHeight) / 2);
                int buttonTop = Math.Max(ScalePixels(12), (bottomActionsPanel.Height - btnNext.Height) / 2);
                btnRestart.Top = buttonTop;
                btnNext.Top = buttonTop;

                LayoutStatsPanel();

                int studioWidth = Math.Max(140, tipPanel.ClientSize.Width - tipPanel.Padding.Horizontal);
                lblTipTitle.MaximumSize = new Size(studioWidth, 0);
                lblTipBody.MaximumSize = new Size(studioWidth, 0);
                int studioTitleHeight = MeasureTextHeight(lblTipTitle.Text, lblTipTitle.Font, studioWidth, Padding.Empty);
                int studioBodyHeight = MeasureTextHeight(lblTipBody.Text, lblTipBody.Font, studioWidth, Padding.Empty);
                lblTipTitle.Height = studioTitleHeight;
                tipPanel.Height = Math.Max(
                    ScalePixels(150),
                    tipPanel.Padding.Top + studioTitleHeight + studioBodyHeight + tipPanel.Padding.Bottom + ScalePixels(8));

                if (prizeLayout != null)
                {
                    int ladderRowHeight = ScalePixels(36);
                    if (prizeLabels != null && prizeLabels.Length > 0)
                    {
                        Label sampleLabel = prizeLabels[0];
                        ladderRowHeight = Math.Max(
                            ladderRowHeight,
                            MeasureSingleLineHeight(sampleLabel) + sampleLabel.Padding.Vertical + sampleLabel.Margin.Vertical + ScalePixels(8));
                    }

                    for (int i = 0; i < prizeLayout.RowStyles.Count; i++)
                    {
                        prizeLayout.RowStyles[i].SizeType = SizeType.Absolute;
                        prizeLayout.RowStyles[i].Height = ladderRowHeight;
                    }

                    prizeLayout.Height = ladderRowHeight * prizeLevels.Length;
                    int hintHeight = MeasureTextHeight(lblPrizeHint.Text, lblPrizeHint.Font, Math.Max(140, prizeCard.ClientSize.Width - prizeCard.Padding.Horizontal), Padding.Empty);
                    lblPrizeHint.Height = hintHeight;
                    prizeCard.Height = prizeCard.Padding.Top + lblPrizeTitle.Height + prizeLayout.Height + hintHeight + prizeCard.Padding.Bottom + ScalePixels(8);
                }

                int helpWidth = Math.Max(120, (helpPanel.ClientSize.Width - ScalePixels(6)) / 2);
                int helpRow1 = Math.Max(
                    GetPreferredButtonHeight(btnHelp5050, helpWidth, ScalePixels(58)),
                    GetPreferredButtonHeight(btnHelpSkip, helpWidth, ScalePixels(58)));
                int helpRow2 = Math.Max(
                    GetPreferredButtonHeight(btnHelpHint, helpWidth, ScalePixels(58)),
                    GetPreferredButtonHeight(btnHelpAudience, helpWidth, ScalePixels(58)));
                helpPanel.RowStyles[0].SizeType = SizeType.Absolute;
                helpPanel.RowStyles[1].SizeType = SizeType.Absolute;
                helpPanel.RowStyles[0].Height = helpRow1;
                helpPanel.RowStyles[1].Height = helpRow2;
                helpPanel.Height = helpRow1 + helpRow2 + ScalePixels(4);
            }
            finally
            {
                ResumeLayout();
            }

            RefreshRoundedRegions();
        }

        private void LayoutStatsPanel()
        {
            if (statsPanel == null)
            {
                return;
            }

            int innerWidth = Math.Max(220, statsPanel.ClientSize.Width - statsPanel.Padding.Horizontal);
            int left = statsPanel.Padding.Left;
            int top = statsPanel.Padding.Top;
            int gap = ScalePixels(16);
            int rightWidth = Math.Max(ScalePixels(130), (int)Math.Round(innerWidth * 0.34f));
            int leftWidth = Math.Max(ScalePixels(165), innerWidth - rightWidth - gap);

            if (leftWidth + rightWidth + gap > innerWidth)
            {
                rightWidth = Math.Max(ScalePixels(116), innerWidth - leftWidth - gap);
            }

            if (rightWidth < ScalePixels(96))
            {
                rightWidth = ScalePixels(96);
                leftWidth = Math.Max(ScalePixels(150), innerWidth - rightWidth - gap);
            }

            int rightX = left + leftWidth + gap;
            int scoreCaptionHeight = MeasureSingleLineHeight(lblScoreCaption);
            int scoreValueHeight = MeasureSingleLineHeight(lblScoreValue);
            int streakCaptionHeight = MeasureSingleLineHeight(lblStreakCaption);
            int streakValueHeight = MeasureSingleLineHeight(lblStreakValue);
            int roundCaptionHeight = MeasureSingleLineHeight(lblRoundCaption);
            int roundValueHeight = MeasureSingleLineHeight(lblRoundValue);

            lblScoreCaption.AutoSize = false;
            lblScoreCaption.Location = new Point(left, top);
            lblScoreCaption.Size = new Size(leftWidth, scoreCaptionHeight);

            lblScoreValue.AutoSize = false;
            lblScoreValue.AutoEllipsis = true;
            lblScoreValue.Location = new Point(left, lblScoreCaption.Bottom + ScalePixels(2));
            lblScoreValue.Size = new Size(leftWidth, scoreValueHeight);

            lblStreakCaption.AutoSize = false;
            lblStreakCaption.Location = new Point(rightX, top);
            lblStreakCaption.Size = new Size(rightWidth, streakCaptionHeight);

            lblStreakValue.AutoSize = false;
            lblStreakValue.AutoEllipsis = true;
            lblStreakValue.Location = new Point(rightX, lblStreakCaption.Bottom + ScalePixels(2));
            lblStreakValue.Size = new Size(rightWidth, streakValueHeight);

            lblRoundCaption.AutoSize = false;
            lblRoundCaption.Location = new Point(rightX, lblStreakValue.Bottom + ScalePixels(10));
            lblRoundCaption.Size = new Size(rightWidth, roundCaptionHeight);

            lblRoundValue.AutoSize = false;
            lblRoundValue.AutoEllipsis = true;
            lblRoundValue.Location = new Point(rightX, lblRoundCaption.Bottom + ScalePixels(2));
            lblRoundValue.Size = new Size(rightWidth, roundValueHeight);

            int requiredHeight = Math.Max(
                lblScoreValue.Bottom,
                lblRoundValue.Bottom) + statsPanel.Padding.Bottom;
            statsPanel.Height = Math.Max(ScalePixels(142), requiredHeight);
        }

        private int MeasureTextHeight(string text, Font font, int width, Padding padding)
        {
            Size measured = TextRenderer.MeasureText(
                text ?? string.Empty,
                font,
                new Size(Math.Max(20, width - padding.Horizontal), int.MaxValue),
                TextFormatFlags.WordBreak | TextFormatFlags.TextBoxControl);

            return measured.Height + padding.Vertical;
        }

        private int MeasureSingleLineHeight(Label label)
        {
            Size measured = TextRenderer.MeasureText(
                label.Text ?? string.Empty,
                label.Font,
                new Size(int.MaxValue, int.MaxValue),
                TextFormatFlags.SingleLine);

            return measured.Height;
        }

        private int GetPreferredButtonHeight(Button button, int availableWidth, int minimumHeight)
        {
            int width = Math.Max(80, availableWidth - button.Margin.Horizontal);
            Size measured = TextRenderer.MeasureText(
                button.Text ?? string.Empty,
                button.Font,
                new Size(Math.Max(20, width - button.Padding.Horizontal), int.MaxValue),
                TextFormatFlags.WordBreak | TextFormatFlags.TextBoxControl);

            return Math.Max(minimumHeight, measured.Height + button.Padding.Vertical + button.Margin.Vertical + ScalePixels(18));
        }

        private int GetPreferredButtonWidth(Button button, int minimumWidth)
        {
            Size measured = TextRenderer.MeasureText(
                button.Text ?? string.Empty,
                button.Font,
                new Size(int.MaxValue, int.MaxValue),
                TextFormatFlags.SingleLine);

            return Math.Max(minimumWidth, measured.Width + button.Padding.Horizontal + ScalePixels(24));
        }

        private int ScalePixels(int value)
        {
            float baseHeight = AutoScaleDimensions.Height <= 0 ? 13f : AutoScaleDimensions.Height;
            float scale = CurrentAutoScaleDimensions.Height / baseHeight;
            return (int)Math.Round(value * Math.Max(1f, scale));
        }

        private List<QuizQuestion> BuildQuestionBank()
        {
            return new List<QuizQuestion>
            {
                new QuizQuestion(
                    "Kateri planet v nasem Osoncju je znan po izrazitih obrocih?",
                    new[]
                    {
                        new QuizOption("Saturn", true),
                        new QuizOption("Mars", false),
                        new QuizOption("Venera", false),
                        new QuizOption("Merkur", false)
                    },
                    "Pomislis na planet, ki ga najpogosteje narisemo z obrocem okoli njega.",
                    "Saturn je najbolj prepoznaven po svojem obseznem sistemu obrocev.",
                    64)
                { Theme = "Vesolje" },

                new QuizQuestion(
                    "Kateri programski jezik se izvaja znotraj ogrodja .NET in ga pogosto uporabljamo pri Windows Forms?",
                    new[]
                    {
                        new QuizOption("C#", true),
                        new QuizOption("PHP", false),
                        new QuizOption("Ruby", false),
                        new QuizOption("Swift", false)
                    },
                    "Ima krizce v imenu in je zelo pogost pri namiznih aplikacijah v Visual Studiu.",
                    "Windows Forms je zelo pogosto povezan prav z jezikom C#.",
                    71)
                { Theme = "Programiranje" },

                new QuizQuestion(
                    "Koliko bitov sestavlja en bajt?",
                    new[]
                    {
                        new QuizOption("8", true),
                        new QuizOption("4", false),
                        new QuizOption("16", false),
                        new QuizOption("32", false)
                    },
                    "Gre za eno najbolj osnovnih merskih enot v racunalnistvu.",
                    "En bajt vsebuje natancno 8 bitov.",
                    67)
                { Theme = "Racunalnistvo" },

                new QuizQuestion(
                    "Katera slovenska reka tece skozi Ljubljano?",
                    new[]
                    {
                        new QuizOption("Ljubljanica", true),
                        new QuizOption("Drava", false),
                        new QuizOption("Mura", false),
                        new QuizOption("Soca", false)
                    },
                    "Ime reke je zelo povezano z imenom nase prestolnice.",
                    "Skozi Ljubljano tece reka Ljubljanica.",
                    78)
                { Theme = "Slovenija" },

                new QuizQuestion(
                    "Kateri umetnik je naslikal znamenito delo Mona Lisa?",
                    new[]
                    {
                        new QuizOption("Leonardo da Vinci", true),
                        new QuizOption("Vincent van Gogh", false),
                        new QuizOption("Pablo Picasso", false),
                        new QuizOption("Claude Monet", false)
                    },
                    "Bil je renesancni genij, znan tudi po izumih in skicah strojev.",
                    "Mona Lisa je eno najbolj znanih del Leonarda da Vincija.",
                    72)
                { Theme = "Umetnost" },

                new QuizQuestion(
                    "Katera barva nastane, ce zmesamo modro in rumeno?",
                    new[]
                    {
                        new QuizOption("Zelena", true),
                        new QuizOption("Oranzna", false),
                        new QuizOption("Rdeca", false),
                        new QuizOption("Vijolicna", false)
                    },
                    "Pomislis na travo, listje in semafor za prost prehod.",
                    "Mesanje modre in rumene da zeleno barvo.",
                    81)
                { Theme = "Barve" },

                new QuizQuestion(
                    "Kako imenujemo postopek, pri katerem uporabnik dokazuje svojo identiteto z geslom ali kodo?",
                    new[]
                    {
                        new QuizOption("Avtentikacija", true),
                        new QuizOption("Animacija", false),
                        new QuizOption("Arhiviranje", false),
                        new QuizOption("Optimizacija", false)
                    },
                    "Beseda se pogosto uporablja pri prijavi v sistem.",
                    "Dokazovanje identitete uporabnika imenujemo avtentikacija.",
                    69)
                { Theme = "Varnost" },

                new QuizQuestion(
                    "Katera zival je simbol hitrosti in lahko razvije vec kot 90 km/h?",
                    new[]
                    {
                        new QuizOption("Gepard", true),
                        new QuizOption("Slon", false),
                        new QuizOption("Medved", false),
                        new QuizOption("Volk", false)
                    },
                    "Gre za pegasto veliko macko, ki je znana po sprintu.",
                    "Gepard velja za najhitrejso kopensko zival.",
                    74)
                { Theme = "Zivali" },

                new QuizQuestion(
                    "Kateri ocean je najvecji na svetu?",
                    new[]
                    {
                        new QuizOption("Tihi ocean", true),
                        new QuizOption("Atlantski ocean", false),
                        new QuizOption("Indijski ocean", false),
                        new QuizOption("Arkticni ocean", false)
                    },
                    "Ime mu namiguje na mir, ceprav je po velikosti povsem mogocen.",
                    "Najvecji ocean na Zemlji je Tihi ocean.",
                    76)
                { Theme = "Geografija" },

                new QuizQuestion(
                    "Kaj v HTML oznacuje element <a>?",
                    new[]
                    {
                        new QuizOption("Povezavo", true),
                        new QuizOption("Naslov prve ravni", false),
                        new QuizOption("Sliko", false),
                        new QuizOption("Tabelo", false)
                    },
                    "Klik nanj nas pogosto odpelje na drugo stran ali drug del dokumenta.",
                    "Element <a> predstavlja povezavo oziroma sidro.",
                    68)
                { Theme = "Splet" },

                new QuizQuestion(
                    "Katera glasbena oznaka pomeni, da skladba postaja glasnejsa?",
                    new[]
                    {
                        new QuizOption("Crescendo", true),
                        new QuizOption("Piano", false),
                        new QuizOption("Legato", false),
                        new QuizOption("Adagio", false)
                    },
                    "Beseda se pogosto slisi tudi izven glasbe, ko nekaj postopno raste.",
                    "Crescendo pomeni postopno stopnjevanje glasnosti.",
                    62)
                { Theme = "Glasba" },

                new QuizQuestion(
                    "Kateri del racunalnika je najpogosteje oznacen s kratico CPU?",
                    new[]
                    {
                        new QuizOption("Procesor", true),
                        new QuizOption("Graficna kartica", false),
                        new QuizOption("Napajalnik", false),
                        new QuizOption("Trdi disk", false)
                    },
                    "To je glavna racunska enota racunalnika.",
                    "CPU pomeni centralno procesno enoto oziroma procesor.",
                    79)
                { Theme = "Strojna oprema" },
            };
        }

        private class QuizQuestion
        {
            public QuizQuestion(string question, IEnumerable<QuizOption> answers, string hint, string explanation, int audienceLead)
            {
                Question = question;
                Answers = answers.ToList();
                Hint = hint;
                Explanation = explanation;
                AudienceLead = audienceLead;
                Theme = "Tematika";
            }

            public string Question { get; private set; }
            public List<QuizOption> Answers { get; private set; }
            public string Hint { get; private set; }
            public string Explanation { get; private set; }
            public int AudienceLead { get; private set; }
            public string Theme { get; set; }
        }

        private class QuizOption
        {
            public QuizOption(string text, bool isCorrect)
            {
                Text = text;
                IsCorrect = isCorrect;
            }

            public string Text { get; private set; }
            public bool IsCorrect { get; private set; }
        }

        private enum GameEndReason
        {
            None,
            WrongAnswer,
            WalkedAway,
            TopPrize
        }
    }
}
