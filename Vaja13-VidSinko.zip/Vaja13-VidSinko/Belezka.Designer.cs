﻿namespace Vaja13_VidSinko
{
    partial class Belezka
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Belezka));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.datotekaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.novaTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.odpriTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.shraniTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.natisniTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.predogledTiskaTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.izhodTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.urediToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.razveljaviTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.ponoviTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.kopirajTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.izreziTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.prilepiTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.oblikaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pisavaTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.barvaPisaveTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.barvaOzadjaTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.levaPoravnavaTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.sredinskaPoravnavaTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.desnaPoravnavaTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.pogledToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.orodnaVrsticaTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.statusnaVrsticaTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.temaTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.oAplikacijiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pomocTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.opisTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.avtorTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.kopirajCM = new System.Windows.Forms.ToolStripMenuItem();
            this.izreziCM = new System.Windows.Forms.ToolStripMenuItem();
            this.prilepiCM = new System.Windows.Forms.ToolStripMenuItem();
            this.nastaviBarvoPisaveCM = new System.Windows.Forms.ToolStripMenuItem();
            this.nastaviBarvoOzadjaCM = new System.Windows.Forms.ToolStripMenuItem();
            this.toolbox = new System.Windows.Forms.ToolStrip();
            this.toolboxNova = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolboxOdpri = new System.Windows.Forms.ToolStripButton();
            this.toolboxShrani = new System.Windows.Forms.ToolStripButton();
            this.toolboxNatisni = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.toolboxRazveljavi = new System.Windows.Forms.ToolStripButton();
            this.toolboxPonovi = new System.Windows.Forms.ToolStripButton();
            this.toolboxKopiraj = new System.Windows.Forms.ToolStripButton();
            this.toolboxIzrezi = new System.Windows.Forms.ToolStripButton();
            this.toolboxPrilepi = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolboxPisava = new System.Windows.Forms.ToolStripButton();
            this.toolboxBarvaFore = new System.Windows.Forms.ToolStripButton();
            this.toolboxBarvaBack = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolboxLevo = new System.Windows.Forms.ToolStripButton();
            this.toolboxSredinska = new System.Windows.Forms.ToolStripButton();
            this.toolboxDesno = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.toolboxTema = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.toolboxZakleniOrodno = new System.Windows.Forms.ToolStripButton();
            this.richtxtTekst = new System.Windows.Forms.RichTextBox();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripSTznakov = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolstripSepparator = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripDatum = new System.Windows.Forms.ToolStripStatusLabel();
            this.colorDialog = new System.Windows.Forms.ColorDialog();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.printPreviewDialog = new System.Windows.Forms.PrintPreviewDialog();
            this.printDialog = new System.Windows.Forms.PrintDialog();
            this.printDocument = new System.Drawing.Printing.PrintDocument();
            this.helpProvider = new System.Windows.Forms.HelpProvider();
            this.menuStrip.SuspendLayout();
            this.contextMenuStrip.SuspendLayout();
            this.toolbox.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.datotekaToolStripMenuItem,
            this.urediToolStripMenuItem,
            this.oblikaToolStripMenuItem,
            this.pogledToolStripMenuItem,
            this.oAplikacijiToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(741, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "Glavni meni";
            // 
            // datotekaToolStripMenuItem
            // 
            this.datotekaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.novaTSMI,
            this.toolStripSeparator1,
            this.odpriTSMI,
            this.shraniTSMI,
            this.natisniTSMI,
            this.predogledTiskaTSMI,
            this.toolStripSeparator2,
            this.izhodTSMI});
            this.datotekaToolStripMenuItem.Name = "datotekaToolStripMenuItem";
            this.datotekaToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.datotekaToolStripMenuItem.Text = "Datoteka";
            // 
            // novaTSMI
            // 
            this.novaTSMI.Image = ((System.Drawing.Image)(resources.GetObject("novaTSMI.Image")));
            this.novaTSMI.Name = "novaTSMI";
            this.novaTSMI.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.novaTSMI.Size = new System.Drawing.Size(180, 22);
            this.novaTSMI.Text = "Nova";
            this.novaTSMI.Click += new System.EventHandler(this.novaTSMI_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(152, 6);
            // 
            // odpriTSMI
            // 
            this.odpriTSMI.Image = ((System.Drawing.Image)(resources.GetObject("odpriTSMI.Image")));
            this.odpriTSMI.Name = "odpriTSMI";
            this.odpriTSMI.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.odpriTSMI.Size = new System.Drawing.Size(155, 22);
            this.odpriTSMI.Text = "Odpri";
            this.odpriTSMI.Click += new System.EventHandler(this.odpriTSMI_Click);
            // 
            // shraniTSMI
            // 
            this.shraniTSMI.Image = ((System.Drawing.Image)(resources.GetObject("shraniTSMI.Image")));
            this.shraniTSMI.Name = "shraniTSMI";
            this.shraniTSMI.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.shraniTSMI.Size = new System.Drawing.Size(155, 22);
            this.shraniTSMI.Text = "Shrani";
            this.shraniTSMI.Click += new System.EventHandler(this.shraniTSMI_Click);
            // 
            // natisniTSMI
            // 
            this.natisniTSMI.Image = global::Vaja13_VidSinko.Properties.Resources.printing_446991;
            this.natisniTSMI.Name = "natisniTSMI";
            this.natisniTSMI.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.natisniTSMI.Size = new System.Drawing.Size(155, 22);
            this.natisniTSMI.Text = "Natisni";
            this.natisniTSMI.Click += new System.EventHandler(this.natisniTSMI_Click);
            // 
            // predogledTiskaTSMI
            // 
            this.predogledTiskaTSMI.Name = "predogledTiskaTSMI";
            this.predogledTiskaTSMI.Size = new System.Drawing.Size(155, 22);
            this.predogledTiskaTSMI.Text = "Predogled tiska";
            this.predogledTiskaTSMI.Click += new System.EventHandler(this.predogledTiskaTSMI_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(152, 6);
            // 
            // izhodTSMI
            // 
            this.izhodTSMI.Image = ((System.Drawing.Image)(resources.GetObject("izhodTSMI.Image")));
            this.izhodTSMI.Name = "izhodTSMI";
            this.izhodTSMI.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.izhodTSMI.Size = new System.Drawing.Size(155, 22);
            this.izhodTSMI.Text = "Izhod";
            this.izhodTSMI.Click += new System.EventHandler(this.izhodTSMI_Click);
            // 
            // urediToolStripMenuItem
            // 
            this.urediToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.razveljaviTSMI,
            this.ponoviTSMI,
            this.toolStripSeparator8,
            this.kopirajTSMI,
            this.izreziTSMI,
            this.prilepiTSMI});
            this.urediToolStripMenuItem.Name = "urediToolStripMenuItem";
            this.urediToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.urediToolStripMenuItem.Text = "Uredi";
            // 
            // razveljaviTSMI
            // 
            this.razveljaviTSMI.Image = ((System.Drawing.Image)(resources.GetObject("razveljaviTSMI.Image")));
            this.razveljaviTSMI.Name = "razveljaviTSMI";
            this.razveljaviTSMI.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.razveljaviTSMI.Size = new System.Drawing.Size(166, 22);
            this.razveljaviTSMI.Text = "Razveljavi";
            this.razveljaviTSMI.Click += new System.EventHandler(this.razveljaviTSMI_Click);
            // 
            // ponoviTSMI
            // 
            this.ponoviTSMI.Image = ((System.Drawing.Image)(resources.GetObject("ponoviTSMI.Image")));
            this.ponoviTSMI.Name = "ponoviTSMI";
            this.ponoviTSMI.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Y)));
            this.ponoviTSMI.Size = new System.Drawing.Size(166, 22);
            this.ponoviTSMI.Text = "Ponovi";
            this.ponoviTSMI.Click += new System.EventHandler(this.ponoviTSMI_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(163, 6);
            // 
            // kopirajTSMI
            // 
            this.kopirajTSMI.Image = ((System.Drawing.Image)(resources.GetObject("kopirajTSMI.Image")));
            this.kopirajTSMI.Name = "kopirajTSMI";
            this.kopirajTSMI.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.kopirajTSMI.Size = new System.Drawing.Size(166, 22);
            this.kopirajTSMI.Text = "Kopiraj";
            this.kopirajTSMI.Click += new System.EventHandler(this.kopirajTSMI_Click);
            // 
            // izreziTSMI
            // 
            this.izreziTSMI.Image = ((System.Drawing.Image)(resources.GetObject("izreziTSMI.Image")));
            this.izreziTSMI.Name = "izreziTSMI";
            this.izreziTSMI.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.izreziTSMI.Size = new System.Drawing.Size(166, 22);
            this.izreziTSMI.Text = "Izreži";
            this.izreziTSMI.Click += new System.EventHandler(this.izreziTSMI_Click);
            // 
            // prilepiTSMI
            // 
            this.prilepiTSMI.Image = ((System.Drawing.Image)(resources.GetObject("prilepiTSMI.Image")));
            this.prilepiTSMI.Name = "prilepiTSMI";
            this.prilepiTSMI.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.prilepiTSMI.Size = new System.Drawing.Size(166, 22);
            this.prilepiTSMI.Text = "Prilepi";
            this.prilepiTSMI.Click += new System.EventHandler(this.prilepiTSMI_Click);
            // 
            // oblikaToolStripMenuItem
            // 
            this.oblikaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pisavaTSMI,
            this.barvaPisaveTSMI,
            this.barvaOzadjaTSMI,
            this.toolStripSeparator3,
            this.levaPoravnavaTSMI,
            this.sredinskaPoravnavaTSMI,
            this.desnaPoravnavaTSMI});
            this.oblikaToolStripMenuItem.Name = "oblikaToolStripMenuItem";
            this.oblikaToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.oblikaToolStripMenuItem.Text = "Oblika";
            // 
            // pisavaTSMI
            // 
            this.pisavaTSMI.Image = ((System.Drawing.Image)(resources.GetObject("pisavaTSMI.Image")));
            this.pisavaTSMI.Name = "pisavaTSMI";
            this.pisavaTSMI.Size = new System.Drawing.Size(182, 22);
            this.pisavaTSMI.Text = "Pisava";
            this.pisavaTSMI.Click += new System.EventHandler(this.pisavaTSMI_Click);
            // 
            // barvaPisaveTSMI
            // 
            this.barvaPisaveTSMI.Image = ((System.Drawing.Image)(resources.GetObject("barvaPisaveTSMI.Image")));
            this.barvaPisaveTSMI.Name = "barvaPisaveTSMI";
            this.barvaPisaveTSMI.Size = new System.Drawing.Size(182, 22);
            this.barvaPisaveTSMI.Text = "Barva pisave";
            this.barvaPisaveTSMI.Click += new System.EventHandler(this.barvaPisaveTSMI_Click);
            // 
            // barvaOzadjaTSMI
            // 
            this.barvaOzadjaTSMI.Image = ((System.Drawing.Image)(resources.GetObject("barvaOzadjaTSMI.Image")));
            this.barvaOzadjaTSMI.Name = "barvaOzadjaTSMI";
            this.barvaOzadjaTSMI.Size = new System.Drawing.Size(182, 22);
            this.barvaOzadjaTSMI.Text = "Barva ozadja";
            this.barvaOzadjaTSMI.Click += new System.EventHandler(this.barvaOzadjaTSMI_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(179, 6);
            // 
            // levaPoravnavaTSMI
            // 
            this.levaPoravnavaTSMI.Image = ((System.Drawing.Image)(resources.GetObject("levaPoravnavaTSMI.Image")));
            this.levaPoravnavaTSMI.Name = "levaPoravnavaTSMI";
            this.levaPoravnavaTSMI.Size = new System.Drawing.Size(182, 22);
            this.levaPoravnavaTSMI.Text = "Leva poravnava";
            this.levaPoravnavaTSMI.Click += new System.EventHandler(this.levaPoravnavaTSMI_Click);
            // 
            // sredinskaPoravnavaTSMI
            // 
            this.sredinskaPoravnavaTSMI.Image = ((System.Drawing.Image)(resources.GetObject("sredinskaPoravnavaTSMI.Image")));
            this.sredinskaPoravnavaTSMI.Name = "sredinskaPoravnavaTSMI";
            this.sredinskaPoravnavaTSMI.Size = new System.Drawing.Size(182, 22);
            this.sredinskaPoravnavaTSMI.Text = "Sredinska poravnava";
            this.sredinskaPoravnavaTSMI.Click += new System.EventHandler(this.sredinskaPoravnavaTSMI_Click);
            // 
            // desnaPoravnavaTSMI
            // 
            this.desnaPoravnavaTSMI.Image = ((System.Drawing.Image)(resources.GetObject("desnaPoravnavaTSMI.Image")));
            this.desnaPoravnavaTSMI.Name = "desnaPoravnavaTSMI";
            this.desnaPoravnavaTSMI.Size = new System.Drawing.Size(182, 22);
            this.desnaPoravnavaTSMI.Text = "Desna poravnava";
            this.desnaPoravnavaTSMI.Click += new System.EventHandler(this.desnaPoravnavaTSMI_Click);
            // 
            // pogledToolStripMenuItem
            // 
            this.pogledToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.orodnaVrsticaTSMI,
            this.statusnaVrsticaTSMI,
            this.toolStripSeparator10,
            this.temaTSMI});
            this.pogledToolStripMenuItem.Name = "pogledToolStripMenuItem";
            this.pogledToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.pogledToolStripMenuItem.Text = "Pogled";
            // 
            // orodnaVrsticaTSMI
            // 
            this.orodnaVrsticaTSMI.Image = ((System.Drawing.Image)(resources.GetObject("orodnaVrsticaTSMI.Image")));
            this.orodnaVrsticaTSMI.Name = "orodnaVrsticaTSMI";
            this.orodnaVrsticaTSMI.Size = new System.Drawing.Size(156, 22);
            this.orodnaVrsticaTSMI.Text = "Orodna vrstica";
            this.orodnaVrsticaTSMI.Click += new System.EventHandler(this.orodnaVrsticaTSMI_Click);
            // 
            // statusnaVrsticaTSMI
            // 
            this.statusnaVrsticaTSMI.Image = ((System.Drawing.Image)(resources.GetObject("statusnaVrsticaTSMI.Image")));
            this.statusnaVrsticaTSMI.Name = "statusnaVrsticaTSMI";
            this.statusnaVrsticaTSMI.Size = new System.Drawing.Size(156, 22);
            this.statusnaVrsticaTSMI.Text = "Statusna vrstica";
            this.statusnaVrsticaTSMI.Click += new System.EventHandler(this.statusnaVrsticaTSMI_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(153, 6);
            // 
            // temaTSMI
            // 
            this.temaTSMI.Image = ((System.Drawing.Image)(resources.GetObject("temaTSMI.Image")));
            this.temaTSMI.Name = "temaTSMI";
            this.temaTSMI.Size = new System.Drawing.Size(156, 22);
            this.temaTSMI.Text = "Svetli način";
            this.temaTSMI.Click += new System.EventHandler(this.temaTSMI_Click);
            // 
            // oAplikacijiToolStripMenuItem
            // 
            this.oAplikacijiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pomocTSMI,
            this.opisTSMI,
            this.avtorTSMI});
            this.oAplikacijiToolStripMenuItem.Name = "oAplikacijiToolStripMenuItem";
            this.oAplikacijiToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.oAplikacijiToolStripMenuItem.Text = "O Aplikaciji";
            // 
            // pomocTSMI
            // 
            this.pomocTSMI.Name = "pomocTSMI";
            this.pomocTSMI.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.pomocTSMI.Size = new System.Drawing.Size(131, 22);
            this.pomocTSMI.Text = "Pomoč";
            this.pomocTSMI.Click += new System.EventHandler(this.pomocTSMI_Click);
            // 
            // opisTSMI
            // 
            this.opisTSMI.Name = "opisTSMI";
            this.opisTSMI.Size = new System.Drawing.Size(131, 22);
            this.opisTSMI.Text = "Opis";
            this.opisTSMI.Click += new System.EventHandler(this.opisTSMI_Click);
            // 
            // avtorTSMI
            // 
            this.avtorTSMI.Name = "avtorTSMI";
            this.avtorTSMI.Size = new System.Drawing.Size(131, 22);
            this.avtorTSMI.Text = "Avtor";
            this.avtorTSMI.Click += new System.EventHandler(this.avtorTSMI_Click);
            // 
            // contextMenuStrip
            // 
            this.contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kopirajCM,
            this.izreziCM,
            this.prilepiCM,
            this.nastaviBarvoPisaveCM,
            this.nastaviBarvoOzadjaCM});
            this.contextMenuStrip.Name = "contextMenuStrip1";
            this.contextMenuStrip.Size = new System.Drawing.Size(184, 114);
            // 
            // kopirajCM
            // 
            this.kopirajCM.Image = ((System.Drawing.Image)(resources.GetObject("kopirajCM.Image")));
            this.kopirajCM.Name = "kopirajCM";
            this.kopirajCM.Size = new System.Drawing.Size(183, 22);
            this.kopirajCM.Text = "Kopiraj";
            this.kopirajCM.Click += new System.EventHandler(this.kopirajCM_Click);
            // 
            // izreziCM
            // 
            this.izreziCM.Image = ((System.Drawing.Image)(resources.GetObject("izreziCM.Image")));
            this.izreziCM.Name = "izreziCM";
            this.izreziCM.Size = new System.Drawing.Size(183, 22);
            this.izreziCM.Text = "Izreži";
            this.izreziCM.Click += new System.EventHandler(this.izreziCM_Click);
            // 
            // prilepiCM
            // 
            this.prilepiCM.Image = ((System.Drawing.Image)(resources.GetObject("prilepiCM.Image")));
            this.prilepiCM.Name = "prilepiCM";
            this.prilepiCM.Size = new System.Drawing.Size(183, 22);
            this.prilepiCM.Text = "Prilepi";
            this.prilepiCM.Click += new System.EventHandler(this.prilepiCM_Click);
            // 
            // nastaviBarvoPisaveCM
            // 
            this.nastaviBarvoPisaveCM.Image = ((System.Drawing.Image)(resources.GetObject("nastaviBarvoPisaveCM.Image")));
            this.nastaviBarvoPisaveCM.Name = "nastaviBarvoPisaveCM";
            this.nastaviBarvoPisaveCM.Size = new System.Drawing.Size(183, 22);
            this.nastaviBarvoPisaveCM.Text = "Nastavi barvo pisave";
            this.nastaviBarvoPisaveCM.Click += new System.EventHandler(this.nastaviBarvoPisaveCM_Click);
            // 
            // nastaviBarvoOzadjaCM
            // 
            this.nastaviBarvoOzadjaCM.Image = ((System.Drawing.Image)(resources.GetObject("nastaviBarvoOzadjaCM.Image")));
            this.nastaviBarvoOzadjaCM.Name = "nastaviBarvoOzadjaCM";
            this.nastaviBarvoOzadjaCM.Size = new System.Drawing.Size(183, 22);
            this.nastaviBarvoOzadjaCM.Text = "Nastavi barvo ozadja";
            this.nastaviBarvoOzadjaCM.Click += new System.EventHandler(this.nastaviBarvoOzadjaCM_Click);
            // 
            // toolbox
            // 
            this.toolbox.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.toolbox.GripMargin = new System.Windows.Forms.Padding(0);
            this.toolbox.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolbox.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolboxNova,
            this.toolStripSeparator4,
            this.toolboxOdpri,
            this.toolboxShrani,
            this.toolboxNatisni,
            this.toolStripSeparator9,
            this.toolboxRazveljavi,
            this.toolboxPonovi,
            this.toolboxKopiraj,
            this.toolboxIzrezi,
            this.toolboxPrilepi,
            this.toolStripSeparator5,
            this.toolboxPisava,
            this.toolboxBarvaFore,
            this.toolboxBarvaBack,
            this.toolStripSeparator6,
            this.toolboxLevo,
            this.toolboxSredinska,
            this.toolboxDesno,
            this.toolStripSeparator7,
            this.toolboxTema,
            this.toolStripSeparator11,
            this.toolboxZakleniOrodno});
            this.toolbox.Location = new System.Drawing.Point(0, 24);
            this.toolbox.Name = "toolbox";
            this.toolbox.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
            this.toolbox.Size = new System.Drawing.Size(741, 42);
            this.toolbox.TabIndex = 1;
            this.toolbox.Text = "Orodna vrstica";
            // 
            // toolboxNova
            // 
            this.toolboxNova.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolboxNova.Image = ((System.Drawing.Image)(resources.GetObject("toolboxNova.Image")));
            this.toolboxNova.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolboxNova.Name = "toolboxNova";
            this.toolboxNova.Size = new System.Drawing.Size(36, 36);
            this.toolboxNova.Text = "Nova beležka";
            this.toolboxNova.Click += new System.EventHandler(this.toolboxNova_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 39);
            // 
            // toolboxOdpri
            // 
            this.toolboxOdpri.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolboxOdpri.Image = ((System.Drawing.Image)(resources.GetObject("toolboxOdpri.Image")));
            this.toolboxOdpri.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolboxOdpri.Name = "toolboxOdpri";
            this.toolboxOdpri.Size = new System.Drawing.Size(36, 36);
            this.toolboxOdpri.Text = "Odpri datoteko";
            this.toolboxOdpri.Click += new System.EventHandler(this.toolboxOdpri_Click);
            // 
            // toolboxShrani
            // 
            this.toolboxShrani.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolboxShrani.Image = ((System.Drawing.Image)(resources.GetObject("toolboxShrani.Image")));
            this.toolboxShrani.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolboxShrani.Name = "toolboxShrani";
            this.toolboxShrani.Size = new System.Drawing.Size(36, 36);
            this.toolboxShrani.Text = "Shrani beležko";
            this.toolboxShrani.Click += new System.EventHandler(this.toolboxShrani_Click);
            // 
            // toolboxNatisni
            // 
            this.toolboxNatisni.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolboxNatisni.Image = global::Vaja13_VidSinko.Properties.Resources.printing_446991;
            this.toolboxNatisni.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolboxNatisni.Name = "toolboxNatisni";
            this.toolboxNatisni.Size = new System.Drawing.Size(36, 36);
            this.toolboxNatisni.Text = "Natisni";
            this.toolboxNatisni.Click += new System.EventHandler(this.toolboxNatisni_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(6, 39);
            // 
            // toolboxRazveljavi
            // 
            this.toolboxRazveljavi.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolboxRazveljavi.Image = ((System.Drawing.Image)(resources.GetObject("toolboxRazveljavi.Image")));
            this.toolboxRazveljavi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolboxRazveljavi.Name = "toolboxRazveljavi";
            this.toolboxRazveljavi.Size = new System.Drawing.Size(36, 36);
            this.toolboxRazveljavi.Text = "Razveljavi";
            this.toolboxRazveljavi.Click += new System.EventHandler(this.toolboxRazveljavi_Click);
            // 
            // toolboxPonovi
            // 
            this.toolboxPonovi.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolboxPonovi.Image = ((System.Drawing.Image)(resources.GetObject("toolboxPonovi.Image")));
            this.toolboxPonovi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolboxPonovi.Name = "toolboxPonovi";
            this.toolboxPonovi.Size = new System.Drawing.Size(36, 36);
            this.toolboxPonovi.Text = "Ponovi";
            this.toolboxPonovi.Click += new System.EventHandler(this.toolboxPonovi_Click);
            // 
            // toolboxKopiraj
            // 
            this.toolboxKopiraj.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolboxKopiraj.Image = ((System.Drawing.Image)(resources.GetObject("toolboxKopiraj.Image")));
            this.toolboxKopiraj.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolboxKopiraj.Name = "toolboxKopiraj";
            this.toolboxKopiraj.Size = new System.Drawing.Size(36, 36);
            this.toolboxKopiraj.Text = "Kopiraj";
            this.toolboxKopiraj.Click += new System.EventHandler(this.toolboxKopiraj_Click);
            // 
            // toolboxIzrezi
            // 
            this.toolboxIzrezi.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolboxIzrezi.Image = ((System.Drawing.Image)(resources.GetObject("toolboxIzrezi.Image")));
            this.toolboxIzrezi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolboxIzrezi.Name = "toolboxIzrezi";
            this.toolboxIzrezi.Size = new System.Drawing.Size(36, 36);
            this.toolboxIzrezi.Text = "Izreži";
            this.toolboxIzrezi.Click += new System.EventHandler(this.toolboxIzrezi_Click);
            // 
            // toolboxPrilepi
            // 
            this.toolboxPrilepi.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolboxPrilepi.Image = ((System.Drawing.Image)(resources.GetObject("toolboxPrilepi.Image")));
            this.toolboxPrilepi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolboxPrilepi.Name = "toolboxPrilepi";
            this.toolboxPrilepi.Size = new System.Drawing.Size(36, 36);
            this.toolboxPrilepi.Text = "Prilepi";
            this.toolboxPrilepi.Click += new System.EventHandler(this.toolboxPrilepi_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 39);
            // 
            // toolboxPisava
            // 
            this.toolboxPisava.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolboxPisava.Image = ((System.Drawing.Image)(resources.GetObject("toolboxPisava.Image")));
            this.toolboxPisava.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolboxPisava.Name = "toolboxPisava";
            this.toolboxPisava.Size = new System.Drawing.Size(36, 36);
            this.toolboxPisava.Text = "Nastavi pisavo";
            this.toolboxPisava.Click += new System.EventHandler(this.toolboxPisava_Click);
            // 
            // toolboxBarvaFore
            // 
            this.toolboxBarvaFore.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolboxBarvaFore.Image = ((System.Drawing.Image)(resources.GetObject("toolboxBarvaFore.Image")));
            this.toolboxBarvaFore.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolboxBarvaFore.Name = "toolboxBarvaFore";
            this.toolboxBarvaFore.Size = new System.Drawing.Size(36, 36);
            this.toolboxBarvaFore.Text = "Nastavi barvo pisave";
            this.toolboxBarvaFore.Click += new System.EventHandler(this.toolboxBarvaFore_Click);
            // 
            // toolboxBarvaBack
            // 
            this.toolboxBarvaBack.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolboxBarvaBack.Image = ((System.Drawing.Image)(resources.GetObject("toolboxBarvaBack.Image")));
            this.toolboxBarvaBack.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolboxBarvaBack.Name = "toolboxBarvaBack";
            this.toolboxBarvaBack.Size = new System.Drawing.Size(36, 36);
            this.toolboxBarvaBack.Text = "Nastavi barvo ozadja";
            this.toolboxBarvaBack.Click += new System.EventHandler(this.toolboxBarvaBack_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 39);
            // 
            // toolboxLevo
            // 
            this.toolboxLevo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolboxLevo.Image = ((System.Drawing.Image)(resources.GetObject("toolboxLevo.Image")));
            this.toolboxLevo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolboxLevo.Name = "toolboxLevo";
            this.toolboxLevo.Size = new System.Drawing.Size(36, 36);
            this.toolboxLevo.Text = "Leva poravnava";
            this.toolboxLevo.Click += new System.EventHandler(this.toolboxLevo_Click);
            // 
            // toolboxSredinska
            // 
            this.toolboxSredinska.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolboxSredinska.Image = ((System.Drawing.Image)(resources.GetObject("toolboxSredinska.Image")));
            this.toolboxSredinska.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolboxSredinska.Name = "toolboxSredinska";
            this.toolboxSredinska.Size = new System.Drawing.Size(36, 36);
            this.toolboxSredinska.Text = "Sredinska poravnava";
            this.toolboxSredinska.Click += new System.EventHandler(this.toolboxSredinska_Click);
            // 
            // toolboxDesno
            // 
            this.toolboxDesno.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolboxDesno.Image = global::Vaja13_VidSinko.Properties.Resources.paragraph_4273768;
            this.toolboxDesno.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolboxDesno.Name = "toolboxDesno";
            this.toolboxDesno.Size = new System.Drawing.Size(36, 36);
            this.toolboxDesno.Text = "Desna poravnava";
            this.toolboxDesno.Click += new System.EventHandler(this.toolboxDesno_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 39);
            // 
            // toolboxTema
            // 
            this.toolboxTema.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolboxTema.Image = ((System.Drawing.Image)(resources.GetObject("toolboxTema.Image")));
            this.toolboxTema.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolboxTema.Name = "toolboxTema";
            this.toolboxTema.Size = new System.Drawing.Size(36, 36);
            this.toolboxTema.Text = "Svetli način";
            this.toolboxTema.Click += new System.EventHandler(this.toolboxTema_Click);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(6, 39);
            // 
            // toolboxZakleniOrodno
            // 
            this.toolboxZakleniOrodno.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolboxZakleniOrodno.Image = ((System.Drawing.Image)(resources.GetObject("toolboxZakleniOrodno.Image")));
            this.toolboxZakleniOrodno.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolboxZakleniOrodno.Name = "toolboxZakleniOrodno";
            this.toolboxZakleniOrodno.Size = new System.Drawing.Size(36, 36);
            this.toolboxZakleniOrodno.Text = "Zakleni orodno vrstico";
            this.toolboxZakleniOrodno.Click += new System.EventHandler(this.toolboxZakleniOrodno_Click);
            // 
            // richtxtTekst
            // 
            this.richtxtTekst.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richtxtTekst.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richtxtTekst.Location = new System.Drawing.Point(0, 69);
            this.richtxtTekst.Name = "richtxtTekst";
            this.richtxtTekst.Size = new System.Drawing.Size(741, 392);
            this.richtxtTekst.TabIndex = 2;
            this.richtxtTekst.Text = "";
            this.richtxtTekst.TextChanged += new System.EventHandler(this.richtxtTekst_TextChanged);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSTznakov,
            this.toolstripSepparator,
            this.toolStripDatum});
            this.statusStrip.Location = new System.Drawing.Point(0, 439);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(741, 22);
            this.statusStrip.TabIndex = 3;
            this.statusStrip.Text = "Statusna vrstica";
            // 
            // toolStripSTznakov
            // 
            this.toolStripSTznakov.Name = "toolStripSTznakov";
            this.toolStripSTznakov.Size = new System.Drawing.Size(88, 17);
            this.toolStripSTznakov.Text = "Število znakov: ";
            // 
            // toolstripSepparator
            // 
            this.toolstripSepparator.Name = "toolstripSepparator";
            this.toolstripSepparator.Size = new System.Drawing.Size(16, 17);
            this.toolstripSepparator.Text = " | ";
            // 
            // toolStripDatum
            // 
            this.toolStripDatum.Name = "toolStripDatum";
            this.toolStripDatum.Size = new System.Drawing.Size(43, 17);
            this.toolStripDatum.Text = "Datum";
            // 
            // openFileDialog
            // 
            this.openFileDialog.Title = "Odpri že shranjeno datoteko";
            // 
            // printPreviewDialog
            // 
            this.printPreviewDialog.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog.Enabled = true;
            this.printPreviewDialog.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog.Icon")));
            this.printPreviewDialog.Name = "printPreviewDialog";
            this.printPreviewDialog.Visible = false;
            // 
            // printDialog
            // 
            this.printDialog.UseEXDialog = true;
            // 
            // helpProvider
            // 
            this.helpProvider.HelpNamespace = "Belezka.chm";
            // 
            // Belezka
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(741, 461);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.richtxtTekst);
            this.Controls.Add(this.toolbox);
            this.Controls.Add(this.menuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip;
            this.Name = "Belezka";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Beležko";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Belezka_FormClosing);
            this.Load += new System.EventHandler(this.Belezka_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.contextMenuStrip.ResumeLayout(false);
            this.toolbox.ResumeLayout(false);
            this.toolbox.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem datotekaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem novaTSMI;
        private System.Windows.Forms.ToolStripMenuItem odpriTSMI;
        private System.Windows.Forms.ToolStripMenuItem shraniTSMI;
        private System.Windows.Forms.ToolStripMenuItem izhodTSMI;
        private System.Windows.Forms.ToolStripMenuItem oblikaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pisavaTSMI;
        private System.Windows.Forms.ToolStripMenuItem barvaPisaveTSMI;
        private System.Windows.Forms.ToolStripMenuItem barvaOzadjaTSMI;
        private System.Windows.Forms.ToolStripMenuItem levaPoravnavaTSMI;
        private System.Windows.Forms.ToolStripMenuItem sredinskaPoravnavaTSMI;
        private System.Windows.Forms.ToolStripMenuItem desnaPoravnavaTSMI;
        private System.Windows.Forms.ToolStripMenuItem pogledToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem orodnaVrsticaTSMI;
        private System.Windows.Forms.ToolStripMenuItem statusnaVrsticaTSMI;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip;
        private System.Windows.Forms.ToolStrip toolbox;
        private System.Windows.Forms.ToolStripButton toolboxNova;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton toolboxOdpri;
        private System.Windows.Forms.ToolStripButton toolboxShrani;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton toolboxPisava;
        private System.Windows.Forms.ToolStripButton toolboxBarvaFore;
        private System.Windows.Forms.ToolStripButton toolboxBarvaBack;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton toolboxLevo;
        private System.Windows.Forms.ToolStripButton toolboxSredinska;
        private System.Windows.Forms.ToolStripButton toolboxDesno;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripButton toolboxZakleniOrodno;
        private System.Windows.Forms.RichTextBox richtxtTekst;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripSTznakov;
        private System.Windows.Forms.ToolStripStatusLabel toolstripSepparator;
        private System.Windows.Forms.ToolStripStatusLabel toolStripDatum;
        private System.Windows.Forms.ColorDialog colorDialog;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.ToolStripMenuItem urediToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem razveljaviTSMI;
        private System.Windows.Forms.ToolStripMenuItem ponoviTSMI;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem kopirajTSMI;
        private System.Windows.Forms.ToolStripMenuItem izreziTSMI;
        private System.Windows.Forms.ToolStripMenuItem prilepiTSMI;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripButton toolboxRazveljavi;
        private System.Windows.Forms.ToolStripButton toolboxPonovi;
        private System.Windows.Forms.ToolStripButton toolboxKopiraj;
        private System.Windows.Forms.ToolStripButton toolboxIzrezi;
        private System.Windows.Forms.ToolStripButton toolboxPrilepi;
        private System.Windows.Forms.ToolStripMenuItem kopirajCM;
        private System.Windows.Forms.ToolStripMenuItem izreziCM;
        private System.Windows.Forms.ToolStripMenuItem prilepiCM;
        private System.Windows.Forms.ToolStripMenuItem nastaviBarvoPisaveCM;
        private System.Windows.Forms.ToolStripMenuItem nastaviBarvoOzadjaCM;
        private System.Windows.Forms.ToolStripMenuItem oAplikacijiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem opisTSMI;
        private System.Windows.Forms.ToolStripMenuItem pomocTSMI;
        private System.Windows.Forms.ToolStripMenuItem avtorTSMI;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripMenuItem temaTSMI;
        private System.Windows.Forms.ToolStripButton toolboxTema;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripMenuItem natisniTSMI;
        private System.Windows.Forms.ToolStripButton toolboxNatisni;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog;
        private System.Windows.Forms.PrintDialog printDialog;
        private System.Drawing.Printing.PrintDocument printDocument;
        private System.Windows.Forms.ToolStripMenuItem predogledTiskaTSMI;
        private System.Windows.Forms.HelpProvider helpProvider;
    }
}

