﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Runtime.InteropServices;
using System.Drawing.Printing;
using System.Runtime.CompilerServices;





namespace Vaja13_VidSinko
{
    public partial class Belezka : Form
    {
        // printanje - chatGPT (win32 struktura??)
        [StructLayout(LayoutKind.Sequential)]
        private struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct CHARRANGE
        {
            public int cpMin;
            public int cpMax;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct FORMATRANGE
        {
            public IntPtr hdc;
            public IntPtr hdcTarget;
            public RECT rc;
            public RECT rcPage;
            public CHARRANGE chrg;
        }

        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wp, IntPtr lp);

        private const int EM_FORMATRANGE = 0x439;


        private int printCharIndex;
        private PrintDocument pd = new PrintDocument();

        // ---- printanje - chatGPT ---- //



        private bool orodnaVrsticaZaklenjena = false;
        private bool spremembaDokumenta = false;

        private bool orodnaVrsticaVidna = true;
        private bool statusnaVrsticaVidna = true;

        private bool temniNacin = false;

        public Belezka()
        {
            InitializeComponent();
        }

        private void Belezka_Load(object sender, EventArgs e)
        {
            toolStripDatum.Text = DateTime.Now.ToString("dd. MMMM yyyy");

            // Undo - Redo disable
            toolboxRazveljavi.Enabled = false;
            toolboxPonovi.Enabled = false;
            razveljaviTSMI.Enabled = false;
            ponoviTSMI.Enabled = false;

            this.temniNacin = false;


            // Enable help provider
            helpProvider.HelpNamespace = "Belezka.chm";

            // Assign help pages
            helpProvider.SetHelpNavigator(this, HelpNavigator.TableOfContents);
            helpProvider.SetHelpKeyword(this, "index.html");



        }
        private void izhodTSMI_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Belezka_FormClosing(object sender, FormClosingEventArgs e)  // zapiranje aplikacije -> shranjevanje dokumenta
        {
            if (this.spremembaDokumenta)
            {
                DialogResult result = MessageBox.Show("Ali želite shraniti trenutni dokument?", "Beležko", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    ShraniDokument();
                }
                else if (result == DialogResult.Cancel)
                {
                    e.Cancel = true; // prekliči zapiranje
                }
            }
        }


        private void richtxtTekst_TextChanged(object sender, EventArgs e) // ko se spremeni besedilo
        {
            toolStripSTznakov.Text = "Število znakov: " + richtxtTekst.Text.Length;
            toolStripDatum.Text = DateTime.Now.ToString("dd. MMMM yyyy");

            if(richtxtTekst.TextLength > 0)    
                this.spremembaDokumenta = true;

            else
                this.spremembaDokumenta = false;


            if (richtxtTekst.CanUndo) // če je možno razveljaviti -> omogoči gumb, sicer onemogoči
            {
                toolboxRazveljavi.Enabled = true;
                razveljaviTSMI.Enabled = true;
            }
            else
            {
                toolboxRazveljavi.Enabled = false;
                razveljaviTSMI.Enabled = false;
            }

            if (richtxtTekst.CanRedo) // če je možno ponoviti -> omogoči gumb, sicer onemogoči 
            {
                toolboxPonovi.Enabled = true;
                ponoviTSMI.Enabled = true;
            }
            else
            {
                toolboxPonovi.Enabled = false;
                ponoviTSMI.Enabled = false;
            }
        }




        // ------------------zakleni/odkleni orodno vrstico----------------- //
        private void toolboxZakleniOrodno_Click(object sender, EventArgs e) // zakleni ali odkleni orodno vrstico
        {
            if (this.orodnaVrsticaZaklenjena)
            {
                OdkleniOrodnoVrstico();
                this.orodnaVrsticaZaklenjena = false;

                toolboxZakleniOrodno.Image = Properties.Resources.padlock_159069;
                toolboxZakleniOrodno.Text = "Zakleni orodno vrstico";
                toolboxZakleniOrodno.ToolTipText = "Zakleni orodno vrstico";
            }
            else
            {
                ZakleniOrodnoVrstico();
                this.orodnaVrsticaZaklenjena = true;

                toolboxZakleniOrodno.Image = Properties.Resources.unlock_9502765;
                toolboxZakleniOrodno.Text = "Odkleni orodno vrstico";
                toolboxZakleniOrodno.ToolTipText = "Odkleni orodno vrstico";
            }
        }
        private void OdkleniOrodnoVrstico()
        {
            toolboxNova.Enabled = true;
            toolboxOdpri.Enabled = true;
            toolboxShrani.Enabled = true;
            toolboxPisava.Enabled = true;
            toolboxBarvaFore.Enabled = true;
            toolboxBarvaBack.Enabled = true;
            toolboxLevo.Enabled = true;
            toolboxSredinska.Enabled = true;
            toolboxDesno.Enabled = true;

            toolboxRazveljavi.Enabled = true;
            toolboxPonovi.Enabled = true;
            toolboxKopiraj.Enabled = true;
            toolboxIzrezi.Enabled = true;
            toolboxPrilepi.Enabled = true;
            toolboxNatisni.Enabled = true;
        }
        private void ZakleniOrodnoVrstico()
        {
            toolboxNova.Enabled = false;
            toolboxOdpri.Enabled = false;
            toolboxShrani.Enabled = false;
            toolboxPisava.Enabled = false;
            toolboxBarvaFore.Enabled = false;
            toolboxBarvaBack.Enabled = false;
            toolboxLevo.Enabled = false;
            toolboxSredinska.Enabled = false;
            toolboxDesno.Enabled = false;

            toolboxRazveljavi.Enabled = false;
            toolboxPonovi.Enabled = false;
            toolboxKopiraj.Enabled = false;
            toolboxIzrezi.Enabled = false;
            toolboxPrilepi.Enabled = false;
            toolboxNatisni.Enabled = false;

        }
        // ----------------------------------------------------------------- //



        // ------------------spremeni poravnavo besedila-------------------- //
        private void SpremeniPoravnavo(ToolStripButton poravnava) // glavna funkcija za spremembo
        {
            if (richtxtTekst.SelectionLength > 0)
            {
                if (poravnava == toolboxLevo)
                {
                    richtxtTekst.SelectionAlignment = HorizontalAlignment.Left;
                }
                else if (poravnava == toolboxSredinska)
                {
                    richtxtTekst.SelectionAlignment = HorizontalAlignment.Center;
                }
                else if (poravnava == toolboxDesno)
                {
                    richtxtTekst.SelectionAlignment = HorizontalAlignment.Right;
                }
            }
            else { }
        }

        private void toolboxLevo_Click(object sender, EventArgs e)
        {
            SpremeniPoravnavo(toolboxLevo);
        }
        private void toolboxSredinska_Click(object sender, EventArgs e)
        {
            SpremeniPoravnavo(toolboxSredinska);
        }
        private void toolboxDesno_Click(object sender, EventArgs e)
        {
            SpremeniPoravnavo(toolboxDesno);
        }

        private void levaPoravnavaTSMI_Click(object sender, EventArgs e)
        {
            SpremeniPoravnavo(toolboxLevo);
        }
        private void sredinskaPoravnavaTSMI_Click(object sender, EventArgs e)
        {
            SpremeniPoravnavo(toolboxSredinska);
        }
        private void desnaPoravnavaTSMI_Click(object sender, EventArgs e)
        {
            SpremeniPoravnavo(toolboxDesno);
        }
        // ----------------------------------------------------------------- //



        // ------------------spremeni barvo besedila------------------------ //
        private void SpremeniBarvo(ToolStripButton barva) // glavna funkcija za spremembo
        {
            ColorDialog colorDialog = new ColorDialog();
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                if (barva == toolboxBarvaFore)
                {
                    if (richtxtTekst.SelectionLength > 0)
                    {
                        richtxtTekst.SelectionColor = colorDialog.Color;
                    }
                    else
                    {
                        richtxtTekst.ForeColor = colorDialog.Color;
                    }
                }
                else if (barva == toolboxBarvaBack)
                {
                    if (richtxtTekst.SelectionLength > 0)
                    {
                        richtxtTekst.SelectionBackColor = colorDialog.Color;
                    }
                    else
                    {
                        richtxtTekst.BackColor = colorDialog.Color;
                    }
                }
            }
        }
        private void toolboxBarvaFore_Click(object sender, EventArgs e)
        {
            SpremeniBarvo(toolboxBarvaFore);
        }
        private void toolboxBarvaBack_Click(object sender, EventArgs e)
        {
            SpremeniBarvo(toolboxBarvaBack);
        }

        private void barvaPisaveTSMI_Click(object sender, EventArgs e)
        {
            SpremeniBarvo(toolboxBarvaFore);
        }
        private void barvaOzadjaTSMI_Click(object sender, EventArgs e)
        {
            SpremeniBarvo(toolboxBarvaBack);
        }

        private void nastaviBarvoPisaveCM_Click(object sender, EventArgs e)
        {
            SpremeniBarvo(toolboxBarvaFore);
        }
        private void nastaviBarvoOzadjaCM_Click(object sender, EventArgs e)
        {
            SpremeniBarvo(toolboxBarvaBack);
        }
        // ----------------------------------------------------------------- //



        // ------------------spremeni pisavo besedila----------------------- //
        private void SpremeniPisavo() // glavna funkcija za spremembo
        {
            FontDialog fontDialog = new FontDialog();
            if (fontDialog.ShowDialog() == DialogResult.OK)
            {
                if (richtxtTekst.SelectionLength > 0)
                {
                    richtxtTekst.SelectionFont = fontDialog.Font;
                }
                else
                {
                    richtxtTekst.Font = fontDialog.Font;
                }
            }
        }

        private void toolboxPisava_Click(object sender, EventArgs e)
        {
            SpremeniPisavo();
        }
        private void pisavaTSMI_Click(object sender, EventArgs e)
        {
            SpremeniPisavo();
        }
        
        // ----------------------------------------------------------------- //



        // --------------------shranjevanje dokumenta----------------------- //
        private void ShraniDokument() // glavna funkcija za shranjevanje
        {
            if (richtxtTekst.Text.Length == 0)
            {
                return;
            }

            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "RTF Files (*.rtf)|*.rtf|All files (*.*)|*.*";  // filter za datoteke
            saveFileDialog.FileName = "Beležkov dokument.rtf"; // privzeto ime datoteke
            saveFileDialog.OverwritePrompt = true; // opozori, če datoteka že obstaja

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                /* stari način brez stila
                using (StreamWriter sw = new StreamWriter(saveFileDialog.FileName))
                {
                    sw.Write(richtxtTekst.Text);
                }
                */

                richtxtTekst.SaveFile(saveFileDialog.FileName);
                this.spremembaDokumenta = false; // po shranjevanju ni več sprememb
            }
        }

        private void toolboxShrani_Click(object sender, EventArgs e)
        {
            ShraniDokument();
        }
        private void shraniTSMI_Click(object sender, EventArgs e)
        {
            ShraniDokument();
        }
        // ----------------------------------------------------------------- //



        // ------------------------nov dokument--------------------------- //
        private void NovDokument() // glavna funkcija za nov dokument
        {
            if (this.spremembaDokumenta)
            {
                DialogResult result = MessageBox.Show("Ali želite shraniti trenutni dokument?", "Beležko", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    ShraniDokument();
                    richtxtTekst.Clear();
                    this.spremembaDokumenta = false; 
                }
                else if (result == DialogResult.No)
                {
                    richtxtTekst.Clear();
                    this.spremembaDokumenta = false; 
                }
            }
            else {
                richtxtTekst.Clear();
                this.spremembaDokumenta = false; // po ustvarjanju novega dokumenta ni več sprememb
            }
        }

        private void toolboxNova_Click(object sender, EventArgs e)
        {
            NovDokument();
        }
        private void novaTSMI_Click(object sender, EventArgs e)
        {
            NovDokument();
        }
        // ----------------------------------------------------------------- //



        // ------------------------odpri dokument-------------------------- //
        private void OdpriDokument() // glavna funkcija za odpiranje dokumenta
        {
            if (this.spremembaDokumenta)
            {
                DialogResult result = MessageBox.Show("Ali želite shraniti trenutni dokument?", "Beležko", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);

                if (result == DialogResult.Cancel)
                    return;

                if (result == DialogResult.Yes)
                    ShraniDokument();
            }

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "RTF Files (*.rtf)|*.rtf|Text files (*.txt)|*.txt|All files (*.*)|*.*";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                /* stari način brez stila
                using (StreamReader sr = new StreamReader(openFileDialog.FileName))
                {
                    richtxtTekst.Text = sr.ReadToEnd();
                }
                */

                richtxtTekst.LoadFile(openFileDialog.FileName);
                this.spremembaDokumenta = false;
            }

            richtxtTekst.SelectionStart = richtxtTekst.Text.Length;
        }

        private void toolboxOdpri_Click(object sender, EventArgs e)
        {
            OdpriDokument();
        }
        private void odpriTSMI_Click(object sender, EventArgs e)
        {
            OdpriDokument();
        }
        // ----------------------------------------------------------------- //



        // ------------------vidnost orodne/statusne vrstice----------------- //
        private void VidnostVrstic (ToolStripMenuItem vrstica) // glavna funkcija za vidnost vrstic
        {
            if (vrstica == orodnaVrsticaTSMI)
            {
                if (orodnaVrsticaVidna)
                {
                    toolbox.Visible = false;
                    orodnaVrsticaVidna = false;
                    orodnaVrsticaTSMI.Image = Properties.Resources.cross_17735556;
                    richtxtTekst.Location = new Point(richtxtTekst.Location.X, menuStrip.Height);
                    richtxtTekst.Size = new Size(richtxtTekst.Size.Width, richtxtTekst.Size.Height + toolbox.Height);
                }
                else
                {
                    toolbox.Visible = true;
                    orodnaVrsticaVidna = true;
                    orodnaVrsticaTSMI.Image = Properties.Resources.check_12483592;
                    richtxtTekst.Location = new Point(richtxtTekst.Location.X, menuStrip.Height + toolbox.Height);
                    richtxtTekst.Size = new Size(richtxtTekst.Size.Width, richtxtTekst.Size.Height - toolbox.Height);
                }
            }
            else if (vrstica == statusnaVrsticaTSMI)
            {
                if (statusnaVrsticaVidna)
                {
                    statusStrip.Visible = false;
                    statusnaVrsticaVidna = false;
                    statusnaVrsticaTSMI.Image = Properties.Resources.cross_17735556;
                    richtxtTekst.Size = new Size(richtxtTekst.Size.Width, richtxtTekst.Size.Height + statusStrip.Height);
                }
                else
                {
                    statusStrip.Visible = true;
                    statusnaVrsticaVidna = true;
                    statusnaVrsticaTSMI.Image = Properties.Resources.check_12483592;
                    richtxtTekst.Size = new Size(richtxtTekst.Size.Width, richtxtTekst.Size.Height - statusStrip.Height);
                }
            }
        }
        private void orodnaVrsticaTSMI_Click(object sender, EventArgs e)
        {
            VidnostVrstic(orodnaVrsticaTSMI);
        }
        private void statusnaVrsticaTSMI_Click(object sender, EventArgs e)
        {
            VidnostVrstic(statusnaVrsticaTSMI);
        }
        // ----------------------------------------------------------------- //



        // ------------------------o aplikaciji----------------------------- //  !! --- ni Pomoči --- !!
        private void pomocTSMI_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(helpProvider.HelpNamespace))
    {
        try
        {
            // Try to open the 'index.html' topic (matches your HelpKeyword), fall back to TOC if it fails
            Help.ShowHelp(this, helpProvider.HelpNamespace, HelpNavigator.Topic, "index.html");
        }
        catch (Exception)
        {
            try
            {
                Help.ShowHelp(this, helpProvider.HelpNamespace, HelpNavigator.TableOfContents);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ne morem odpreti pomoči: " + ex.Message, "Pomoč", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
    else
    {
        MessageBox.Show("Pomoč ni na voljo.", "Pomoč", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
        }
        private void opisTSMI_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Beležka je preprosta aplikacija za urejanje besedil, ki omogoča ustvarjanje, odpiranje, shranjevanje in oblikovanje dokumentov. Uporabnikom nudi osnovne funkcije za urejanje besedil, kot so spreminjanje pisave, barve in poravnave besedila. Aplikacija je zasnovana tako, da je enostavna za uporabo in primerna za hitro zapisovanje idej, beležk ali krajših dokumentov.", "Opis aplikacije", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void avtorTSMI_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Avtor aplikacije: \n\nDijak:\tVid Šinko\nRazred:\t4R3\nPredmet:\tNRPA\nMentor:\tprof. Igor Kutoš", "Avtor aplikacije", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        // ----------------------------------------------------------------- //



        // ----------------razveljavi/undo in ponovi/redo------------------- //
        private void Razveljavi() // glavna funkcija za razveljavi
        {
            if (richtxtTekst.CanUndo)
            {
                richtxtTekst.Undo();
            }
        }
        private void Ponovi() // glavna funkcija za ponovi
        {
            if (richtxtTekst.CanRedo)
            {
                richtxtTekst.Redo();
            }
        }

        private void toolboxRazveljavi_Click(object sender, EventArgs e)
        {
            Razveljavi();
        }
        private void razveljaviTSMI_Click(object sender, EventArgs e)
        {
            Razveljavi();
        }

        private void toolboxPonovi_Click(object sender, EventArgs e)
        {
            Ponovi();
        }
        private void ponoviTSMI_Click(object sender, EventArgs e)
        {
            Ponovi();
        }
        // ----------------------------------------------------------------- //



        // -----------------------copy - cut - paste------------------------ //
        private void Kopiraj() // glavna funkcija za kopiraj
        {
            if (richtxtTekst.SelectionLength > 0)
            {
                richtxtTekst.Copy();
            }
        }

        private void Izrezi() // glavna funkcija za izreži
        {
            if (richtxtTekst.SelectionLength > 0)
            {
                richtxtTekst.Cut();
            }
        }

        private void Prilepi() // glavna funkcija za prilepi
        {
            if (Clipboard.ContainsText())
            {
                richtxtTekst.Paste();
            }
        }

        private void toolboxKopiraj_Click(object sender, EventArgs e) { Kopiraj(); }
        private void kopirajTSMI_Click(object sender, EventArgs e) { Kopiraj(); }       
        private void kopirajCM_Click(object sender, EventArgs e) { Kopiraj(); }

        private void toolboxIzrezi_Click(object sender, EventArgs e) { Izrezi(); }
        private void izreziTSMI_Click(object sender, EventArgs e) { Izrezi(); }
        private void izreziCM_Click(object sender, EventArgs e) { Izrezi(); }

        private void toolboxPrilepi_Click(object sender, EventArgs e) { Prilepi(); }
        private void prilepiTSMI_Click(object sender, EventArgs e) { Prilepi(); }
        private void prilepiCM_Click(object sender, EventArgs e) { Prilepi(); }
        // ----------------------------------------------------------------- //



        // ----------------------tema aplikacije---------------------------- //
        private void SpremembaTeme() // glavna funkcija za spremembo teme
        {
            if (this.temniNacin)                                                   
            {
                this.BackColor = SystemColors.Control;
                richtxtTekst.BackColor = SystemColors.Window;
                richtxtTekst.ForeColor = SystemColors.ControlText;
                this.temniNacin = false;

                //toolbox in status strip
                toolbox.BackColor = SystemColors.GradientInactiveCaption;
                toolbox.ForeColor = SystemColors.ControlText;
                statusStrip.BackColor = SystemColors.Control;
                statusStrip.ForeColor = SystemColors.ControlText;
                                                                                                // temni način -> svetli način
                // menu strip
                menuStrip.BackColor = SystemColors.Control;
                menuStrip.ForeColor = SystemColors.ControlText;

                // spremeni ikone in besedilo za preklop teme
                toolboxTema.Image = Properties.Resources.light;
                toolboxTema.Text = "Svetla tema";
                temaTSMI.Image = Properties.Resources.light;
                temaTSMI.Text = "Svetla tema";
            }
            else
            {
                this.BackColor = SystemColors.ControlDarkDark;
                richtxtTekst.BackColor = SystemColors.ControlDark;
                richtxtTekst.ForeColor = SystemColors.ControlText;
                this.temniNacin = true;

                //toolbox in status strip
                toolbox.BackColor = SystemColors.ControlDarkDark;
                toolbox.ForeColor = SystemColors.ControlText;
                statusStrip.BackColor = SystemColors.ControlDarkDark;
                statusStrip.ForeColor = SystemColors.ControlText;
                                                                                                // svetli način -> temni način

                // menu strip
                menuStrip.BackColor = SystemColors.ControlDark;
                menuStrip.ForeColor = SystemColors.ControlText;

                // spremeni ikone in besedilo za preklop teme
                toolboxTema.Image = Properties.Resources.dark;
                toolboxTema.Text = "Temna tema";
                temaTSMI.Image = Properties.Resources.dark;
                temaTSMI.Text = "Temna tema";
            }
        }
        private void toolboxTema_Click(object sender, EventArgs e)
        {
            SpremembaTeme();
        }
        private void temaTSMI_Click(object sender, EventArgs e)
        {
            SpremembaTeme();
        }
        // ----------------------------------------------------------------- //



        // --------------natisni - chatGPT + stackOverflow------------------ //
        private void Pd_PrintPage(object sender, PrintPageEventArgs e)
        {
            RECT rect = new RECT();
            rect.Top = HundredthInchToTwips(e.MarginBounds.Top);
            rect.Bottom = HundredthInchToTwips(e.MarginBounds.Bottom);
            rect.Left = HundredthInchToTwips(e.MarginBounds.Left);
            rect.Right = HundredthInchToTwips(e.MarginBounds.Right);

            RECT page = new RECT();
            page.Top = HundredthInchToTwips(e.PageBounds.Top);
            page.Bottom = HundredthInchToTwips(e.PageBounds.Bottom);
            page.Left = HundredthInchToTwips(e.PageBounds.Left);
            page.Right = HundredthInchToTwips(e.PageBounds.Right);

            FORMATRANGE fmt = new FORMATRANGE();
            fmt.chrg.cpMin = printCharIndex;
            fmt.chrg.cpMax = -1;
            fmt.hdc = e.Graphics.GetHdc();
            fmt.hdcTarget = fmt.hdc;
            fmt.rc = rect;
            fmt.rcPage = page;

            IntPtr lparam = Marshal.AllocCoTaskMem(Marshal.SizeOf(fmt));
            Marshal.StructureToPtr(fmt, lparam, false);

            IntPtr res = SendMessage(richtxtTekst.Handle, EM_FORMATRANGE, (IntPtr)1, lparam);

            Marshal.FreeCoTaskMem(lparam);
            e.Graphics.ReleaseHdc(fmt.hdc);

            printCharIndex = res.ToInt32();
            e.HasMorePages = printCharIndex < richtxtTekst.TextLength;
        }
        private int HundredthInchToTwips(int n)
        {
            return (int)(n * 14.4);
        }
        private void NatisniDokument()
        {
            PrintDialog dlg = new PrintDialog();
            pd.PrintPage += Pd_PrintPage;
            dlg.Document = pd;

            printCharIndex = 0;

            if (dlg.ShowDialog() == DialogResult.OK)
                pd.Print();
        }
        private void PredogledTiska()
        {
            PrintPreviewDialog preview = new PrintPreviewDialog();
            pd.PrintPage += Pd_PrintPage;
            preview.Document = pd;

            printCharIndex = 0;
            preview.ShowDialog();
        }
        

        private void toolboxNatisni_Click(object sender, EventArgs e)
        {
            PredogledTiska();
            NatisniDokument();
        }
        private void natisniTSMI_Click(object sender, EventArgs e)
        {
            PredogledTiska();
            NatisniDokument();
        }

        private void predogledTiskaTSMI_Click(object sender, EventArgs e)
        {
            PredogledTiska();
        }
        // ----------------------------------------------------------------- //

        











        
    }
}
