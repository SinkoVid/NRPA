﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Vaja09_VidSInko
{
    public partial class Prijava : Form
    {
        public string upime { set; get; }
        public string geslo { set; get; }

        public bool uspesnaPrijava = false;
        public int spremenjenoGeslo = 0;
        
        private int preostaliPoiskusi = 3;

        //povezave na druga okna / razrede
        public GlavnoOkno pGlavnoOkno;
        public BinPodatki pBinPodatki;

        public Prijava()
        {
            InitializeComponent();
        }

        public Prijava(BinPodatki pBinPodatki, GlavnoOkno pGlavnoOkno)
        {
            InitializeComponent();
            this.pBinPodatki = pBinPodatki;
            this.pGlavnoOkno = pGlavnoOkno;
            this.uspesnaPrijava = false;
        }

        /*
        public Prijava(string upime, string geslo, GlavnoOkno pGlavnoOkno)
        {
            InitializeComponent();
            this.upime = upime;
            this.geslo = geslo;
            this.pGlavnoOkno = pGlavnoOkno;
            this.uspesnaPrijava = false;
        }
        */

        private void Prijava_Load(object sender, EventArgs e)
        {
            int preostaliPoiskusi = 3;
        }


        private void btnPrijava_Click(object sender, EventArgs e)
        {
            this.uspesnaPrijava = false;
            

            //logika za prijavljanje
            if(this.txtUporabniskoIme.Text == string.Empty || this.txtGeslo.Text == string.Empty)
            {
                //mankajoci podatki
                MessageBox.Show("Napaka! Niste vnesli vseh podatkov.", "Napaka", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.uspesnaPrijava = false;
            }
            //else if(this.txtUporabniskoIme.Text == this.upime && this.txtGeslo.Text == this.geslo)

            //vneseni podatki = pravi podatki -> datoteka
            else if (this.txtUporabniskoIme.Text == this.pBinPodatki.upime && this.txtGeslo.Text == this.pBinPodatki.geslo)
            {
                //MessageBox.Show("Pozdravljen šef!", "Prijava", MessageBoxButtons.OK, MessageBoxIcon.None);
                this.uspesnaPrijava = true;
            }
            else
            {
                this.uspesnaPrijava = false;
                this.preostaliPoiskusi--;

                if (this.preostaliPoiskusi == 0)
                {
                    MessageBox.Show("Napaka! Napačno uporabniško ime ali geslo!\nNimaš več poizkusov\n\nZapri aplikacijo [OK]", "Napaka", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Application.Exit();
                }
                //vneseni podatki != pravi podatki
                else if(MessageBox.Show("Napaka! Napačno uporabniško ime ali geslo!\nPreostali poizkusi: " + this.preostaliPoiskusi + "\n\nPoskusi znova [OK] ali zapri [Cancel]", "Napaka", MessageBoxButtons.OKCancel, MessageBoxIcon.Error) == DialogResult.Cancel)
                {
                    Application.Exit();
                }
                
            }

            //shrani poizkus prijave
            new BinLoginLog
            {
                upime = this.txtUporabniskoIme.Text,
                cas = DateTime.Now,
                uspesnaPrijava = Uspeh()
            }.ShraniBin();



            //ko je prijava uspešna, se dialog zapre
            if (this.uspesnaPrijava)
            {
                pGlavnoOkno.nastaviLabeloStatusBarPrijava();
                this.upime = txtUporabniskoIme.Text;
                pGlavnoOkno.Show();
                this.Close(); 
            }
            
        }

        private string Uspeh()
        {
            if (this.uspesnaPrijava) { return "DA"; }
            else { return "NE"; }
        }


        private void Prijava_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(!this.uspesnaPrijava)
            {
                Application.Exit();
            }
        }
    }
}
