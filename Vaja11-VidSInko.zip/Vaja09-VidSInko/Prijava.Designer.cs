﻿namespace Vaja09_VidSInko
{
    partial class Prijava
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Prijava));
            this.bgoxPrijava = new System.Windows.Forms.GroupBox();
            this.btnPrijava = new System.Windows.Forms.Button();
            this.txtGeslo = new System.Windows.Forms.TextBox();
            this.lblGeslo = new System.Windows.Forms.Label();
            this.txtUporabniskoIme = new System.Windows.Forms.TextBox();
            this.lblUporabniskoIme = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bgoxPrijava.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // bgoxPrijava
            // 
            this.bgoxPrijava.Controls.Add(this.btnPrijava);
            this.bgoxPrijava.Controls.Add(this.txtGeslo);
            this.bgoxPrijava.Controls.Add(this.lblGeslo);
            this.bgoxPrijava.Controls.Add(this.txtUporabniskoIme);
            this.bgoxPrijava.Controls.Add(this.lblUporabniskoIme);
            this.bgoxPrijava.Location = new System.Drawing.Point(127, 12);
            this.bgoxPrijava.Name = "bgoxPrijava";
            this.bgoxPrijava.Size = new System.Drawing.Size(254, 129);
            this.bgoxPrijava.TabIndex = 0;
            this.bgoxPrijava.TabStop = false;
            this.bgoxPrijava.Text = "Prijava šefa";
            // 
            // btnPrijava
            // 
            this.btnPrijava.Location = new System.Drawing.Point(119, 100);
            this.btnPrijava.Name = "btnPrijava";
            this.btnPrijava.Size = new System.Drawing.Size(100, 23);
            this.btnPrijava.TabIndex = 4;
            this.btnPrijava.Text = "Prijava";
            this.btnPrijava.UseVisualStyleBackColor = true;
            this.btnPrijava.Click += new System.EventHandler(this.btnPrijava_Click);
            // 
            // txtGeslo
            // 
            this.txtGeslo.Location = new System.Drawing.Point(119, 56);
            this.txtGeslo.MaximumSize = new System.Drawing.Size(100, 20);
            this.txtGeslo.MinimumSize = new System.Drawing.Size(100, 20);
            this.txtGeslo.Name = "txtGeslo";
            this.txtGeslo.PasswordChar = '*';
            this.txtGeslo.Size = new System.Drawing.Size(100, 20);
            this.txtGeslo.TabIndex = 3;
            // 
            // lblGeslo
            // 
            this.lblGeslo.AutoSize = true;
            this.lblGeslo.Location = new System.Drawing.Point(24, 59);
            this.lblGeslo.Name = "lblGeslo";
            this.lblGeslo.Size = new System.Drawing.Size(37, 13);
            this.lblGeslo.TabIndex = 2;
            this.lblGeslo.Text = "Geslo:";
            // 
            // txtUporabniskoIme
            // 
            this.txtUporabniskoIme.Location = new System.Drawing.Point(119, 29);
            this.txtUporabniskoIme.Name = "txtUporabniskoIme";
            this.txtUporabniskoIme.Size = new System.Drawing.Size(100, 20);
            this.txtUporabniskoIme.TabIndex = 1;
            // 
            // lblUporabniskoIme
            // 
            this.lblUporabniskoIme.AutoSize = true;
            this.lblUporabniskoIme.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblUporabniskoIme.Location = new System.Drawing.Point(24, 32);
            this.lblUporabniskoIme.Name = "lblUporabniskoIme";
            this.lblUporabniskoIme.Size = new System.Drawing.Size(89, 13);
            this.lblUporabniskoIme.TabIndex = 0;
            this.lblUporabniskoIme.Text = "Uporabniško ime:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Vaja09_VidSInko.Properties.Resources.user_3917688;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 129);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // Prijava
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(393, 153);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.bgoxPrijava);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Prijava";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Prijava";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Prijava_FormClosing);
            this.Load += new System.EventHandler(this.Prijava_Load);
            this.bgoxPrijava.ResumeLayout(false);
            this.bgoxPrijava.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox bgoxPrijava;
        private System.Windows.Forms.Button btnPrijava;
        private System.Windows.Forms.TextBox txtGeslo;
        private System.Windows.Forms.Label lblGeslo;
        private System.Windows.Forms.TextBox txtUporabniskoIme;
        private System.Windows.Forms.Label lblUporabniskoIme;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

