﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace Vaja09_VidSInko
{
    internal class BinLoginLog
    {
        [DisplayName("Uporabnik")]
        public string upime {  get; set; }

        [DisplayName("Čas poizkusa")]
        public DateTime cas {  get; set; }

        [DisplayName("Uspeh [DA/NE]")]
        public string uspesnaPrijava { get; set; }

        private static string pot = "BinLoginLog.bin";

        public void ShraniBin()
        {
            using (var fs = new FileStream(pot, FileMode.Append))
            {
                using (var bw = new BinaryWriter(fs, Encoding.UTF8))
                {
                    bw.Write(upime);
                    bw.Write(cas.ToBinary());
                    bw.Write(uspesnaPrijava);
                }
            }
        }


        public static List<BinLoginLog> BeriBin()
        {
            var list = new List<BinLoginLog>();

            //ce datoteka ne obstaja -> vrne prazen list
            if (!File.Exists(pot)) { return list; }

            //branje bin datoteke
            using (var fs = new FileStream(pot, FileMode.Open))
            {
                using (var br = new BinaryReader(fs, Encoding.UTF8))
                {

                    while (fs.Position < fs.Length) //while pozicija(ie. index) < celotna dolžina
                    {
                        var poizkus = new BinLoginLog
                        {
                            upime = br.ReadString(),
                            cas = DateTime.FromBinary(br.ReadInt64()),
                            uspesnaPrijava = br.ReadString(),
                        };

                        list.Add(poizkus);
                        
                    }
                }
            }

            return list;
            
        }

    }
}
