﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Vaja09_VidSInko
{
    public partial class PoizkusiPrijave : Form
    {

        public GlavnoOkno pGlavnoOkno;

        public PoizkusiPrijave()
        {
            InitializeComponent();
        }

        public PoizkusiPrijave (GlavnoOkno pGlavnoOkno)
        {
            InitializeComponent();
            this.pGlavnoOkno = pGlavnoOkno;
        }

        private void PoizkusiPrijave_Load(object sender, EventArgs e)
        {
            var log = BinLoginLog.BeriBin();
            dgvLoginLog.DataSource = log;
            dgvLoginLog.ClearSelection();

            PrestejPoizkuse(out int Uspesni, out int neUspesni);
            DrawPieChart(Uspesni, neUspesni);
        }

        private void PrestejPoizkuse(out int Uspesni, out int neUspesni)
        {
            var log = BinLoginLog.BeriBin();
            Uspesni = log.Count(x => x.uspesnaPrijava == "DA");
            neUspesni = log.Count(x => x.uspesnaPrijava == "NE");
        }


        private void DrawPieChart(int Uspesni, int neUspesni)
        {
            //reset your chart series and legends
            chPrijave.Series.Clear();
            chPrijave.Legends.Clear();

            //Add a new Legend(if needed) and do some formating
            chPrijave.Legends.Add("Legenda:");
            chPrijave.Legends[0].LegendStyle = LegendStyle.Table;
            chPrijave.Legends[0].Docking = Docking.Bottom;
            chPrijave.Legends[0].Alignment = StringAlignment.Center;
            chPrijave.Legends[0].Title = "Uspešnost poskusov prijave";
            chPrijave.Legends[0].BorderColor = Color.Black;

            //Add a new chart-series
            string seriesname = "Prijave";
            chPrijave.Series.Add(seriesname);
            //set the chart-type to "Pie"
            chPrijave.Series[seriesname].ChartType = SeriesChartType.Pie;

            //Add some datapoints so the series. in this case you can pass the values to this method
            chPrijave.Series[seriesname].Points.AddXY("Uspešni", Uspesni);
            chPrijave.Series[seriesname].Points.AddXY("Neuspešni", neUspesni);
        }
    }
}
