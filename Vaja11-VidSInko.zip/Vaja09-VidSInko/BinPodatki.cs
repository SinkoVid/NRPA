﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vaja09_VidSInko
{
    public class BinPodatki
    {
        public string upime { get; set; }
        public string geslo { get; set; }
        public int spremenjenoGeslo { get; set; }


        private static string pot = "BinPodatki.bin";

        public void ShraniBin()
        {
            using (var fs = new FileStream(pot, FileMode.Create))
            {
                using (var bw = new BinaryWriter(fs, Encoding.UTF8))
                {
                    bw.Write(this.upime);
                    bw.Write(this.geslo);
                    bw.Write(this.spremenjenoGeslo);
                }
            }
        }

        public static BinPodatki BeriBin()
        {
            if (!File.Exists(pot)) { return null; }

            using (var fs = new FileStream(pot, FileMode.Open))
            {
                using (var br = new BinaryReader(fs, Encoding.UTF8))
                {
                    return new BinPodatki
                    {
                        upime = br.ReadString(),
                        geslo = br.ReadString(),
                        spremenjenoGeslo = br.ReadInt32()
                    };
                }
            }
        }    

    }
}
