﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vaja09_VidSInko
{
    public partial class Nastavitve : Form
    {
        public Nastavitve()
        {
            InitializeComponent();
        }
        public GlavnoOkno pGlavnoOkno;


        public Nastavitve(GlavnoOkno glavnoOkno)
        {
            InitializeComponent();
            this.pGlavnoOkno = glavnoOkno;
        }

        private void Nastavitve_Load(object sender, EventArgs e)
        {

        }

        private void btnNABarva_Click(object sender, EventArgs e)
        {
            if (colorDialogNA.ShowDialog() == DialogResult.OK)
            {
                this.pGlavnoOkno.SpremeniBarvo(colorDialogNA.Color);
            }
            
        }

        private void btnNAPisava_Click(object sender, EventArgs e)
        {
            
            if(fontDialogNA.ShowDialog() == DialogResult.OK)
            {
                this.pGlavnoOkno.SpremeniFont(fontDialogNA.Font);
            }
            
        }

        private void btnNASpremeni_Click(object sender, EventArgs e)
        {
            if(txtNANovo.Text == string.Empty || txtNAPonovi.Text == string.Empty)
            {
                MessageBox.Show("Napaka! Niste vnesli vseh podatkov.", "Napaka", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txtNANovo.Text != txtNAPonovi.Text)
            {
                MessageBox.Show("Napaka! Gesli se morata ujemati!", "Napaka", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txtNANovo.Text == pGlavnoOkno.pBinPodatki.geslo)
            {
                MessageBox.Show("Napaka! Geslo mora biti drugačno od prejšnjega!", "Napaka", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txtNANovo.Clear();
                this.txtNAPonovi.Clear();
            }
            else
            {
                MessageBox.Show("Geslo je bilo uspešno spremenjeno.", "Sprememba gesla", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //spremeni geslo
                pGlavnoOkno.pBinPodatki.geslo = txtNANovo.Text;
                pGlavnoOkno.pBinPodatki.spremenjenoGeslo++;
                pGlavnoOkno.pBinPodatki.ShraniBin();

                this.txtNANovo.Clear();
                this.txtNAPonovi.Clear();
            }
        }
    }
}
