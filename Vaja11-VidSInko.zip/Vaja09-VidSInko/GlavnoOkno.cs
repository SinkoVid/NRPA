﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vaja09_VidSInko
{
    public partial class GlavnoOkno : Form
    {
        //default
        public string DEFAULTupime = "vids";
        public string DEFAULTgeslo = "12345";

        //povezave na druga okna / razrede
        public Prijava pPrijava;
        public Nastavitve pNastavitve;
        public Pregled pPregled;        
        public BinPodatki pBinPodatki;
        public PoizkusiPrijave pPoizkusiPrijave;



        public GlavnoOkno()
        {
            InitializeComponent();
        }

        private void GlavnoOkno_Load(object sender, EventArgs e)
        {

            //prebere podatke iz datoteke - ce obstaja
            pBinPodatki = BinPodatki.BeriBin();
            if (pBinPodatki == null)
            {
                //ce datoteka ne obstaja -> nastavimo default -> shranimo v novo datoteko
                pBinPodatki = new BinPodatki();

                pBinPodatki.upime = DEFAULTupime;
                pBinPodatki.geslo = DEFAULTgeslo;
                pBinPodatki.spremenjenoGeslo = 0;

                pBinPodatki.ShraniBin();
            }



            //pošlje podatke prijavi za preverjanje pristnosti
            this.pPrijava = new Prijava(pBinPodatki, this);
            this.pPrijava.ShowDialog();
            this.Hide();

        }
        private void GlavnoOkno_Shown(object sender, EventArgs e)
        {
            this.lblGOSefIme.Text = this.pPrijava.upime;
        }


        //nastavitve form
        private void btnGONastavitve_Click(object sender, EventArgs e)
        {
            this.pNastavitve = new Nastavitve(this);
            this.pNastavitve.Show();           
        }

        //pregled form
        private void btnGOPregled_Click(object sender, EventArgs e)
        {
            this.pPregled = new Pregled(this);
            this.pPregled.Show();
        }



        //nastavi propertije teksta - username
        public void SpremeniBarvo(Color barva)
        {
            this.lblGOSefIme.ForeColor = barva;
        }
        public void SpremeniFont(Font font)
        { 
            this.lblGOSefIme.Font = font;
        }




        //refresh label za cas
        public void nastaviLabeloStatusBarPrijava()
        {
            DateTime cas = DateTime.Now;
            this.tstripGOCas.Text = cas.ToLongDateString() + ", " + cas.ToShortTimeString();
        }
        //razni dogodki za update casa
        private void nastaviCas_events(object sender, EventArgs e)
        {
            nastaviLabeloStatusBarPrijava();
        }



        private void btnPoizkusiPrijave_Click(object sender, EventArgs e)
        {
            this.pPoizkusiPrijave = new PoizkusiPrijave(this);
            this.pPoizkusiPrijave.Show();
        }
    }
}
