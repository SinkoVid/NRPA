﻿namespace Vaja09_VidSInko
{
    partial class GlavnoOkno
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GlavnoOkno));
            this.lblGOPozdrav = new System.Windows.Forms.Label();
            this.lblGOSefIme = new System.Windows.Forms.Label();
            this.btnGONastavitve = new System.Windows.Forms.Button();
            this.btnGOPregled = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tstripGOCas = new System.Windows.Forms.ToolStripStatusLabel();
            this.btnPoizkusiPrijave = new System.Windows.Forms.Button();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblGOPozdrav
            // 
            this.lblGOPozdrav.AutoSize = true;
            this.lblGOPozdrav.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.lblGOPozdrav.Location = new System.Drawing.Point(12, 19);
            this.lblGOPozdrav.Name = "lblGOPozdrav";
            this.lblGOPozdrav.Size = new System.Drawing.Size(142, 24);
            this.lblGOPozdrav.TabIndex = 0;
            this.lblGOPozdrav.Text = "Pozdravljen šef!";
            // 
            // lblGOSefIme
            // 
            this.lblGOSefIme.AutoSize = true;
            this.lblGOSefIme.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.lblGOSefIme.ForeColor = System.Drawing.Color.Red;
            this.lblGOSefIme.Location = new System.Drawing.Point(214, 19);
            this.lblGOSefIme.Name = "lblGOSefIme";
            this.lblGOSefIme.Size = new System.Drawing.Size(152, 24);
            this.lblGOSefIme.TabIndex = 1;
            this.lblGOSefIme.Text = "Uporabniško ime";
            // 
            // btnGONastavitve
            // 
            this.btnGONastavitve.Location = new System.Drawing.Point(16, 85);
            this.btnGONastavitve.Name = "btnGONastavitve";
            this.btnGONastavitve.Size = new System.Drawing.Size(138, 23);
            this.btnGONastavitve.TabIndex = 2;
            this.btnGONastavitve.Text = "Nastavitve";
            this.btnGONastavitve.UseVisualStyleBackColor = true;
            this.btnGONastavitve.Click += new System.EventHandler(this.btnGONastavitve_Click);
            // 
            // btnGOPregled
            // 
            this.btnGOPregled.Location = new System.Drawing.Point(218, 85);
            this.btnGOPregled.Name = "btnGOPregled";
            this.btnGOPregled.Size = new System.Drawing.Size(148, 23);
            this.btnGOPregled.TabIndex = 3;
            this.btnGOPregled.Text = "Pregled";
            this.btnGOPregled.UseVisualStyleBackColor = true;
            this.btnGOPregled.Click += new System.EventHandler(this.btnGOPregled_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tstripGOCas});
            this.statusStrip1.Location = new System.Drawing.Point(0, 156);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(378, 22);
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tstripGOCas
            // 
            this.tstripGOCas.Name = "tstripGOCas";
            this.tstripGOCas.Size = new System.Drawing.Size(0, 17);
            // 
            // btnPoizkusiPrijave
            // 
            this.btnPoizkusiPrijave.Location = new System.Drawing.Point(218, 114);
            this.btnPoizkusiPrijave.Name = "btnPoizkusiPrijave";
            this.btnPoizkusiPrijave.Size = new System.Drawing.Size(148, 23);
            this.btnPoizkusiPrijave.TabIndex = 5;
            this.btnPoizkusiPrijave.Text = "Poizkusi prijave";
            this.btnPoizkusiPrijave.UseVisualStyleBackColor = true;
            this.btnPoizkusiPrijave.Click += new System.EventHandler(this.btnPoizkusiPrijave_Click);
            // 
            // GlavnoOkno
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(378, 178);
            this.Controls.Add(this.btnPoizkusiPrijave);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.btnGOPregled);
            this.Controls.Add(this.btnGONastavitve);
            this.Controls.Add(this.lblGOSefIme);
            this.Controls.Add(this.lblGOPozdrav);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(394, 217);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(394, 217);
            this.Name = "GlavnoOkno";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sam svoj šef";
            this.Activated += new System.EventHandler(this.nastaviCas_events);
            this.Load += new System.EventHandler(this.GlavnoOkno_Load);
            this.Shown += new System.EventHandler(this.GlavnoOkno_Shown);
            this.Click += new System.EventHandler(this.nastaviCas_events);
            this.DoubleClick += new System.EventHandler(this.nastaviCas_events);
            this.Enter += new System.EventHandler(this.nastaviCas_events);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblGOPozdrav;
        private System.Windows.Forms.Label lblGOSefIme;
        private System.Windows.Forms.Button btnGONastavitve;
        private System.Windows.Forms.Button btnGOPregled;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tstripGOCas;
        private System.Windows.Forms.Button btnPoizkusiPrijave;
    }
}