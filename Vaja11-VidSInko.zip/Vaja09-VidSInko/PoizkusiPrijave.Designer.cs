﻿namespace Vaja09_VidSInko
{
    partial class PoizkusiPrijave
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PoizkusiPrijave));
            this.dgvLoginLog = new System.Windows.Forms.DataGridView();
            this.chPrijave = new System.Windows.Forms.DataVisualization.Charting.Chart();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoginLog)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chPrijave)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvLoginLog
            // 
            this.dgvLoginLog.AllowUserToAddRows = false;
            this.dgvLoginLog.AllowUserToDeleteRows = false;
            this.dgvLoginLog.AllowUserToResizeColumns = false;
            this.dgvLoginLog.AllowUserToResizeRows = false;
            this.dgvLoginLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLoginLog.Enabled = false;
            this.dgvLoginLog.Location = new System.Drawing.Point(12, 12);
            this.dgvLoginLog.MultiSelect = false;
            this.dgvLoginLog.Name = "dgvLoginLog";
            this.dgvLoginLog.ReadOnly = true;
            this.dgvLoginLog.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToDisplayedHeaders;
            this.dgvLoginLog.Size = new System.Drawing.Size(358, 476);
            this.dgvLoginLog.TabIndex = 0;
            // 
            // chPrijave
            // 
            chartArea1.Name = "ChartArea1";
            this.chPrijave.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chPrijave.Legends.Add(legend1);
            this.chPrijave.Location = new System.Drawing.Point(376, 12);
            this.chPrijave.Name = "chPrijave";
            this.chPrijave.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Bright;
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chPrijave.Series.Add(series1);
            this.chPrijave.Size = new System.Drawing.Size(354, 476);
            this.chPrijave.TabIndex = 1;
            this.chPrijave.Text = "Prijave";
            // 
            // PoizkusiPrijave
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(742, 497);
            this.Controls.Add(this.chPrijave);
            this.Controls.Add(this.dgvLoginLog);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PoizkusiPrijave";
            this.Text = "PregledPoizkusov";
            this.Load += new System.EventHandler(this.PoizkusiPrijave_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoginLog)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chPrijave)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvLoginLog;
        private System.Windows.Forms.DataVisualization.Charting.Chart chPrijave;
    }
}