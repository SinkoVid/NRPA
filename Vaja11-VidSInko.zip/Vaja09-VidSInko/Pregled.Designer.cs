﻿namespace Vaja09_VidSInko
{
    partial class Pregled
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Pregled));
            this.gboxInformacije = new System.Windows.Forms.GroupBox();
            this.txtSpremenjenoX = new System.Windows.Forms.TextBox();
            this.txtTrenutnoGeslo = new System.Windows.Forms.TextBox();
            this.lblSpremenjenoX = new System.Windows.Forms.Label();
            this.lblTrenutnoGeslo = new System.Windows.Forms.Label();
            this.gboxInformacije.SuspendLayout();
            this.SuspendLayout();
            // 
            // gboxInformacije
            // 
            this.gboxInformacije.Controls.Add(this.txtSpremenjenoX);
            this.gboxInformacije.Controls.Add(this.txtTrenutnoGeslo);
            this.gboxInformacije.Controls.Add(this.lblSpremenjenoX);
            this.gboxInformacije.Controls.Add(this.lblTrenutnoGeslo);
            this.gboxInformacije.Location = new System.Drawing.Point(12, 12);
            this.gboxInformacije.Name = "gboxInformacije";
            this.gboxInformacije.Size = new System.Drawing.Size(248, 105);
            this.gboxInformacije.TabIndex = 0;
            this.gboxInformacije.TabStop = false;
            this.gboxInformacije.Text = "Informacije";
            // 
            // txtSpremenjenoX
            // 
            this.txtSpremenjenoX.Enabled = false;
            this.txtSpremenjenoX.Location = new System.Drawing.Point(119, 57);
            this.txtSpremenjenoX.Name = "txtSpremenjenoX";
            this.txtSpremenjenoX.ReadOnly = true;
            this.txtSpremenjenoX.Size = new System.Drawing.Size(55, 20);
            this.txtSpremenjenoX.TabIndex = 3;
            // 
            // txtTrenutnoGeslo
            // 
            this.txtTrenutnoGeslo.Enabled = false;
            this.txtTrenutnoGeslo.Location = new System.Drawing.Point(119, 26);
            this.txtTrenutnoGeslo.Name = "txtTrenutnoGeslo";
            this.txtTrenutnoGeslo.ReadOnly = true;
            this.txtTrenutnoGeslo.Size = new System.Drawing.Size(100, 20);
            this.txtTrenutnoGeslo.TabIndex = 2;
            // 
            // lblSpremenjenoX
            // 
            this.lblSpremenjenoX.AutoSize = true;
            this.lblSpremenjenoX.Location = new System.Drawing.Point(13, 60);
            this.lblSpremenjenoX.Name = "lblSpremenjenoX";
            this.lblSpremenjenoX.Size = new System.Drawing.Size(100, 13);
            this.lblSpremenjenoX.TabIndex = 1;
            this.lblSpremenjenoX.Text = "Spremenjeno geslo:";
            // 
            // lblTrenutnoGeslo
            // 
            this.lblTrenutnoGeslo.AutoSize = true;
            this.lblTrenutnoGeslo.Location = new System.Drawing.Point(13, 29);
            this.lblTrenutnoGeslo.Name = "lblTrenutnoGeslo";
            this.lblTrenutnoGeslo.Size = new System.Drawing.Size(81, 13);
            this.lblTrenutnoGeslo.TabIndex = 0;
            this.lblTrenutnoGeslo.Text = "Trenutno geslo:";
            // 
            // Pregled
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(272, 129);
            this.Controls.Add(this.gboxInformacije);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(288, 168);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(288, 168);
            this.Name = "Pregled";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pregled";
            this.Load += new System.EventHandler(this.Pregled_Load);
            this.gboxInformacije.ResumeLayout(false);
            this.gboxInformacije.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gboxInformacije;
        private System.Windows.Forms.TextBox txtSpremenjenoX;
        private System.Windows.Forms.TextBox txtTrenutnoGeslo;
        private System.Windows.Forms.Label lblSpremenjenoX;
        private System.Windows.Forms.Label lblTrenutnoGeslo;
    }
}