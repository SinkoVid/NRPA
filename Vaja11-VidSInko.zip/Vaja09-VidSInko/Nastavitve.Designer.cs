﻿namespace Vaja09_VidSInko
{
    partial class Nastavitve
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Nastavitve));
            this.bgoxNAVnos = new System.Windows.Forms.GroupBox();
            this.txtNANovo = new System.Windows.Forms.TextBox();
            this.txtNAPonovi = new System.Windows.Forms.TextBox();
            this.btnNASpremeni = new System.Windows.Forms.Button();
            this.lblNAPonoviGeslo = new System.Windows.Forms.Label();
            this.lblNANovoGeslo = new System.Windows.Forms.Label();
            this.gboxNASpremeniOTHR = new System.Windows.Forms.GroupBox();
            this.btnNAPisava = new System.Windows.Forms.Button();
            this.btnNABarva = new System.Windows.Forms.Button();
            this.colorDialogNA = new System.Windows.Forms.ColorDialog();
            this.fontDialogNA = new System.Windows.Forms.FontDialog();
            this.bgoxNAVnos.SuspendLayout();
            this.gboxNASpremeniOTHR.SuspendLayout();
            this.SuspendLayout();
            // 
            // bgoxNAVnos
            // 
            this.bgoxNAVnos.Controls.Add(this.txtNANovo);
            this.bgoxNAVnos.Controls.Add(this.txtNAPonovi);
            this.bgoxNAVnos.Controls.Add(this.btnNASpremeni);
            this.bgoxNAVnos.Controls.Add(this.lblNAPonoviGeslo);
            this.bgoxNAVnos.Controls.Add(this.lblNANovoGeslo);
            this.bgoxNAVnos.Location = new System.Drawing.Point(12, 12);
            this.bgoxNAVnos.Name = "bgoxNAVnos";
            this.bgoxNAVnos.Size = new System.Drawing.Size(288, 180);
            this.bgoxNAVnos.TabIndex = 0;
            this.bgoxNAVnos.TabStop = false;
            this.bgoxNAVnos.Text = "Spremeni geslo";
            // 
            // txtNANovo
            // 
            this.txtNANovo.Location = new System.Drawing.Point(157, 48);
            this.txtNANovo.Name = "txtNANovo";
            this.txtNANovo.PasswordChar = '*';
            this.txtNANovo.Size = new System.Drawing.Size(106, 20);
            this.txtNANovo.TabIndex = 4;
            // 
            // txtNAPonovi
            // 
            this.txtNAPonovi.Location = new System.Drawing.Point(157, 85);
            this.txtNAPonovi.Name = "txtNAPonovi";
            this.txtNAPonovi.PasswordChar = '*';
            this.txtNAPonovi.Size = new System.Drawing.Size(106, 20);
            this.txtNAPonovi.TabIndex = 3;
            // 
            // btnNASpremeni
            // 
            this.btnNASpremeni.Location = new System.Drawing.Point(157, 128);
            this.btnNASpremeni.Name = "btnNASpremeni";
            this.btnNASpremeni.Size = new System.Drawing.Size(106, 23);
            this.btnNASpremeni.TabIndex = 2;
            this.btnNASpremeni.Text = "Spremeni";
            this.btnNASpremeni.UseVisualStyleBackColor = true;
            this.btnNASpremeni.Click += new System.EventHandler(this.btnNASpremeni_Click);
            // 
            // lblNAPonoviGeslo
            // 
            this.lblNAPonoviGeslo.AutoSize = true;
            this.lblNAPonoviGeslo.Location = new System.Drawing.Point(43, 88);
            this.lblNAPonoviGeslo.Name = "lblNAPonoviGeslo";
            this.lblNAPonoviGeslo.Size = new System.Drawing.Size(71, 13);
            this.lblNAPonoviGeslo.TabIndex = 1;
            this.lblNAPonoviGeslo.Text = "Ponovi geslo:";
            // 
            // lblNANovoGeslo
            // 
            this.lblNANovoGeslo.AutoSize = true;
            this.lblNANovoGeslo.Location = new System.Drawing.Point(43, 51);
            this.lblNANovoGeslo.Name = "lblNANovoGeslo";
            this.lblNANovoGeslo.Size = new System.Drawing.Size(64, 13);
            this.lblNANovoGeslo.TabIndex = 0;
            this.lblNANovoGeslo.Text = "Novo geslo:";
            // 
            // gboxNASpremeniOTHR
            // 
            this.gboxNASpremeniOTHR.Controls.Add(this.btnNAPisava);
            this.gboxNASpremeniOTHR.Controls.Add(this.btnNABarva);
            this.gboxNASpremeniOTHR.Location = new System.Drawing.Point(12, 198);
            this.gboxNASpremeniOTHR.Name = "gboxNASpremeniOTHR";
            this.gboxNASpremeniOTHR.Size = new System.Drawing.Size(288, 85);
            this.gboxNASpremeniOTHR.TabIndex = 1;
            this.gboxNASpremeniOTHR.TabStop = false;
            this.gboxNASpremeniOTHR.Text = "Spremeni uporabniško ime";
            // 
            // btnNAPisava
            // 
            this.btnNAPisava.Location = new System.Drawing.Point(157, 40);
            this.btnNAPisava.Name = "btnNAPisava";
            this.btnNAPisava.Size = new System.Drawing.Size(106, 23);
            this.btnNAPisava.TabIndex = 1;
            this.btnNAPisava.Text = "Pisava";
            this.btnNAPisava.UseVisualStyleBackColor = true;
            this.btnNAPisava.Click += new System.EventHandler(this.btnNAPisava_Click);
            // 
            // btnNABarva
            // 
            this.btnNABarva.Location = new System.Drawing.Point(34, 40);
            this.btnNABarva.Name = "btnNABarva";
            this.btnNABarva.Size = new System.Drawing.Size(106, 23);
            this.btnNABarva.TabIndex = 0;
            this.btnNABarva.Text = "Barva";
            this.btnNABarva.UseVisualStyleBackColor = true;
            this.btnNABarva.Click += new System.EventHandler(this.btnNABarva_Click);
            // 
            // Nastavitve
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(312, 295);
            this.Controls.Add(this.gboxNASpremeniOTHR);
            this.Controls.Add(this.bgoxNAVnos);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(328, 334);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(328, 334);
            this.Name = "Nastavitve";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Nastavitve";
            this.Load += new System.EventHandler(this.Nastavitve_Load);
            this.bgoxNAVnos.ResumeLayout(false);
            this.bgoxNAVnos.PerformLayout();
            this.gboxNASpremeniOTHR.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox bgoxNAVnos;
        private System.Windows.Forms.GroupBox gboxNASpremeniOTHR;
        private System.Windows.Forms.Button btnNAPisava;
        private System.Windows.Forms.Button btnNABarva;
        private System.Windows.Forms.TextBox txtNANovo;
        private System.Windows.Forms.TextBox txtNAPonovi;
        private System.Windows.Forms.Button btnNASpremeni;
        private System.Windows.Forms.Label lblNAPonoviGeslo;
        private System.Windows.Forms.Label lblNANovoGeslo;
        private System.Windows.Forms.ColorDialog colorDialogNA;
        private System.Windows.Forms.FontDialog fontDialogNA;
    }
}