﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vaja09_VidSInko
{
    public partial class Pregled : Form
    {
        public GlavnoOkno pGlavnoOkno;

        public Pregled(GlavnoOkno glavnoOkno)
        {
            InitializeComponent();
            this.pGlavnoOkno = glavnoOkno;
        }

        public Pregled()
        {
            InitializeComponent();
        }

        private void Pregled_Load(object sender, EventArgs e)
        {
            txtTrenutnoGeslo.Text = pGlavnoOkno.pBinPodatki.geslo;
            txtSpremenjenoX.Text = pGlavnoOkno.pBinPodatki.spremenjenoGeslo + "x";
        }
    }
}
