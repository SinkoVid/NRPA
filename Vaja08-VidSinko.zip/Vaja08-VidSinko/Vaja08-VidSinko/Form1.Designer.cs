﻿namespace Vaja08_VidSinko
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gboxMeritev = new System.Windows.Forms.GroupBox();
            this.dtpDatum = new System.Windows.Forms.DateTimePicker();
            this.txtTemp = new System.Windows.Forms.TextBox();
            this.lblTemp = new System.Windows.Forms.Label();
            this.btnShrani = new System.Windows.Forms.Button();
            this.lboxData = new System.Windows.Forms.ListBox();
            this.btnNalozi = new System.Windows.Forms.Button();
            this.lbl1 = new System.Windows.Forms.Label();
            this.gboxMeritev.SuspendLayout();
            this.SuspendLayout();
            // 
            // gboxMeritev
            // 
            this.gboxMeritev.Controls.Add(this.lbl1);
            this.gboxMeritev.Controls.Add(this.btnShrani);
            this.gboxMeritev.Controls.Add(this.lblTemp);
            this.gboxMeritev.Controls.Add(this.txtTemp);
            this.gboxMeritev.Controls.Add(this.dtpDatum);
            this.gboxMeritev.Location = new System.Drawing.Point(22, 28);
            this.gboxMeritev.Name = "gboxMeritev";
            this.gboxMeritev.Size = new System.Drawing.Size(205, 133);
            this.gboxMeritev.TabIndex = 0;
            this.gboxMeritev.TabStop = false;
            this.gboxMeritev.Text = "Nova meritev";
            // 
            // dtpDatum
            // 
            this.dtpDatum.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDatum.Location = new System.Drawing.Point(40, 31);
            this.dtpDatum.Name = "dtpDatum";
            this.dtpDatum.Size = new System.Drawing.Size(114, 20);
            this.dtpDatum.TabIndex = 0;
            // 
            // txtTemp
            // 
            this.txtTemp.Location = new System.Drawing.Point(39, 61);
            this.txtTemp.Name = "txtTemp";
            this.txtTemp.Size = new System.Drawing.Size(63, 20);
            this.txtTemp.TabIndex = 1;
            // 
            // lblTemp
            // 
            this.lblTemp.AutoSize = true;
            this.lblTemp.Location = new System.Drawing.Point(118, 64);
            this.lblTemp.Name = "lblTemp";
            this.lblTemp.Size = new System.Drawing.Size(0, 13);
            this.lblTemp.TabIndex = 2;
            // 
            // btnShrani
            // 
            this.btnShrani.Location = new System.Drawing.Point(39, 104);
            this.btnShrani.Name = "btnShrani";
            this.btnShrani.Size = new System.Drawing.Size(114, 23);
            this.btnShrani.TabIndex = 4;
            this.btnShrani.Text = "Shrani";
            this.btnShrani.UseVisualStyleBackColor = true;
            this.btnShrani.Click += new System.EventHandler(this.btnShrani_Click);
            // 
            // lboxData
            // 
            this.lboxData.FormattingEnabled = true;
            this.lboxData.Location = new System.Drawing.Point(22, 231);
            this.lboxData.Name = "lboxData";
            this.lboxData.Size = new System.Drawing.Size(205, 225);
            this.lboxData.TabIndex = 1;
            // 
            // btnNalozi
            // 
            this.btnNalozi.Location = new System.Drawing.Point(62, 202);
            this.btnNalozi.Name = "btnNalozi";
            this.btnNalozi.Size = new System.Drawing.Size(114, 23);
            this.btnNalozi.TabIndex = 5;
            this.btnNalozi.Text = "Naloži vse";
            this.btnNalozi.UseVisualStyleBackColor = true;
            this.btnNalozi.Click += new System.EventHandler(this.btnNalozi_Click);
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(108, 64);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(18, 13);
            this.lbl1.TabIndex = 5;
            this.lbl1.Text = "°C";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(251, 476);
            this.Controls.Add(this.btnNalozi);
            this.Controls.Add(this.lboxData);
            this.Controls.Add(this.gboxMeritev);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Name = "Form1";
            this.Text = "Meritev";
            this.gboxMeritev.ResumeLayout(false);
            this.gboxMeritev.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gboxMeritev;
        private System.Windows.Forms.Button btnShrani;
        private System.Windows.Forms.Label lblTemp;
        private System.Windows.Forms.TextBox txtTemp;
        private System.Windows.Forms.DateTimePicker dtpDatum;
        private System.Windows.Forms.ListBox lboxData;
        private System.Windows.Forms.Button btnNalozi;
        private System.Windows.Forms.Label lbl1;
    }
}

