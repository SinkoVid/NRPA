﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.WebRequestMethods;

namespace Vaja08_VidSinko
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


        }

        private void Pocisti()
        {
            txtTemp.Text = string.Empty;
            dtpDatum.Value = DateTime.Today;
        }


        private void btnShrani_Click(object sender, EventArgs e)
        {
            int temp;

            if (int.TryParse(txtTemp.Text, out temp))
            {
                string message = "Po podatkih je dan ";
                message += dtpDatum.Value.ToShortDateString();
                message += " bila izmerjena temperatura ";
                message += txtTemp.Text + "°C.\n\n";
                message += "Shranim podatek?";

                if (MessageBox.Show(message, "Meritev", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    BinaryWriter bw = new BinaryWriter(new FileStream(@"C:\test\test.bin", FileMode.Create));

                    try
                    {
                        string datum = dtpDatum.Value.ToShortDateString();
                        int temperatura = int.Parse(txtTemp.Text);

                        bw.Write(datum);
                        bw.Write(temperatura);

                    }
                    catch (Exception exc)
                    {
                        MessageBox.Show(exc.Message);
                    }

                    bw.Close();
                    Pocisti();

                    try
                    {
                        BinaryReader br = new BinaryReader(new FileStream(@"C:\test\test.bin", FileMode.Open));

                        string datum = br.ReadString();
                        int temperatura = br.ReadInt32();

                        MessageBox.Show(datum + " " + temperatura + " °C", "Meritev", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        br.Close();
                    }
                    catch (IOException exc)
                    {
                        Console.WriteLine(exc.Message);
                    }

                    bw.Close();
                    Pocisti();

                }
                else
                {
                    MessageBox.Show("Vnesi število (temperatura)", "Napaka!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void btnNalozi_Click(object sender, EventArgs e)
        { 
            try
            {
                BinaryReader br = new BinaryReader(new FileStream(@"C:\test\test.bin", FileMode.Open));

                string datum = br.ReadString();
                int temperatura = br.ReadInt32();

                
                lboxData.Items.Add(datum + " | " + temperatura + " °C");

                br.Close();
            }
            catch (IOException exc)
            {
                MessageBox.Show(exc.Message);
            }

            
            Pocisti();
        }
    }
}
